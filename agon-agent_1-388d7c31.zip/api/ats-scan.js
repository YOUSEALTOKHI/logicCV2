import supabase from './_supabase.js';

// ============================================================
// ENTERPRISE-GRADE ATS SCANNER ENGINE v4.0
// Modeled after: Taleo, Workday, Greenhouse, Lever, iCIMS, SmartRecruiters
// 150+ evaluation criteria | Deterministic scoring | Zero randomness
// ============================================================

// ─── SECTION HEADER PATTERNS (EN + AR) ───
const SECTION_PATTERNS = {
  contact: [
    'contact', 'contact information', 'personal details', 'personal info',
    'معلومات الاتصال', 'البيانات الشخصية', 'التواصل',
  ],
  summary: [
    'summary', 'professional summary', 'profile', 'about me', 'objective',
    'career objective', 'professional profile', 'executive summary',
    'الملخص', 'نبذة عني', 'الملخص التنفيذي', 'الهدف المهني',
  ],
  experience: [
    'experience', 'work experience', 'professional experience', 'employment history',
    'work history', 'career history', 'employment', 'professional background',
    'الخبرات', 'الخبرة العملية', 'الخبرة المهنية', 'تاريخ العمل', 'الوظائف السابقة',
  ],
  education: [
    'education', 'academic background', 'academic history', 'qualifications',
    'educational background', 'academic qualifications',
    'التعليم', 'المؤهلات العلمية', 'الخلفية الأكاديمية', 'التعليم الأكاديمي',
  ],
  skills: [
    'skills', 'technical skills', 'core competencies', 'competencies',
    'areas of expertise', 'skill set', 'key skills', 'proficiencies',
    'المهارات', 'المهارات التقنية', 'الكفاءات', 'مجالات الخبرة',
  ],
  certifications: [
    'certifications', 'certificates', 'credentials', 'licenses',
    'professional certifications', 'accreditations',
    'الشهادات', 'التراخيص', 'المؤهلات المهنية',
  ],
  projects: [
    'projects', 'portfolio', 'project experience', 'notable projects',
    'المشاريع', 'معرض الأعمال', 'مشاريع مميزة',
  ],
  awards: [
    'awards', 'honors', 'achievements', 'recognition', 'accomplishments',
    'الجوائز', 'التكريمات', 'الإنجازات', 'الأوسمة',
  ],
  languages: [
    'languages', 'language proficiency', 'language skills',
    'اللغات', 'إتقان اللغات',
  ],
  references: [
    'references', 'references available upon request',
    'المراجع', 'مراجع متاحة عند الطلب',
  ],
  volunteer: [
    'volunteer', 'volunteering', 'community service', 'community involvement',
    'التطوع', 'العمل التطوعي', 'خدمة المجتمع',
  ],
  publications: [
    'publications', 'research', 'papers', 'articles', 'patents',
    'المنشورات', 'البحث العلمي', 'المقالات',
  ],
};

// ─── COMPREHENSIVE ACTION VERBS (Power Verbs) ───
const POWER_VERBS = {
  leadership: ['led', 'managed', 'directed', 'supervised', 'oversaw', 'headed', 'chaired', 'coordinated', 'orchestrated', 'spearheaded', 'guided', 'mentored', 'trained', 'coached'],
  achievement: ['achieved', 'delivered', 'exceeded', 'surpassed', 'attained', 'accomplished', 'realized', 'secured', 'won', 'earned'],
  creation: ['created', 'developed', 'built', 'designed', 'established', 'founded', 'launched', 'initiated', 'pioneered', 'engineered', 'architected', 'constructed', 'formulated'],
  improvement: ['improved', 'enhanced', 'optimized', 'streamlined', 'upgraded', 'modernized', 'revamped', 'refined', 'strengthened', 'boosted', 'accelerated'],
  analysis: ['analyzed', 'evaluated', 'assessed', 'examined', 'investigated', 'researched', 'audited', 'diagnosed', 'surveyed', 'measured', 'monitored'],
  financial: ['reduced', 'cut', 'saved', 'decreased', 'lowered', 'minimized', 'eliminated', 'increased', 'grew', 'expanded', 'generated', 'budgeted', 'allocated'],
  communication: ['presented', 'negotiated', 'persuaded', 'influenced', 'drafted', 'authored', 'published', 'communicated', 'addressed', 'represented'],
  technical: ['implemented', 'deployed', 'integrated', 'migrated', 'configured', 'programmed', 'coded', 'debugged', 'tested', 'automated', 'scripted'],
  problem_solving: ['resolved', 'solved', 'fixed', 'troubleshooted', 'addressed', 'overcame', 'transformed', 'restructured', 'reorganized', 'consolidated'],
  strategic: ['devised', 'formulated', 'defined', 'shaped', 'championed', 'drove', 'propelled', 'positioned', 'aligned', 'partnered', 'collaborated'],
};

const ALL_POWER_VERBS = Object.values(POWER_VERBS).flat();

// ─── WEAK/FILLER PHRASES (Red Flags) ───
const WEAK_PHRASES = [
  'responsible for', 'duties included', 'responsibilities included',
  'helped with', 'assisted in', 'participated in', 'involved in',
  'worked on', 'was part of', 'contributed to', 'my duties were',
  'tasks included', 'job functions', 'i was responsible',
  // Generic fluff
  'team player', 'hard worker', 'self-starter', 'go-getter',
  'think outside the box', 'synergy', 'leverage', 'utilize',
  'best of breed', 'bottom line', 'value add', 'move the needle',
  'hit the ground running', 'fast-paced environment', 'detail-oriented',
  'results-driven', 'dynamic', 'motivated self-starter',
  // Arabic weak phrases
  'مسؤول عن', 'كانت مهامي', 'شاركت في', 'عملت على',
];

// ─── SKILLS TAXONOMY ───
const SKILL_CATEGORIES = {
  programming_languages: [
    'python', 'javascript', 'typescript', 'java', 'c plus plus', 'cpp', 'c sharp', 'c#', 'go', 'rust', 'swift', 'kotlin',
    'ruby', 'php', 'scala', 'r language', 'matlab', 'perl', 'shell script', 'bash', 'powershell', 'sql',
  ],
  web_frameworks: [
    'react', 'angular', 'vue', 'next.js', 'nuxt', 'svelte', 'express', 'django', 'flask',
    'spring boot', 'rails', 'laravel', 'asp.net', 'node.js', 'nest.js', 'fastapi',
  ],
  cloud_devops: [
    'aws', 'azure', 'gcp', 'google cloud', 'docker', 'kubernetes', 'k8s', 'terraform',
    'ansible', 'jenkins', 'github actions', 'gitlab ci', 'ci/cd', 'devops', 'microservices',
  ],
  data_ai: [
    'machine learning', 'deep learning', 'ai', 'artificial intelligence', 'data science',
    'nlp', 'computer vision', 'tensorflow', 'pytorch', 'keras', 'scikit-learn', 'pandas',
    'numpy', 'spark', 'hadoop', 'big data', 'etl', 'data warehouse', 'bi', 'tableau',
    'power bi', 'looker', 'sql server', 'postgresql', 'mongodb', 'redis', 'elasticsearch',
  ],
  mobile: [
    'ios', 'android', 'react native', 'flutter', 'swiftui', 'kotlin', 'xcode',
    'android studio', 'mobile development', 'app store', 'play store',
  ],
  design: [
    'figma', 'sketch', 'adobe xd', 'photoshop', 'illustrator', 'after effects',
    'ui design', 'ux design', 'wireframing', 'prototyping', 'design system',
    'responsive design', 'css', 'scss', 'sass', 'tailwind', 'bootstrap',
  ],
  project_management: [
    'agile', 'scrum', 'kanban', 'waterfall', 'jira', 'confluence', 'trello', 'asana',
    'monday.com', 'project management', 'pmp', 'prince2', 'stakeholder management',
    'roadmap planning', 'sprint planning', 'backlog management',
  ],
  marketing: [
    'seo', 'sem', 'ppc', 'google analytics', 'facebook ads', 'instagram ads',
    'email marketing', 'marketing automation', 'hubspot', 'salesforce', 'crm',
    'content marketing', 'social media marketing', 'branding', 'copywriting',
    'conversion rate optimization', 'cro', 'a/b testing', 'growth hacking',
  ],
  business_finance: [
    'financial modeling', 'financial analysis', 'accounting', 'forecasting',
    'budgeting', 'valuation', 'due diligence', 'investment banking', 'private equity',
    'venture capital', 'strategy consulting', 'management consulting', 'business development',
    'partnership development', 'revenue operations', 'revops', 'saas',
  ],
  soft_skills: [
    'leadership', 'communication', 'teamwork', 'problem solving', 'critical thinking',
    'time management', 'adaptability', 'emotional intelligence', 'negotiation',
    'presentation', 'public speaking', 'decision making', 'conflict resolution',
    'cross-functional collaboration', 'stakeholder management', 'mentorship',
  ],
  office_tools: [
    'microsoft office', 'excel', 'powerpoint', 'word', 'outlook', 'google workspace',
    'google sheets', 'google docs', 'google slides', 'notion', 'slack', 'zoom',
    'microsoft teams', 'sharepoint', 'onedrive', 'dropbox',
  ],
};

const ALL_SKILLS = Object.values(SKILL_CATEGORIES).flat();

// ─── DEGREE LEVELS ───
const DEGREE_LEVELS = {
  doctoral: ['phd', 'doctorate', 'doctor of philosophy', 'دكتوراه', 'دكتور'],
  masters: ['master', 'mba', 'msc', 'ms', 'm.a.', 'm.b.a.', 'm.sc.', 'ماجستير', 'ماجستير إدارة أعمال'],
  bachelors: ['bachelor', "b.s.", 'b.a.', 'b.sc.', 'b.eng.', 'btech', 'بكالوريوس', 'إجازة'],
  associate: ['associate', "a.a.", 'a.s.', 'diploma', 'دبلوم'],
  high_school: ['high school', 'ged', 'secondary school', 'ثانوية', 'شهادة ثانوية'],
  certification: ['certificate', 'certification', 'شهادة', 'معتمد'],
};

// ─── REGEX PATTERNS ───
const PATTERNS = {
  email: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/gi,
  phone: /(?:\+?\d{1,3}[-.\s]?)?\(?\d{2,4}\)?[-.\s]?\d{2,4}[-.\s]?\d{2,6}(?![\d@])/gi,
  linkedin: /linkedin\.com\/in\/[a-zA-Z0-9_-]{5,30}/gi,
  github: /github\.com\/[a-zA-Z0-9_-]{1,39}/gi,
  portfolio: /(?:portfolio|website|site|behance|dribbble)[.:]\s*\S+/gi,
  url: /https?:\/\/[^\s<>"')\]]+/gi,
  date_range: /\b((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?[\s\-\/]*\d{2,4}|\d{1,2}[\/\-]\d{2,4})\s*[-–—to]+\s*((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?[\s\-\/]*\d{2,4}|present|current|now|حتى الآن|الآن)/gi,
  single_date: /\b((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?[\s\-\/]*\d{2,4}|\d{4})\b/gi,
  gpa: /gpa[:\s]*(\d+\.?\d*)|(?:cgpa|grade)[:\s]*(\d+\.?\d*)/gi,
  currency_metric: /[$€£¥]\s*[\d,]+(?:\.\d+)?[kmb]?|\d+[%$]|[\d,]+(?:\.\d+)?\s*(?:%|dollars|euros|pounds)/gi,
  metric_patterns: [
    /\d+\s*%/gi,
    /\$\s*[\d,]+(?:\.\d+)?/gi,
    /\d+(?:\.\d+)?\s*(?:million|billion|thousand|k|m|b)/gi,
    /\d+(?:\.\d+)?\s*(?:users|clients|customers|employees|team members|projects|deals|leads|orders|units|items)/gi,
    /\d+(?:\.\d+)?\s*(?:percent|reduction|increase|decrease|growth|saving|savings|revenue|profit|cost|hours|days|weeks|months|years)/gi,
    /reduced\s+by\s+\d+/gi,
    /increased\s+by\s+\d+/gi,
    /saved\s+\$?[\d,]+/gi,
    /generated\s+\$?[\d,]+/gi,
    /managed\s+\$?[\d,]+/gi,
    /led\s+a\s+team\s+of\s+\d+/gi,
    /team\s+of\s+\d+/gi,
  ],
};

// ─── ATS KILLER ELEMENTS ───
const ATS_KILLERS = {
  tables: { pattern: /\|[^\n]+\|[^\n]+\|/, penalty: 25, msg: 'Tables break ATS parsing' },
  images: { pattern: /<img|\[image\]|\[photo\]|<figure/i, penalty: 20, msg: 'Images are invisible to ATS' },
  headers_footers: { pattern: /header|footer|page\s*\d+\s*of\s*\d+/i, penalty: 10, msg: 'Headers/footers confuse ATS' },
  two_column: { pattern: /^\s*[^\n]{80,}\s{5,}[^\n]+$/gm, penalty: 20, msg: 'Two-column layouts misread by ATS' },
  special_symbols: { pattern: /[★☆●◉▶▷◆◇♦♥♠♣▲▼■□▪▫]/g, penalty: 12, msg: 'Special symbols cause encoding errors' },
  non_standard_fonts: { pattern: /(comic\s*sans|papyrus|brush\s*script|wingdings|symbol)/i, penalty: 8, msg: 'Non-standard fonts fail to render' },
  encoded_chars: { pattern: /&[a-z]+;|\\u[0-9a-fA-F]{4}|&#\d+;/g, penalty: 15, msg: 'HTML entities corrupt text extraction' },
  macros_scripts: { pattern: /<script|macro|vba|active|x|object/i, penalty: 30, msg: 'Scripts/macros trigger security blocks' },
  text_boxes: { pattern: /text\s*box|textbox|wordart/i, penalty: 18, msg: 'Text boxes are often skipped' },
  password_protected: { pattern: /password|protected|encrypted/i, penalty: 50, msg: 'Protected files cannot be scanned' },
};

// ─── UTILITIES ───
function hashString(str) {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) + hash + str.charCodeAt(i)) & 0xFFFFFFFF;
  }
  return hash >>> 0;
}

function extractTextHash(text) {
  return hashString(text.trim().replace(/\s+/g, ' '));
}

function detectLanguage(text) {
  const arabicPattern = /[\u0600-\u06FF]/;
  const arabicMatches = (text.match(arabicPattern) || []).length;
  const totalChars = text.replace(/\s/g, '').length;
  if (totalChars === 0) return 'en';
  return arabicMatches / totalChars > 0.3 ? 'ar' : 'en';
}

function cleanText(text) {
  return text
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/\t/g, ' ')
    .replace(/ {2,}/g, ' ')
    .trim();
}

function getWords(text) {
  return text.split(/\s+/).filter(w => w.length > 0);
}

function getLines(text) {
  return text.split('\n').filter(l => l.trim().length > 0);
}

function findSectionPosition(text, patterns) {
  const lower = text.toLowerCase();
  let bestPos = -1;
  let bestMatch = null;
  for (const p of patterns) {
    const idx = lower.indexOf(p.toLowerCase());
    if (idx !== -1 && (bestPos === -1 || idx < bestPos)) {
      bestPos = idx;
      bestMatch = p;
    }
  }
  return { position: bestPos, match: bestMatch };
}

function extractSectionBetween(text, startPatterns, endPatterns) {
  const lower = text.toLowerCase();
  let startPos = -1;
  let startMatch = null;

  for (const p of startPatterns) {
    const idx = lower.indexOf(p.toLowerCase());
    if (idx !== -1 && (startPos === -1 || idx < startPos)) {
      startPos = idx;
      startMatch = p;
    }
  }

  if (startPos === -1) return null;

  let endPos = text.length;
  for (const p of endPatterns) {
    const idx = lower.indexOf(p.toLowerCase(), startPos + 10);
    if (idx !== -1 && idx < endPos) {
      endPos = idx;
    }
  }

  return text.substring(startPos, endPos);
}

// ─── CORE ANALYSIS ENGINE ───
function analyzeResume(rawText, userLanguage = 'en') {
  const text = cleanText(rawText);
  const detectedLang = detectLanguage(text);
  const isAr = detectedLang === 'ar';
  const lower = text.toLowerCase();
  const words = getWords(text);
  const wordCount = words.length;
  const lines = getLines(text);
  const lineCount = lines.length;
  const sentences = text.split(/[.!?؟。]+/).filter(s => s.trim().length > 5);
  const textHash = extractTextHash(text);

  // ════════════════════════════════════════════════════════
  // 1. CONTACT INFORMATION ANALYSIS (Weight: 8%)
  // ════════════════════════════════════════════════════════
  const contactAnalysis = analyzeContactInfo(text, lower, lines, isAr);

  // ════════════════════════════════════════════════════════
  // 2. STRUCTURE & FORMATTING ANALYSIS (Weight: 14%)
  // ════════════════════════════════════════════════════════
  const structureAnalysis = analyzeStructure(text, lower, lines, words, wordCount, lineCount, isAr);

  // ════════════════════════════════════════════════════════
  // 3. PROFESSIONAL SUMMARY ANALYSIS (Weight: 6%)
  // ════════════════════════════════════════════════════════
  const summaryAnalysis = analyzeSummary(text, lower, words, wordCount, isAr);

  // ════════════════════════════════════════════════════════
  // 4. WORK EXPERIENCE ANALYSIS (Weight: 26%)
  // ════════════════════════════════════════════════════════
  const experienceAnalysis = analyzeExperience(text, lower, lines, words, isAr);

  // ════════════════════════════════════════════════════════
  // 5. EDUCATION ANALYSIS (Weight: 10%)
  // ════════════════════════════════════════════════════════
  const educationAnalysis = analyzeEducation(text, lower, lines, isAr);

  // ════════════════════════════════════════════════════════
  // 6. SKILLS & KEYWORDS ANALYSIS (Weight: 22%)
  // ════════════════════════════════════════════════════════
  const skillsAnalysis = analyzeSkills(text, lower, words, wordCount, isAr);

  // ════════════════════════════════════════════════════════
  // 7. ATS TECHNICAL COMPATIBILITY (Weight: 14%)
  // ════════════════════════════════════════════════════════
  const atsCompatibility = analyzeATSCompatibility(text, lower, lines, isAr);

  // ════════════════════════════════════════════════════════
  // CALCULATE WEIGHTED OVERALL SCORE
  // ════════════════════════════════════════════════════════
  const sections = {
    contact_information: contactAnalysis,
    formatting_structure: structureAnalysis,
    professional_summary: summaryAnalysis,
    work_experience: experienceAnalysis,
    education: educationAnalysis,
    skills_keywords: skillsAnalysis,
    ats_compatibility: atsCompatibility,
  };

  const weights = {
    contact_information: 0.08,
    formatting_structure: 0.14,
    professional_summary: 0.06,
    work_experience: 0.26,
    education: 0.10,
    skills_keywords: 0.22,
    ats_compatibility: 0.14,
  };

  let overallScore = 0;
  for (const [key, weight] of Object.entries(weights)) {
    overallScore += sections[key].score * weight;
  }
  overallScore = Math.round(Math.max(0, Math.min(100, overallScore)));

  // ════════════════════════════════════════════════════════
  // GENERATE IMPROVEMENTS & STRENGTHS
  // ════════════════════════════════════════════════════════
  const improvements = [];
  const strengths = [];

  for (const [key, section] of Object.entries(sections)) {
    if (section.criticalIssues && section.criticalIssues.length > 0) {
      improvements.push(...section.criticalIssues.slice(0, 2));
    }
    if (section.score >= 75 && section.strengths) {
      strengths.push(...section.strengths.slice(0, 2));
    } else if (section.score < 50 && section.improvements) {
      improvements.push(...section.improvements.slice(0, 2));
    }
  }

  // Deduplicate
  const seenImprovements = new Set();
  const uniqueImprovements = [];
  for (const imp of improvements) {
    if (!seenImprovements.has(imp)) {
      seenImprovements.add(imp);
      uniqueImprovements.push(imp);
    }
  }
  // Fix: use correct variable
  const finalImprovements = Array.from(seenImprovements);

  const seenStrengths = new Set();
  const uniqueStrengths = [];
  for (const str of strengths) {
    if (!seenStrengths.has(str)) {
      seenStrengths.add(str);
      uniqueStrengths.push(str);
    }
  }

  // Generate compatibility verdict
  const verdict = generateVerdict(overallScore, sections, isAr);

  return {
    overall_score: overallScore,
    language_detected: detectedLang,
    sections,
    improvements: finalImprovements.slice(0, 8),
    strengths: uniqueStrengths.slice(0, 6),
    ats_compatibility: verdict.text,
    compatibility_level: verdict.level,
    metadata: {
      word_count: wordCount,
      line_count: lineCount,
      character_count: text.length,
      analyzed_at: new Date().toISOString(),
      engine_version: '4.0-enterprise',
    },
  };
}

// ─── 1. CONTACT INFORMATION ───
function analyzeContactInfo(text, lower, lines, isAr) {
  const issues = [];
  const strengths = [];
  const criticalIssues = [];
  let score = 0;

  // Name detection (first non-empty line should be name)
  const firstLine = lines[0]?.trim() || '';
  const looksLikeName = /^[A-Za-z\u0600-\u06FF\s]{2,50}$/.test(firstLine) &&
    !firstLine.includes('@') && !firstLine.includes('http') &&
    !/\d{3,}/.test(firstLine) && firstLine.split(/\s+/).length >= 2 &&
    firstLine.split(/\s+/).length <= 5;

  if (looksLikeName) { score += 15; strengths.push(isAr ? '✓ اسم واضح في أول السيرة' : '✓ Clear name at resume top'); }
  else { issues.push(isAr ? '✗ لم يتم تحديد اسم واضح في بداية السيرة' : '✗ No clear name detected at resume top'); criticalIssues.push(isAr ? 'أضف اسمك الكامل في أول صفحة' : 'Add your full name at the top of your resume'); }

  // Email
  const emails = text.match(PATTERNS.email) || [];
  const hasValidEmail = emails.some(e => {
    const domain = e.split('@')[1];
    return domain && !domain.includes('example') && !domain.includes('test');
  });
  const hasProfessionalEmail = emails.some(e => {
    const domain = e.split('@')[1]?.toLowerCase();
    return domain && !['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'mail.com'].includes(domain);
  });

  if (emails.length > 0 && hasValidEmail) {
    score += 20;
    if (hasProfessionalEmail) { score += 5; strengths.push(isAr ? '✓ بريد إلكتروني مهني' : '✓ Professional email address used'); }
    else { issues.push(isAr ? '⚠ استخدم بريد مهني بدلاً من Gmail/Yahoo' : '⚠ Use a professional email instead of personal services'); }
  } else {
    issues.push(isAr ? '✗ لا يوجد بريد إلكتروني صالح' : '✗ No valid email address found');
    criticalIssues.push(isAr ? 'أضف بريد إلكتروني احترافي' : 'Add a professional email address');
  }

  // Phone
  const phones = text.match(PATTERNS.phone) || [];
  const validPhones = phones.filter(p => p.replace(/\D/g, '').length >= 7);
  if (validPhones.length > 0) { score += 20; strengths.push(isAr ? '✓ رقم هاتف موجود' : '✓ Phone number present'); }
  else { issues.push(isAr ? '✗ لا يوجد رقم هاتف' : '✗ No phone number found'); criticalIssues.push(isAr ? 'أضف رقم هاتف للتواصل' : 'Add a phone number for contact'); }

  // LinkedIn
  const linkedinUrls = text.match(PATTERNS.linkedin) || [];
  if (linkedinUrls.length > 0) { score += 15; strengths.push(isAr ? '✓ رابط LinkedIn موجود' : '✓ LinkedIn profile URL included'); }
  else { issues.push(isAr ? '⚠ أضف رابط ملفك على LinkedIn' : '⚠ Add your LinkedIn profile URL'); }

  // GitHub/Portfolio (bonus)
  const githubUrls = text.match(PATTERNS.github) || [];
  const portfolioUrls = text.match(PATTERNS.portfolio) || [];
  if (githubUrls.length > 0) { score += 5; strengths.push(isAr ? '✓ رابط GitHub موجود' : '✓ GitHub profile included'); }
  if (portfolioUrls.length > 0) { score += 5; strengths.push(isAr ? '✓ موقع أعمال/معرض موجود' : '✓ Portfolio/website included'); }

  // Location
  const locationPatterns = [
    /(?:city|location|address|based in|located in)[:\s]*([A-Za-z\s,]+)/i,
    /(?:الموقع|المدينة|العنوان|أعيش في)[:\s]*([\u0600-\u06FF\s,]+)/i,
    /\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*,\s*[A-Z]{2}\b/,
    /\b(?:Egypt|Saudi Arabia|UAE|Dubai|Kuwait|Qatar|Bahrain|Oman|Jordan|Lebanon|Iraq|Morocco|Algeria|Tunis|Cairo|Riyadh|Jeddah|Doha|Abu Dhabi|Manama|Muscat|Amman|Beirut|Baghdad|Casablanca|Algiers|Tunis)\b/i,
    /(?:مصر|السعودية|الإمارات|دبي|الكويت|قطر|البحرين|عمان|الأردن|لبنان|العراق|المغرب|الجزائر|تونس|القاهرة|الرياض|جدة|الدوحة|أبو ظبي|المنامة|مسقط|عمّان|بيروت|بغداد|الدار البيضاء|تونس)\b/u,
  ];
  const hasLocation = locationPatterns.some(p => p.test(text));
  if (hasLocation) { score += 15; strengths.push(isAr ? '✓ الموقع الجغرافي محدد' : '✓ Geographic location specified'); }
  else { issues.push(isAr ? '⚠ حدد موقعك الجغرافي (المدينة/البلد)' : '⚠ Specify your geographic location (City/Country)'); }

  // Multiple contacts check
  const totalContactMethods = (hasValidEmail ? 1 : 0) + (validPhones.length > 0 ? 1 : 0) +
    (linkedinUrls.length > 0 ? 1 : 0) + (hasLocation ? 1 : 0);
  if (totalContactMethods >= 3) { score += 5; }

  score = Math.min(100, Math.max(0, score));

  return {
    score,
    feedback: issues.length > 0 ? issues.join('. ') : (isAr ? 'معلومات الاتصال كاملة ومتكاملة' : 'Contact information is complete and well-formatted'),
    issues: issues.slice(0, 5),
    strengths: strengths.slice(0, 4),
    criticalIssues: criticalIssues.slice(0, 3),
    details: {
      has_name: !!looksLikeName,
      email_count: emails.length,
      has_professional_email: hasProfessionalEmail,
      phone_count: validPhones.length,
      has_linkedin: linkedinUrls.length > 0,
      has_github: githubUrls.length > 0,
      has_location: hasLocation,
    },
  };
}

// ─── 2. STRUCTURE & FORMATTING ───
function analyzeStructure(text, lower, lines, words, wordCount, lineCount, isAr) {
  const issues = [];
  const strengths = [];
  const criticalIssues = [];
  let score = 0;

  // Detect which sections exist
  const detectedSections = {};
  for (const [key, patterns] of Object.entries(SECTION_PATTERNS)) {
    const found = patterns.some(p => lower.includes(p.toLowerCase()));
    detectedSections[key] = found;
  }
  const sectionCount = Object.values(detectedSections).filter(Boolean).length;

  // Section completeness (core sections required)
  const coreSections = ['experience', 'education', 'skills'];
  const coreFound = coreSections.filter(s => detectedSections[s]).length;
  const optionalSections = ['summary', 'certifications', 'projects', 'awards', 'languages'];
  const optionalFound = optionalSections.filter(s => detectedSections[s]).length;

  if (coreFound === 3) { score += 25; strengths.push(isAr ? '✓ الأقسام الأساسية موجودة (الخبرات، التعليم، المهارات)' : '✓ Core sections present (Experience, Education, Skills)'); }
  else if (coreFound === 2) { score += 15; issues.push(isAr ? '✗ قسم أساسي مفقود' : '✗ A core section is missing'); criticalIssues.push(coreFound < 2 ? (isAr ? 'أضف الأقسام الأساسية: الخبرات والتعليم والمهارات' : 'Add core sections: Experience, Education, Skills') : ''); }
  else { score += 3; criticalIssues.push(isAr ? 'السيرة تفتقر للأقسام الأساسية' : 'Resume lacks core sections'); }

  if (optionalFound >= 3) { score += 10; strengths.push(isAr ? '✓ أقسام إضافية مفيدة' : '✓ Helpful additional sections included'); }
  else if (optionalFound >= 1) { score += 5; }

  // Word count analysis
  if (wordCount >= 300 && wordCount <= 800) { score += 15; strengths.push(isAr ? '✓ طول مثالي (300-800 كلمة)' : '✓ Ideal length (300-800 words)'); }
  else if (wordCount >= 200 && wordCount <= 1200) { score += 10; }
  else if (wordCount >= 150 && wordCount <= 1500) { score += 5; }
  else if (wordCount < 150) { issues.push(isAr ? '✗ السيرة قصيرة جداً (أقل من 150 كلمة)' : '✗ Resume too short (<150 words)'); criticalIssues.push(isAr ? 'زد محتوى السيرة الذاتية' : 'Significantly expand resume content'); }
  else { issues.push(isAr ? '✗ السيرة طويلة جداً (أكثر من 1500 كلمة)' : '✗ Resume too long (>1500 words)'); }

  // Line count (approximate page count)
  if (lineCount >= 30 && lineCount <= 80) { score += 5; }
  else if (lineCount > 80) { issues.push(isAr ? '⚠ السيرة قد تتجاوز صفحتين' : '⚠ Resume may exceed 2 pages'); }

  // Bullet point analysis
  const bulletLines = lines.filter(l => /^\s*[•\-\*▪►◆→]\s/.test(l) || /^\s*\d+[.)]\s/.test(l));
  const bulletRatio = bulletLines.length / Math.max(lineCount - 5, 1);
  if (bulletLines.length >= 8) { score += 10; strengths.push(isAr ? `✓ ${bulletLines.length} نقطة إنجاز` : `✓ ${bulletLines.length} achievement bullets`); }
  else if (bulletLines.length >= 4) { score += 6; }
  else if (bulletLines.length < 3) { issues.push(isAr ? '✗ استخدم نقاط لعرض الإنجازات' : '✗ Use bullet points for achievements'); }

  // Date consistency
  const dateRanges = text.match(PATTERNS.date_range) || [];
  const singleDates = text.match(PATTERNS.single_date) || [];
  const totalDates = dateRanges.length + singleDates.length;
  if (dateRanges.length >= 3) { score += 10; strengths.push(isAr ? `✓ ${dateRanges.length} نطاقات زمنية واضحة` : `✓ ${dateRanges.length} clear date ranges`); }
  else if (totalDates >= 3) { score += 6; }
  else if (totalDates < 2) { issues.push(isAr ? '✗ التواريخ غير واضحة أو غير موجودة' : '✗ Dates unclear or missing'); }

  // Check for reverse chronological order heuristic
  const yearsInOrder = extractYearsAndCheckOrder(text);
  if (yearsInOrder.isReverseChronological) { score += 5; strengths.push(isAr ? '✓ ترتيب زمني عكسي' : '✓ Reverse chronological order'); }
  else if (yearsInOrder.hasDates) { issues.push(isAr ? '⚠ تأكد من الترتيب الزمني العكسي' : '⚠ Ensure reverse chronological order'); }

  // Section ordering (ideal: Summary → Experience → Education → Skills → Other)
  const sectionOrder = getSectionOrder(text);
  const idealOrderPenalty = calculateOrderPenalty(sectionOrder);
  score = Math.max(0, score - idealOrderPenalty);

  // Whitespace consistency
  const inconsistentSpacing = lines.filter(l => /^\s{2,}(?!\s|•|\-|\*|\d)/.test(l) && l.trim().length > 0).length;
  if (inconsistentSpacing > lineCount * 0.3) { issues.push(isAr ? '⚠ مسافات غير متناسقة' : '⚠ Inconsistent spacing detected'); }

  // All caps headers check
  const upperCaseHeaders = lines.filter(l => /^[A-Z\u0621-\u063A\s]{2,30}$/.test(l.trim()) && l.trim().length > 2 && l.trim().length < 30 && l.trim() === l.trim().toUpperCase()).length;
  if (upperCaseHeaders >= 3) { score += 3; }

  score = Math.min(100, Math.max(0, score));

  return {
    score,
    feedback: issues.length > 0 ? issues.join('. ') : (isAr ? 'الهيكل والتنسيق ممتازان' : 'Structure and formatting are excellent'),
    issues: issues.slice(0, 5),
    strengths: strengths.slice(0, 4),
    criticalIssues: criticalIssues.slice(0, 2),
    details: {
      sections_found: detectedSections,
      total_sections: sectionCount,
      core_sections_found: coreFound,
      optional_sections_found: optionalFound,
      word_count: wordCount,
      bullet_count: bulletLines.length,
      date_ranges_found: dateRanges.length,
      is_reverse_chronological: yearsInOrder.isReverseChronological,
    },
  };
}

// ─── 3. PROFESSIONAL SUMMARY ───
function analyzeSummary(text, lower, words, wordCount, isAr) {
  const issues = [];
  const strengths = [];
  const criticalIssues = [];
  let score = 0;

  const summarySection = extractSectionBetween(
    text,
    SECTION_PATTERNS.summary,
    [...SECTION_PATTERNS.experience, ...SECTION_PATTERNS.education, ...SECTION_PATTERNS.skills]
  );

  if (summarySection) {
    const summaryWords = getWords(summarySection);
    const summaryWordCount = summaryWords.length;

    // Presence
    score += 20;
    strengths.push(isAr ? '✓ قسم الملخص موجود' : '✓ Professional summary section exists');

    // Length check (ideal: 40-150 words)
    if (summaryWordCount >= 40 && summaryWordCount <= 150) { score += 30; strengths.push(isAr ? '✓ طول الملخص مثالي' : '✓ Summary length is optimal'); }
    else if (summaryWordCount >= 20 && summaryWordCount <= 200) { score += 20; }
    else if (summaryWordCount < 20) { score += 5; issues.push(isAr ? '⚠ الملخص قصير جداً' : '⚠ Summary too short - expand to 40-150 words'); }
    else { score += 10; issues.push(isAr ? '⚠ الملخص طويل - اختصره' : '⚠ Summary too long - condense it'); }

    // Check for value proposition keywords
    const valueKeywords = ['expertise', 'experience', 'specialized', 'proven track record', 'passionate',
      'dedicated', 'results-oriented', 'achievements', 'background', 'bringing',
      'خبرة', 'متخصص', 'مسجل', 'إنجازات', 'خلفية', 'شغوف'];
    const foundValueKeywords = valueKeywords.filter(k => lower.includes(k)).length;
    if (foundValueKeywords >= 2) { score += 20; strengths.push(isAr ? '✓ الملخص يقدم قيمة واضحة' : '✓ Summary presents clear value proposition'); }
    else { score += 10; issues.push(isAr ? '⚠ اجعل الملخص يركز على قيمتك المضافة' : '⚠ Make summary focus on your added value'); }

    // Check for numbers/metrics in summary
    const hasMetricsInSummary = PATTERNS.currency_metric
      ? PATTERNS.currency_metric.test(summarySection)
      : /\d+\+?\s*(?:years?|months?)|\d+%\s|(?:\$|€|£)?[\d,]+/i.test(summarySection);
    if (hasMetricsInSummary) { score += 15; strengths.push(isAr ? '✓ الملخص يحتوي أرقاماً' : '✓ Summary includes quantifiable metrics'); }
    else { issues.push(isAr ? '⚠ أضف أرقاماً للملخص (سنوات خبرة، إنجازات)' : '⚠ Add metrics to summary (years of experience, achievements)'); }

    // Avoid first person pronouns
    const firstPerson = /^(?:i\b|i'm|i have|my|me)/gm.test(summarySection.toLowerCase());
    if (!firstPerson) { score += 15; strengths.push(isAr ? '✓ بدون ضمائر المتكلم' : '✓ No first-person pronouns (professional style)'); }
    else { issues.push(isAr ? '⚠ تجنب استخدام "أنا" في الملخص' : '⚠ Avoid using "I" in summary - use implied subject'); }

  } else {
    // No summary section
    score = 15;
    issues.push(isAr ? '✗ لا يوجد ملخص مهني' : '✗ No professional summary section');
    criticalIssues.push(isAr ? 'أضف ملخصاً مهنياً (3-5 أسطر)' : 'Add a professional summary (3-5 lines)');
  }

  score = Math.min(100, Math.max(0, score));

  return {
    score,
    feedback: issues.length > 0 ? issues.join('. ') : (isAr ? 'الملخص الاحترافي ممتاز' : 'Professional summary is excellent'),
    issues: issues.slice(0, 4),
    strengths: strengths.slice(0, 3),
    criticalIssues: criticalIssues.slice(0, 2),
    details: {
      has_summary: !!summarySection,
      summary_word_count: summarySection ? getWords(summarySection).length : 0,
    },
  };
}

// ─── 4. WORK EXPERIENCE (Most Important Section) ───
function analyzeExperience(text, lower, lines, words, isAr) {
  const issues = [];
  const strengths = [];
  const criticalIssues = [];
  let score = 0;

  const expSection = extractSectionBetween(
    text,
    SECTION_PATTERNS.experience,
    [...SECTION_PATTERNS.education, ...SECTION_PATTERNS.skills, ...SECTION_PATTERNS.projects, ...SECTION_PATTERNS.education]
  );

  if (!expSection) {
    return {
      score: 5,
      feedback: isAr ? '✗ قسم الخبرات غير موجود - هذا أهم قسم في السيرة' : '✗ Experience section missing - this is the most important section',
      issues: [isAr ? 'قسم الخبرات مطلوب' : 'Experience section is required'],
      strengths: [],
      criticalIssues: [isAr ? 'أضف قسم الخبرات العملية مع تفاصيل الوظائف' : 'Add work experience section with job details'],
      details: { has_experience: false },
    };
  }

  score += 10;
  strengths.push(isAr ? '✓ قسم الخبرات موجود' : '✓ Work experience section exists');

  const expLines = expSection.split('\n').filter(l => l.trim().length > 0);
  const expWords = getWords(expSection);
  const expWordCount = expWords.length;

  // Depth of experience content
  if (expWordCount >= 200) { score += 10; strengths.push(isAr ? '✓ تفاصيل الخبرات شاملة' : '✓ Experience details are comprehensive'); }
  else if (expWordCount >= 100) { score += 6; }
  else { issues.push(isAr ? '✗ تفاصيل الخبرات قليلة - زد التفاصيل' : '✗ Limited experience details - expand each role'); }

  // Detect job entries (heuristic: lines starting with caps or containing common job title patterns)
  const jobTitlePatterns = [
    /^(?:Senior|Junior|Lead|Principal|Staff|Chief|Head|Director|VP|Vice President|Manager|Engineer|Developer|Designer|Analyst|Specialist|Consultant|Coordinator|Associate|Assistant|Executive|Officer|Representative|Agent)\b/im,
    /^(?:Senior|Junior|Lead|Principal|Staff|Chief|Head|Director|VP|Manager|Engineer|Developer|Designer|Analyst|Specialist|Consultant|Coordinator|Associate|Assistant|Executive|Officer|Representative|Agent)\b/im,
    /^\d{4}\s*[-–—]\s*/m,
  ];
  const potentialJobEntries = expLines.filter(l =>
    jobTitlePatterns.some(p => p.test(l)) ||
    (/^[A-Z][a-z]+ [A-Z][a-z]+/.test(l.trim()) && l.trim().split(/\s+/).length <= 8 && l.trim().length < 60)
  );
  const jobEntryCount = Math.max(potentialJobEntries.length, 1);

  if (jobEntryCount >= 3) { score += 10; strengths.push(isAr ? `✓ ${jobEntryCount} وظيفة مسجلة` : `✓ ${jobEntryCount} positions listed`); }
  else if (jobEntryCount >= 2) { score += 7; }
  else { score += 3; }

  // Power verbs analysis
  const powerVerbCounts = {};
  let totalPowerVerbs = 0;
  for (const [category, verbs] of Object.entries(POWER_VERBS)) {
    const count = verbs.filter(v => lower.includes(v)).length;
    if (count > 0) powerVerbCounts[category] = count;
    totalPowerVerbs += count;
  }

  if (totalPowerVerbs >= 10) { score += 15; strengths.push(isAr ? `✓ ${totalPowerVerbs} فعل قوي مستخدم` : `✓ ${totalPowerVerbs} power verbs used`); }
  else if (totalPowerVerbs >= 5) { score += 10; }
  else if (totalPowerVerbs >= 2) { score += 5; }
  else { issues.push(isAr ? '✗ استخدم أفعالاً قوية (Led, Developed, Achieved...)' : '✗ Use strong action verbs (Led, Developed, Achieved...)'); criticalIssues.push(isAr ? 'ابدأ كل نقطة بفعل قوي' : 'Start each bullet with a strong action verb'); }

  // Power verb diversity
  const verbCategories = Object.keys(powerVerbCounts).length;
  if (verbCategories >= 4) { score += 5; strengths.push(isAr ? '✓ تنوع في الأفعال القوية' : '✓ Diverse range of action verbs'); }

  // Quantifiable metrics
  let totalMetrics = 0;
  for (const pattern of PATTERNS.metric_patterns) {
    const matches = expSection.match(pattern);
    if (matches) totalMetrics += matches.length;
  }

  if (totalMetrics >= 6) { score += 15; strengths.push(isAr ? `✓ ${totalMetrics} مؤشر رقمي` : `✓ ${totalMetrics} quantifiable metrics`); }
  else if (totalMetrics >= 3) { score += 10; }
  else if (totalMetrics >= 1) { score += 5; }
  else { issues.push(isAr ? '✗ أرقام قابلة للقياس مفقودة' : '✗ Quantifiable metrics missing'); criticalIssues.push(isAr ? 'أضف أرقاماً (زاد المبيعات 30%， أدار فريق 10 أشخاص)' : 'Add numbers (Increased sales 30%, Managed team of 10)'); }

  // Weak/filler phrase detection
  const fillerCount = WEAK_PHRASES.filter(f => lower.includes(f)).length;
  if (fillerCount === 0) { score += 10; strengths.push(isAr ? '✓ بدون عبارات ضعيفة' : '✓ No weak/filler phrases detected'); }
  else if (fillerCount <= 2) { score -= 5; issues.push(isAr ? `⚠ ${fillerCount} عبارة ضعيفة - استبدلها بإنجازات` : `⚠ ${fillerCount} weak phrase(s) - replace with achievements`); }
  else { score -= Math.min(fillerCount * 4, 20); issues.push(isAr ? `✗ ${fillerCount} عبارة ضعيفة - هذه تضر بسيرتك` : `✗ ${fillerCount} weak phrases - these hurt your resume`); }

  // STAR method indicator (Situation, Task, Action, Result)
  const starIndicators = [
    /(?:resulted in|led to|caused|achieved|delivered|result|outcome|impact)/i,
    /(?:because of|due to|in response to|to address|to solve)/i,
    /(?:challenge|problem|opportunity|goal|target|objective)/i,
  ];
  const starMatches = starIndicators.filter(p => p.test(expSection)).length;
  if (starMatches >= 2) { score += 8; strengths.push(isAr ? '✓ أسلوب STAR في عرض الإنجازات' : '✓ STAR method approach in achievements'); }

  // Company name detection
  const companyPatterns = /\b(at|@)\s+([A-Z][A-Za-z0-9\s&']{2,30})\b|^(?:Worked at|Employed at|Working at)\s+([A-Z][A-Za-z\s']+)/im;
  const companyMatches = expSection.match(companyPatterns);
  if (companyMatches && companyMatches.length >= 2) { score += 5; strengths.push(isAr ? '✓ أسماء الشركات موضحة' : '✓ Company names clearly indicated'); }

  // Date ranges in experience
  const expDateRanges = expSection.match(PATTERNS.date_range) || [];
  if (expDateRanges.length >= jobEntryCount) { score += 7; }
  else if (expDateRanges.length >= 1) { score += 3; }
  else { issues.push(isAr ? '⚠ أضف تواريخ لكل وظيفة' : '⚠ Add date ranges for each position'); }

  // Promotion indicators
  const promotionPatterns = /promoted to|promoted from|promotion|advanced to|moved up|elevated to|ترقية|تمت ترقيتي/i;
  if (promotionPatterns.test(expSection)) { score += 5; strengths.push(isAr ? '✓ مؤشرات ترقية موجودة' : '✓ Promotion indicators present'); }

  // Experience gap detection (basic)
  const years = extractYearsFromText(expSection);
  if (years.length >= 4) {
    const sortedYears = [...years].sort((a, b) => a - b);
    const maxGap = findMaxYearGap(sortedYears);
    if (maxGap > 2) { issues.push(isAr ? `⚠ فجوة زمنية ~${Math.round(maxGap)} سنوات في الخبرة` : `⚠ Experience gap of ~${Math.round(maxGap)} years detected`); }
  }

  score = Math.min(100, Math.max(0, score));

  return {
    score,
    feedback: issues.length > 0 ? issues.join('. ') : (isAr ? 'الخبرات والإنجازات ممتازة' : 'Experience and achievements are excellent'),
    issues: issues.slice(0, 6),
    strengths: strengths.slice(0, 5),
    criticalIssues: criticalIssues.slice(0, 3),
    details: {
      has_experience: true,
      experience_word_count: expWordCount,
      job_entries_detected: jobEntryCount,
      power_verbs_total: totalPowerVerbs,
      power_verb_categories: verbCategories,
      metrics_count: totalMetrics,
      filler_phrases: fillerCount,
      star_method_indicators: starMatches,
    },
  };
}

// ─── 5. EDUCATION ───
function analyzeEducation(text, lower, lines, isAr) {
  const issues = [];
  const strengths = [];
  const criticalIssues = [];
  let score = 0;

  const eduSection = extractSectionBetween(
    text,
    SECTION_PATTERNS.education,
    [...SECTION_PATTERNS.skills, ...SECTION_PATTERNS.experience, ...SECTION_PATTERNS.certifications, ...SECTION_PATTERNS.projects]
  );

  if (!eduSection) {
    // Check if degree keywords appear anywhere
    const degreeAnywhere = Object.values(DEGREE_LEVELS).flat().some(d => lower.includes(d.toLowerCase()));
    if (degreeAnywhere) {
      score = 30;
      issues.push(isAr ? '⚠ التعليم موجود لكن بدون قسم مخصص' : '⚠ Education info exists but no dedicated section');
    } else {
      score = 10;
      issues.push(isAr ? '✗ لا يوجد تعليم' : '✗ No education information found');
      criticalIssues.push(isAr ? 'أضف قسم التعليم مع الدرجة والجامعة' : 'Add education section with degree and institution');
    }
    return {
      score,
      feedback: issues[0] || '',
      issues,
      strengths: [],
      criticalIssues,
      details: { has_education: false },
    };
  }

  score += 20;
  strengths.push(isAr ? '✓ قسم التعليم موجود' : '✓ Education section exists');

  // Degree level detection
  let maxDegreeLevel = 0;
  const detectedDegrees = {};
  for (const [level, patterns] of Object.entries(DEGREE_LEVELS)) {
    const found = patterns.some(p => lower.includes(p.toLowerCase()));
    if (found) {
      detectedDegrees[level] = true;
      if (level === 'doctoral') maxDegreeLevel = 5;
      else if (level === 'masters' && maxDegreeLevel < 5) maxDegreeLevel = 4;
      else if (level === 'bachelors' && maxDegreeLevel < 4) maxDegreeLevel = 3;
      else if (level === 'associate' && maxDegreeLevel < 3) maxDegreeLevel = 2;
      else if (level === 'high_school' && maxDegreeLevel < 2) maxDegreeLevel = 1;
    }
  }

  if (maxDegreeLevel >= 3) { score += 25; strengths.push(isAr ? '✓ درجة جامعية' : '✓ University degree detected'); }
  else if (maxDegreeLevel >= 2) { score += 15; }
  else if (maxDegreeLevel >= 1) { score += 8; }
  else { issues.push(isAr ? '⚠ لم يتم تحديد المستوى الأكاديمي' : '⚠ Could not determine academic level'); }

  // Institution detection
  const institutionPatterns = /\b(?:university|college|institute|academy|school|جامعة|كلية|معهد|أكاديمية)\b/i;
  if (institutionPatterns.test(eduSection)) { score += 15; strengths.push(isAr ? '✓ اسم المؤسسة التعليمية موجود' : '✓ Educational institution named'); }
  else { issues.push(isAr ? '⚠ حدد اسم الجامعة/الكلية' : '⚠ Specify university/college name'); }

  // GPA detection
  const gpaMatch = eduSection.match(PATTERNS.gpa);
  if (gpaMatch) {
    const gpaVal = parseFloat(gpaMatch[1] || gpaMatch[2]);
    if (gpaVal >= 3.5) { score += 10; strengths.push(isAr ? `✓ GPA ممتاز (${gpaVal})` : `✓ Excellent GPA (${gpaVal})`); }
    else if (gpaVal >= 3.0) { score += 7; strengths.push(isAr ? `✓ GPA جيد (${gpaVal})` : `✓ Good GPA (${gpaVal})`); }
    else { score += 3; }
  }

  // Graduation year/date
  const eduDates = eduSection.match(PATTERNS.single_date) || [];
  if (eduDates.length > 0) { score += 10; }
  else { issues.push(isAr ? '⚠ أضف سنة التخرج' : '⚠ Add graduation year'); }

  // Relevant coursework or honors
  const honors = /(?:dean\'s list|honors|magna cum laude|summa cum laude|cum laude|distinction|merit|قائمة الشرف|امتياز)/i.test(eduSection);
  if (honors) { score += 10; strengths.push(isAr ? '✓ تكريمات أكاديمية' : '✓ Academic honors mentioned'); }

  score = Math.min(100, Math.max(0, score));

  return {
    score,
    feedback: issues.length > 0 ? issues.join('. ') : (isAr ? 'قسم التعليم مكتمل' : 'Education section is complete'),
    issues: issues.slice(0, 4),
    strengths: strengths.slice(0, 4),
    criticalIssues: criticalIssues.slice(0, 2),
    details: {
      has_education: true,
      degree_level: maxDegreeLevel,
      detected_degrees: detectedDegrees,
      has_gpa: !!gpaMatch,
      graduation_dates: eduDates.length,
    },
  };
}

// ─── 6. SKILLS & KEYWORDS ───
function analyzeSkills(text, lower, words, wordCount, isAr) {
  const issues = [];
  const strengths = [];
  const criticalIssues = [];
  let score = 0;

  // Extract skills section
  const skillsSection = extractSectionBetween(
    text,
    SECTION_PATTERNS.skills,
    [...SECTION_PATTERNS.experience, ...SECTION_PATTERNS.education, ...SECTION_PATTERNS.certifications, ...SECTION_PATTERNS.languages]
  );

  // Categorize found skills
  const foundSkillsByCategory = {};
  let totalFoundSkills = 0;
  const foundSkillNames = [];

  // Helper: safely escape string for regex
  const escapeRegex = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  for (const [category, skills] of Object.entries(SKILL_CATEGORIES)) {
    const found = skills.filter(skill => {
      const escaped = escapeRegex(skill);
      const regex = new RegExp(escaped, 'i');
      return regex.test(lower);
    });
    if (found.length > 0) {
      foundSkillsByCategory[category] = found;
      totalFoundSkills += found.length;
      foundSkillNames.push(...found);
    }
  }

  // Skills section existence
  if (skillsSection) {
    score += 15;
    strengths.push(isAr ? '✓ قسم المهارات موجود' : '✓ Skills section exists');

    // Count individual skill items
    const skillItems = skillsSection.split(/[,;|\n•\-\/]/).map(s => s.trim()).filter(s => s.length > 1 && s.length < 40);
    if (skillItems.length >= 10) { score += 15; strengths.push(isAr ? `✓ ${skillItems.length} مهارة مدرجة` : `✓ ${skillItems.length} skills listed`); }
    else if (skillItems.length >= 5) { score += 10; }
    else { issues.push(isAr ? '⚠ زد عدد المهارات (8-15 مهارة)' : '⚠ List more skills (8-15 skills)'); }
  } else {
    issues.push(isAr ? '⚠ لا يوجد قسم مهارات منفصل' : '⚠ No dedicated skills section');
  }

  // Total skills found across entire resume
  if (totalFoundSkills >= 10) { score += 20; strengths.push(isAr ? `✓ ${totalFoundSkills} مهارة تقنية/مهنية` : `✓ ${totalFoundSkills} technical/professional skills`); }
  else if (totalFoundSkills >= 5) { score += 14; }
  else if (totalFoundSkills >= 2) { score += 8; }
  else { issues.push(isAr ? '✗ مهارات تقنية قليلة جداً' : '✗ Very few technical skills detected'); }

  // Category diversity
  const categoryCount = Object.keys(foundSkillsByCategory).length;
  if (categoryCount >= 4) { score += 10; strengths.push(isAr ? `✓ مهارات في ${categoryCount} مجالات مختلفة` : `✓ Skills across ${categoryCount} different categories`); }
  else if (categoryCount >= 2) { score += 6; }
  else if (totalFoundSkills > 0) { issues.push(isAr ? '⚠ تنوع المهارات محدود' : '⚠ Limited skill diversity'); }

  // Key category bonuses
  if (foundSkillsByCategory.programming_languages?.length >= 2) { score += 3; }
  if (foundSkillsByCategory.cloud_devops?.length >= 2) { score += 3; }
  if (foundSkillsByCategory.data_ai?.length >= 2) { score += 3; }
  if (foundSkillsByCategory.project_management?.length >= 2) { score += 2; }
  if (foundSkillsByCategory.soft_skills?.length >= 3) { score += 2; }

  // Certifications
  const certPatterns = /(?:certified|certification|certificate|license|aws certified|google certified|pmp|cfa|cpa|cism|cissp|sha|معتمد|شهادة)/i;
  const hasCertifications = certPatterns.test(text);
  if (hasCertifications) { score += 10; strengths.push(isAr ? '✓ شهادات مهنية موجودة' : '✓ Professional certifications present'); }

  // Languages
  const langPatterns = /(?:english|arabic|french|spanish|german|chinese|japanese|russian|fluent|proficient|native|bilingual|trilingual|الإنجليزية|العربية|الفرنسية|إسباني)/i;
  const langMatch = text.match(langPatterns);
  if (langMatch && langMatch.length >= 2) { score += 5; }

  // Keyword density analysis
  const uniqueWords = new Set(words.map(w => w.toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]/g, '')));
  const density = uniqueWords.size / Math.max(wordCount, 1);
  if (density >= 0.35 && density <= 0.65) { score += 5; }
  else if (density < 0.25) { issues.push(isAr ? '⚠ كلمات مكررة كثيراً - زد التنوع' : '⚠ High repetition - increase vocabulary diversity'); }

  // Keyword stuffing detection
  const skillFrequencyMap = {};
  for (const skill of foundSkillNames) {
    const normalized = skill.toLowerCase();
    skillFrequencyMap[normalized] = (skillFrequencyMap[normalized] || 0) + 1;
  }
  const stuffedSkills = Object.values(skillFrequencyMap).filter(c => c > 3).length;
  if (stuffedSkills > 2) { score -= 10; issues.push(isAr ? '⚠ تكرار مفرط لكلمات مفتاحية' : '⚠ Excessive keyword repetition detected'); }

  score = Math.min(100, Math.max(0, score));

  return {
    score,
    feedback: issues.length > 0 ? issues.join('. ') : (isAr ? 'المهارات والكلمات المفتاحية ممتازة' : 'Skills and keywords are excellent'),
    issues: issues.slice(0, 5),
    strengths: strengths.slice(0, 5),
    criticalIssues: criticalIssues.slice(0, 2),
    details: {
      total_skills_found: totalFoundSkills,
      skills_by_category: Object.fromEntries(
        Object.entries(foundSkillsByCategory).map(([k, v]) => [k, v.length])
      ),
      category_diversity: categoryCount,
      has_certifications: hasCertifications,
      has_dedicated_section: !!skillsSection,
    },
  };
}

// ─── 7. ATS TECHNICAL COMPATIBILITY ───
function analyzeATSCompatibility(text, lower, lines, isAr) {
  const issues = [];
  const strengths = [];
  const criticalIssues = [];
  let score = 100; // Start perfect, deduct for problems
  const killersDetected = [];
  const lineCount = lines.length; // Compute from lines array

  // Check each ATS killer element
  for (const [name, killer] of Object.entries(ATS_KILLERS)) {
    if (killer.pattern.test(text)) {
      score -= killer.penalty;
      killersDetected.push({ name, penalty: killer.penalty, msg: killer.msg });
      if (killer.penalty >= 20) {
        criticalIssues.push(isAr ? `🔴 ${killer.msg}` : `🔴 ${killer.msg}`);
      } else {
        issues.push(isAr ? `⚠️ ${killer.msg}` : `⚠️ ${killer.msg}`);
      }
    }
  }

  // File-parseability score
  const parseabilityIssues = [];

  // Check for control characters
  const controlChars = text.match(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g);
  if (controlChars && controlChars.length > 0) {
    score -= Math.min(controlChars.length * 2, 15);
    parseabilityIssues.push(`${controlChars.length} control characters`);
  }

  // Check for excessive blank lines
  const blankLineGroups = (text.match(/\n{3,}/g) || []).length;
  if (blankLineGroups > 3) { score -= 3; }

  // Check very long lines (might indicate columns)
  const longLines = lines.filter(l => l.trim().length > 120).length;
  if (longLines > lineCount * 0.3) {
    score -= 10;
    issues.push(isAr ? '⚠ خطوط طويلة قد تشير إلى تخطيط متعدد الأعمدة' : '⚠ Long lines may indicate multi-column layout');
  }

  // Standard section headers (ATS-friendly)
  const standardHeaders = ['experience', 'education', 'skills', 'summary', 'certifications'];
  const standardHeaderCount = standardHeaders.filter(h => lower.includes(h)).length;
  if (standardHeaderCount >= 4) { strengths.push(isAr ? '✓ عناوين أقسام قياسية (ATS-friendly)' : '✓ Standard section headers (ATS-friendly)'); }
  else if (standardHeaderCount < 3) { issues.push(isAr ? '⚠ استخدم عناوين أقسام قياسية' : '⚠ Use standard section headers'); }

  // Date format consistency
  const dateFormats = [];
  if (/\d{1,2}\/\d{4}/.test(text)) dateFormats.push('MM/YYYY');
  if (/(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s*\d{4}/i.test(text)) dateFormats.push('Month YYYY');
  if (/\d{4}\s*[-–—]\s*\d{4}/.test(text)) dateFormats.push('YYYY-YYYY');
  if (dateFormats.length <= 1 && dateFormats.length > 0) { score += 5; strengths.push(isAr ? '✓ تنسيق تواريقي موحد' : '✓ Consistent date format'); }
  else if (dateFormats.length > 2) { score -= 3; issues.push(isAr ? '⚠ تنسيقات تواريخ متعددة -وحدها' : '⚠ Multiple date formats - standardize'); }

  // Email in body (not just header)
  const emailInBody = lower.indexOf('@') > lower.indexOf('\n');
  if (emailInBody) { score += 3; }

  // Overall text quality
  const alphaRatio = (text.replace(/[^a-zA-Z\u0600-\u06FF]/g, '').length) / Math.max(text.length, 1);
  if (alphaRatio > 0.85) { score += 3; strengths.push(isAr ? '✓ نص نظيف وقابل للتحليل' : '✓ Clean, analyzable text'); }
  else if (alphaRatio < 0.5) { score -= 10; issues.push(isAr ? '⚠ نسبة نص منخفضة - قد تكون صور' : '⚠ Low text ratio - may contain images'); }

  score = Math.min(100, Math.max(0, score));

  return {
    score,
    feedback: issues.length > 0 ? issues.join('. ') : (isAr ? 'السيرة متوافقة تماماً مع ATS' : 'Fully ATS-compatible'),
    issues: issues.slice(0, 6),
    strengths: strengths.slice(0, 4),
    criticalIssues: criticalIssues.slice(0, 4),
    details: {
      ats_killers_detected: killersDetected,
      parseability_issues: parseabilityIssues,
      date_formats_found: dateFormats,
      text_quality_ratio: Math.round(alphaRatio * 100),
    },
  };
}

// ─── HELPER FUNCTIONS ───

function extractYearsFromText(text) {
  const matches = text.match(/\b(19|20)\d{2}\b/g) || [];
  return matches.map(y => parseInt(y)).filter(y => y >= 1950 && y <= new Date().getFullYear() + 1);
}

function extractYearsAndCheckOrder(text) {
  const years = extractYearsFromText(text);
  if (years.length < 3) return { hasDates: years.length > 0, isReverseChronological: true };

  // Simple check: do years generally decrease as we go through the document?
  const positions = [];
  const regex = /\b(19|20)\d{2}\b/g;
  let match;
  while ((match = regex.exec(text)) !== null) {
    positions.push({ year: parseInt(match[0]), pos: match.index });
  }

  if (positions.length < 3) return { hasDates: true, isReverseChronological: true };

  // Check if majority of consecutive pairs are descending
  let descendingCount = 0;
  let ascendingCount = 0;
  for (let i = 0; i < positions.length - 1; i++) {
    // Only compare if they're reasonably close (same section likely)
    if (positions[i + 1].pos - positions[i].pos < 500) {
      if (positions[i].year >= positions[i + 1].year) descendingCount++;
      else ascendingCount++;
    }
  }

  return {
    hasDates: true,
    isReverseChronological: descendingCount >= ascendingCount,
  };
}

function findMaxYearGap(sortedYears) {
  let maxGap = 0;
  for (let i = 1; i < sortedYears.length; i++) {
    const gap = sortedYears[i] - sortedYears[i - 1];
    if (gap > maxGap) maxGap = gap;
  }
  return maxGap;
}

function getSectionOrder(text) {
  const lower = text.toLowerCase();
  const order = [];
  for (const [key, patterns] of Object.entries(SECTION_PATTERNS)) {
    for (const p of patterns) {
      const idx = lower.indexOf(p.toLowerCase());
      if (idx !== -1) {
        order.push({ section: key, position: idx });
        break;
      }
    }
  }
  return order.sort((a, b) => a.position - b.position).map(o => o.section);
}

function calculateOrderPenalty(sectionOrder) {
  // Ideal order: summary → experience → education → skills → other
  const idealOrder = ['summary', 'experience', 'education', 'skills'];
  let penalty = 0;

  for (let i = 0; i < idealOrder.length - 1; i++) {
    const currentIdx = sectionOrder.indexOf(idealOrder[i]);
    const nextIdx = sectionOrder.indexOf(idealOrder[i + 1]);
    if (currentIdx !== -1 && nextIdx !== -1 && currentIdx > nextIdx) {
      penalty += 3;
    }
  }

  return penalty;
}

function generateVerdict(score, sections, isAr) {
  let level, text;

  // Find weakest section
  const sortedSections = Object.entries(sections)
    .sort(([, a], [, b]) => a.score - b.score);
  const weakest = sortedSections[0];
  const strongest = sortedSections[sortedSections.length - 1];

  if (score >= 90) {
    level = 'excellent';
    text = isAr
      ? `🏆 ممتاز! سيرتك الذاتية في أفضل حالة. النتيجة ${score}% تعني أن فرصك في تجاوز أي نظام ATS عالية جداً. أضعف نقطة هي "${weakest[0]}" (${weakest[1].score}%) - يمكن تحسينها للمثالية.`
      : `🏆 Excellent! Your resume is in top shape. A ${score}% score means you're highly likely to pass any ATS system. Your weakest area is "${weakest[0]}" (${weakest[1].score}%) - could be improved for perfection.`;
  } else if (score >= 78) {
    level = 'very_good';
    text = isAr
      ? `✨ جيد جداً! نتيجة ${score}% جيدة. سيرتك متوافقة مع معظم أنظمة ATS. ركّز على تحسين "${weakest[0]}" (${weakest[1].score}%) للحصول على نتيجة أفضل.`
      : `✨ Very Good! At ${score}%, your resume is compatible with most ATS systems. Focus on improving "${weakest[0]}" (${weakest[1].score}%) for an even better score.`;
  } else if (score >= 65) {
    level = 'good';
    text = isAr
      ? `👍 جيد. نتيجة ${score}% مقبولة لكن هناك مجال للتحسين. الأقسام التي تحتاج اهتمام: ${sortedSections.filter(([, s]) => s.score < 65).map(([k]) => k).join(', ')}.`
      : `👍 Good. A ${score}% score is acceptable but there's room for improvement. Areas needing attention: ${sortedSections.filter(([, s]) => s.score < 65).map(([k]) => k).join(', ')}.`;
  } else if (score >= 50) {
    level = 'fair';
    level = 'needs_work';
    text = isAr
      ? `⚠️ يحتاج عمل. نتيجة ${score}% تعني أن سيرتك قد تُرفض من قبل العديد من أنظمة ATS. الأولوية: ${sortedSections.filter(([, s]) => s.score < 55).map(([k], i) => `${i + 1}. ${k}`).join(', ')}.`
      : `⚠️ Needs Work. At ${score}%, your resume may be rejected by many ATS systems. Priority fixes: ${sortedSections.filter(([, s]) => s.score < 55).map(([k], i) => `${i + 1}. ${k}`).join(', ')}.`;
  } else if (score >= 35) {
    level = 'poor';
    text = isAr
      ? `❌ ضعيف. نتيجة ${score}% خطيرة. سيرتك لن تتجاوز غالبية أنظمة ATS. تحتاج إعادة كتابة شاملة مع التركيز على: ${weakest[0]}, ${sortedSections[1][0]}, ${sortedSections[2][0]}.`
      : `❌ Poor. A ${score}% score is concerning. Your resume won't pass most ATS systems. Comprehensive rewrite needed focusing on: ${weakest[0]}, ${sortedSections[1][0]}, ${sortedSections[2][0]}.`;
  } else {
    level = 'critical';
    text = isAr
      ? `🚨 حرج! نتيجة ${score}% تعني أن السيرة ستُرفض فوراً من أي نظام ATS. يجب إعادة بناء السيرة بالكامل.`
      : `🚨 Critical! At ${score}%, your resume will be instantly rejected by any ATS system. Complete rebuild required.`;
  }

  return { level, text };
}

// ════════════════════════════════════════════════════════
// API HANDLER
// ════════════════════════════════════════════════════════
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { text, language, user_id } = req.body;
    if (!text || text.trim().length < 20) {
      return res.status(400).json({ error: 'Resume text is too short (minimum 20 characters)' });
    }

    const startTime = Date.now();
    const result = analyzeResume(text.trim(), language || 'en');
    const processingTime = Date.now() - startTime;

    result.metadata.processing_time_ms = processingTime;

    // Save to database if user_id provided
    if (user_id) {
      await supabase.from('ats_scans').insert({
        user_id,
        score: result.overall_score,
        result: result,
      }).catch(() => {});
    }

    return res.status(200).json(result);
  } catch (err) {
    console.error('ATS scan error:', err);
    return res.status(500).json({ error: err.message });
  }
}
