import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { event_type, event_data, session_id } = req.body;
      const { error } = await supabase
        .from('tracking_events')
        .insert({ event_type, event_data, session_id });
      if (error) throw error;
      // Also increment stats counters
      if (event_type === 'cv_upload') {
        await supabase.rpc('increment_stat', { stat_key: 'cvs_today' }).catch(() => {});
        await supabase.rpc('increment_stat', { stat_key: 'cvs_optimized' }).catch(() => {});
      }
      return res.status(201).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}