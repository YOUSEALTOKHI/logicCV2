import { useState, useCallback, useEffect } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { useAuth } from "@/lib/auth/auth-context"
import { supabase } from "@/integrations/supabase/client"
import {
  Upload, FileText, CheckCircle2, AlertTriangle, XCircle, Loader2,
  Sparkles, Lock, CreditCard, Shield, Target, TrendingUp, Brain,
  FileSearch, BarChart3, Zap, Award, AlertOctagon, ChevronDown, ChevronUp,
  User, Layout, BookOpen, Wrench, GraduationCap, Cpu
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useLanguage } from "@/lib/i18n/language-context"
import { Link } from "react-router-dom"
import { motion, AnimatePresence } from "framer-motion"

interface SectionDetail {
  score: number
  feedback: string
  issues?: string[]
  strengths?: string[]
  criticalIssues?: string[]
  details?: Record<string, any>
}

interface ATSResult {
  overall_score: number
  language_detected: string
  sections: Record<string, SectionDetail>
  improvements: string[]
  strengths: string[]
  ats_compatibility: string
  compatibility_level: string
  metadata: {
    word_count: number
    line_count: number
    character_count: number
    analyzed_at: string
    engine_version: string
    processing_time_ms?: number
  }
}

const sectionIcons: Record<string, React.ReactNode> = {
  contact_information: <User className="w-4 h-4" />,
  formatting_structure: <Layout className="w-4 h-4" />,
  professional_summary: <FileText className="w-4 h-4" />,
  work_experience: <TrendingUp className="w-4 h-4" />,
  education: <GraduationCap className="w-4 h-4" />,
  skills_keywords: <Wrench className="w-4 h-4" />,
  ats_compatibility: <Cpu className="w-4 h-4" />,
}

const sectionLabelsAr: Record<string, string> = {
  contact_information: 'معلومات الاتصال',
  formatting_structure: 'الهيكل والتنسيق',
  professional_summary: 'الملخص المهني',
  work_experience: 'الخبرات العملية',
  education: 'التعليم',
  skills_keywords: 'المهارات والكلمات المفتاحية',
  ats_compatibility: 'توافق ATS التقني',
}

const sectionLabelsEn: Record<string, string> = {
  contact_information: 'Contact Information',
  formatting_structure: 'Structure & Formatting',
  professional_summary: 'Professional Summary',
  work_experience: 'Work Experience',
  education: 'Education',
  skills_keywords: 'Skills & Keywords',
  ats_compatibility: 'ATS Technical Compatibility',
}

export default function ATSScannerPage() {
  const { user, plan } = useAuth()
  const { toast } = useToast()
  const { language } = useLanguage()
  const isAr = language === "ar"
  const labels = isAr ? sectionLabelsAr : sectionLabelsEn

  const [resumeText, setResumeText] = useState("")
  const [loading, setLoading] = useState(false)
  const [fileLoading, setFileLoading] = useState(false)
  const [uploadedFileName, setUploadedFileName] = useState("")
  const [result, setResult] = useState<ATSResult | null>(null)
  const [scanCount, setScanCount] = useState(0)
  const [expandedSection, setExpandedSection] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      supabase.from("ats_scans").select("id", { count: "exact", head: true }).eq("user_id", user.id).then(({ count }: any) => {
        setScanCount(count ?? 0)
      })
    }
  }, [user])

  const canScan = plan === "pro" || plan === "premium" || scanCount < 3

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    e.target.value = ""
    setFileLoading(true)
    try {
      const text = await file.text()
      const cleaned = text.replace(/\s+/g, " ").trim()
      if (!cleaned || cleaned.length < 20) {
        toast({ title: isAr ? "لم يتم العثور على نص" : "No text found", description: isAr ? "الملف فارغ أو يحتوي على صور فقط. الصق النص مباشرة." : "File is empty or contains only images. Paste text directly.", variant: "destructive" })
        return
      }
      setResumeText(cleaned)
      setUploadedFileName(file.name)
      toast({ title: isAr ? "تم استخراج النص بنجاح" : "Text extracted successfully" })
    } catch {
      toast({ title: isAr ? "خطأ في قراءة الملف" : "Error reading file", variant: "destructive" })
    } finally {
      setFileLoading(false)
    }
  }

  const handleScan = useCallback(async () => {
    if (!resumeText.trim() || !user) return
    if (!canScan) {
      toast({ title: isAr ? "تم استنفاد الفحوصات المجانية" : "Free scans used", description: isAr ? "اشترك في باقة للحصول على فحوصات غير محدودة" : "Subscribe to a plan for unlimited scans", variant: "destructive" })
      return
    }

    setLoading(true)
    setResult(null)
    setExpandedSection(null)

    try {
      const response = await fetch('/api/ats-scan', {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: resumeText,
          language,
          user_id: user.id,
        }),
      })

      if (!response.ok) {
        const errorBody = await response.text()
        throw new Error(errorBody || "Failed to analyze")
      }

      const parsed = await response.json()
      setResult(parsed)
      setScanCount(prev => prev + 1)
    } catch (err: any) {
      toast({ title: isAr ? "خطأ في التحليل" : "Analysis Error", description: err.message || (isAr ? "حاول مرة أخرى" : "Please try again"), variant: "destructive" })
    } finally {
      setLoading(false)
    }
  }, [resumeText, user, canScan, language, isAr, toast])

  // ─── Score Color Helpers ───
  const getScoreColor = (score: number) => {
    if (score >= 80) return { text: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-500", border: "border-emerald-500/30", light: "#10b981" }
    if (score >= 65) return { text: "text-blue-600 dark:text-blue-400", bg: "bg-blue-500", border: "border-blue-500/30", light: "#3b82f6" }
    if (score >= 50) return { text: "text-amber-600 dark:text-amber-400", bg: "bg-amber-500", border: "border-amber-500/30", light: "#f59e0b" }
    if (score >= 35) return { text: "text-orange-600 dark:text-orange-400", bg: "bg-orange-500", border: "border-orange-500/30", light: "#f97316" }
    return { text: "text-red-600 dark:text-red-400", bg: "bg-red-500", border: "border-red-500/30", light: "#ef4444" }
  }

  const getScoreIcon = (score: number) => {
    if (score >= 78) return <CheckCircle2 className="w-5 h-5 text-emerald-500" />
    if (score >= 55) return <AlertTriangle className="w-5 h-5 text-amber-500" />
    return <XCircle className="w-5 h-5 text-red-500" />
  }

  const getCompatibilityBadge = (level: string) => {
    switch (level) {
      case 'excellent': return { color: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300', icon: <Award className="w-3.5 h-3.5" />, label: isAr ? 'ممتاز' : 'Excellent' }
      case 'very_good': return { color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300', icon: <Zap className="w-3.5 h-3.5" />, label: isAr ? 'جيد جداً' : 'Very Good' }
      case 'good': return { color: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900/40 dark:text-cyan-300', icon: <Target className="w-3.5 h-3.5" />, label: isAr ? 'جيد' : 'Good' }
      case 'needs_work': return { color: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300', icon: <AlertTriangle className="w-3.5 h-3.5" />, label: isAr ? 'يحتاج عمل' : 'Needs Work' }
      case 'poor': return { color: 'bg-orange-100 text-orange-800 dark:bg-orange-900/40 dark:text-orange-300', icon: <AlertOctagon className="w-3.5 h-3.5" />, label: isAr ? 'ضعيف' : 'Poor' }
      case 'critical': return { color: 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300', icon: <XCircle className="w-3.5 h-3.5" />, label: isAr ? 'حرج' : 'Critical' }
      default: return { color: 'bg-gray-100 text-gray-800', icon: <Shield className="w-3.5 h-3.5" />, label: level }
    }
  }

  // ─── Score Ring Component ───
  const ScoreRing = ({ score, size = 140 }: { score: number; size?: number }) => {
    const colors = getScoreColor(score)
    const radius = (size - 16) / 2
    const circumference = 2 * Math.PI * radius
    const offset = circumference - (score / 100) * circumference

    return (
      <div className="relative flex items-center justify-center">
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="currentColor" strokeWidth="8" className="text-muted/30" />
          <circle
            cx={size / 2} cy={size / 2} r={radius} fill="none"
            stroke={colors.light}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            className="transition-all duration-1500 ease-out"
          />
        </svg>
        <div className="absolute flex flex-col items-center">
          <span className={`text-3xl font-black ${colors.text}`}>{score}</span>
          <span className="text-[10px] text-muted-foreground font-medium">/100</span>
        </div>
      </div>
    )
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
              <Brain className="w-8 h-8 text-primary" />
              {isAr ? "فحص ATS احترافي للسيرة الذاتية" : "Professional ATS Resume Scanner"}
            </h1>
            <p className="text-muted-foreground mt-1.5 max-w-2xl">
              {isAr
                ? "محرك تحليل متقدم مبني على معايير أنظمة: Taleo • Workday • Greenhouse • Lever • iCIMS — أكثر من 150 معيار تقييم"
                : "Advanced analysis engine based on: Taleo • Workday • Greenhouse • Lever • iCIMS — 150+ evaluation criteria"}
            </p>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="outline" className="text-xs font-mono">
                <Shield className="w-3 h-3 mr-1" /> Engine v4.0 Enterprise
              </Badge>
              <Badge variant="outline" className="text-xs">
                <FileSearch className="w-3 h-3 mr-1" /> {isAr ? '150+ معيار' : '150+ Criteria'}
              </Badge>
              <Badge variant="outline" className="text-xs">
                <BarChart3 className="w-3 h-3 mr-1" /> {isAr ? '7 أقسام تحليل' : '7 Analysis Sections'}
              </Badge>
            </div>
          </div>

          {/* Plan badge */}
          {plan === "free" && (
            <Badge variant="outline" className="shrink-0">
              {isAr ? `${Math.max(0, 3 - scanCount)} فحص مجاني` : `${Math.max(0, 3 - scanCount)} free scans`}
            </Badge>
          )}
          {(plan === "pro" || plan === "premium") && (
            <Badge className="shrink-0 bg-gradient-to-r from-primary to-purple-600 text-white border-0">
              <Sparkles className="w-3.5 h-3.5 mr-1" />
              {isAr ? "فحوصات غير محدودة ∞" : "Unlimited Scans ∞"}
            </Badge>
          )}
        </div>

        {/* Paywall */}
        {plan === "free" && !canScan && (
          <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-purple-500/5">
            <CardContent className="py-10 text-center space-y-4">
              <Lock className="w-16 h-16 mx-auto text-primary/60" />
              <h2 className="text-xl font-bold">{isAr ? "لقد استخدمت فحوصاتك المجانية الثلاث" : "You've used your 3 free scans"}</h2>
              <p className="text-muted-foreground max-w-md mx-auto text-sm">
                {isAr ? "قم بترقية باقتك للحصول على فحوصات غير محدودة مع تحليل تفصيلي شامل." : "Upgrade your plan for unlimited ATS scans with comprehensive detailed analysis."}
              </p>
              <Link to="/dashboard/subscription">
                <Button className="gap-2 bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90">
                  <CreditCard className="w-4 h-4" />
                  {isAr ? "ترقية الباقة" : "Upgrade Plan"}
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Main Content Grid */}
        <div className={`grid grid-cols-1 lg:grid-cols-2 gap-6 ${plan === "free" && !canScan ? "opacity-50 pointer-events-none" : ""}`}>
          {/* Input Panel */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                {isAr ? "نص السيرة الذاتية" : "Resume Text"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* File upload area */}
              <div className="border-2 border-dashed border-border rounded-xl p-5 text-center hover:border-primary/50 transition-colors bg-muted/20">
                <input type="file" accept=".txt,.pdf,.docx" id="ats-file-upload" className="hidden" onChange={handleFileUpload} />
                <Button type="button" variant="outline" size="sm" className="gap-2 mb-2" disabled={fileLoading} onClick={() => document.getElementById("ats-file-upload")?.click()}>
                  {fileLoading ? (
                    <><Loader2 className="w-4 h-4 animate-spin" />{isAr ? "جاري الاستخراج..." : "Extracting..."}</>
                  ) : (
                    <><Upload className="w-4 h-4" />{isAr ? "رفع ملف (TXT/PDF)" : "Upload File (TXT/PDF)"}</>
                  )}
                </Button>
                {uploadedFileName && (
                  <p className="text-sm text-emerald-600 dark:text-emerald-400 font-medium mt-1">
                    📄 {uploadedFileName}
                  </p>
                )}
                <p className="text-xs text-muted-foreground mt-2">
                  {isAr ? "أو الصق نص السيرة الذاتية أدناه" : "Or paste your resume text below"}
                </p>
              </div>

              {/* Text input */}
              <Textarea
                value={resumeText}
                onChange={e => setResumeText(e.target.value)}
                placeholder={isAr
                  ? "الصق سيرتك الذاتية هنا...\n\nمثال:\n\nAhmed Mohamed\nahmed@email.com | +1 234 567 890 | Cairo, Egypt | linkedin.com/in/ahmed\n\nPROFESSIONAL SUMMARY\nSenior Software Engineer with 7+ years of experience in full-stack development..."
                  : "Paste your resume here...\n\nExample:\n\nJohn Smith\njohn@email.com | +1 234 567 890 | New York, NY | linkedin.com/in/john\n\nPROFESSIONAL SUMMARY\nSenior Software Engineer with 7+ years of experience in full-stack development..."}
                className="min-h-[280px] text-sm font-mono leading-relaxed"
                dir={isAr ? "rtl" : "ltr"}
              />

              {/* Character count */}
              <div className="flex justify-between items-center text-xs text-muted-foreground">
                <span>{resumeText.trim().split(/\s+/).filter(w => w.length > 0).length} {isAr ? 'كلمة' : 'words'}</span>
                <span>{resumeText.length} {isAr ? 'حرف' : 'characters'}</span>
              </div>

              {/* Scan button */}
              <Button
                onClick={handleScan}
                disabled={loading || !resumeText.trim() || !canScan}
                className="w-full h-12 text-base font-semibold bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90 transition-all shadow-lg shadow-primary/25"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    <span>{isAr ? "جاري التحليل المتقدم..." : "Running Advanced Analysis..."}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 mr-2" />
                    <span>{isAr ? "تشغيل فحص ATS الشامل" : "Run Full ATS Analysis"}</span>
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Results Panel */}
          <div className="space-y-4">
            {/* Loading State */}
            {loading && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <Card>
                  <CardContent className="py-14 text-center space-y-4">
                    <div className="relative w-20 h-20 mx-auto">
                      <div className="absolute inset-0 rounded-full border-4 border-primary/20" />
                      <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-primary animate-spin" />
                      <Brain className="w-8 h-8 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold">{isAr ? "جاري تحليل السيرة الذاتية..." : "Analyzing your resume..."}</h3>
                    <p className="text-sm text-muted-foreground max-w-xs mx-auto">
                      {isAr
                        ? "فحص 150+ معيار • تحليل 7 أقسام • مطابقة الكلمات المفتاحية • كشف عناصر ATS القاتلة"
                        : "Checking 150+ criteria • Analyzing 7 sections • Matching keywords • Detecting ATS killer elements"}
                    </p>
                    <div className="flex justify-center gap-1.5">
                      {[0, 1, 2].map(i => (
                        <motion.div key={i} className="w-2 h-2 rounded-full bg-primary" animate={{ opacity: [0.3, 1, 0.3] }} transition={{ duration: 1, repeat: Infinity, delay: i * 0.25 }} />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Results */}
            {result && !loading && (
              <AnimatePresence mode="wait">
                <motion.div key="results" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="space-y-4">

                  {/* Overall Score Card */}
                  <Card className={`overflow-hidden border-2 ${getScoreColor(result.overall_score).border}`}>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-6 flex-wrap">
                        <ScoreRing score={result.overall_score} />
                        <div className="flex-1 min-w-[200px] space-y-2">
                          <div className="flex items-center gap-2">
                            <h3 className="text-lg font-bold">{isAr ? "النتيجة الإجمالية" : "Overall ATS Score"}</h3>
                            {getCompatibilityBadge(result.compatibility_level) && (
                              <Badge className={`${getCompatibilityBadge(result.compatibility_level).color} gap-1 border-0`}>
                                {getCompatibilityBadge(result.compatibility_level).icon}
                                {getCompatibilityBadge(result.compatibility_level).label}
                              </Badge>
                            )}
                          </div>
                          <Progress value={result.overall_score} className="h-3" />
                          <p className="text-sm text-muted-foreground leading-relaxed">{result.ats_compatibility}</p>
                        </div>
                      </div>

                      {/* Metadata bar */}
                      <div className="mt-4 pt-4 border-t border-border/50 flex flex-wrap gap-x-5 gap-y-1 text-xs text-muted-foreground">
                        <span>📝 {result.metadata.word_count} {isAr ? 'كلمة' : 'words'}</span>
                        <span>📄 {result.metadata.line_count} {isAr ? 'سطر' : 'lines'}</span>
                        <span>🌐 {result.language_detected === 'ar' ? 'العربية' : 'English'}</span>
                        <span>⚡ {result.metadata.engine_version}</span>
                        {result.metadata.processing_time_ms && (
                          <span>⏱️ {result.metadata.processing_time_ms}ms</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Section Scores */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <BarChart3 className="w-4 h-4 text-primary" />
                        {isAr ? "التقييم التفصيلي (7 أقسام)" : "Detailed Assessment (7 Sections)"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {Object.entries(result.sections).map(([key, section]) => {
                        const colors = getScoreColor(section.score)
                        const isExpanded = expandedSection === key

                        return (
                          <div key={key} className={`rounded-lg border transition-colors ${isExpanded ? 'border-primary/30 bg-muted/30 p-4' : 'border-border/50 p-3'}`}>
                            <button
                              onClick={() => setExpandedSection(isExpanded ? null : key)}
                              className="w-full flex items-center gap-3 text-left"
                            >
                              <span className="shrink-0">{sectionIcons[key] || <FileText className="w-4 h-4" />}</span>
                              <span className="flex-1 text-sm font-medium truncate">{labels[key] || key.replace(/_/g, ' ')}</span>
                              <span className={`font-bold text-sm tabular-nums ${colors.text}`}>{section.score}%</span>
                              <Progress value={section.score} className="w-16 h-1.5 hidden sm:block" />
                              {getScoreIcon(section.score)}
                              {isExpanded ? <ChevronUp className="w-4 h-4 text-muted-foreground shrink-0" /> : <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />}
                            </button>

                            {/* Expanded Details */}
                            <AnimatePresence>
                              {isExpanded && (
                                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden">
                                  <div className="mt-3 pt-3 border-t border-border/50 space-y-3">
                                    {/* Feedback */}
                                    <p className="text-sm text-muted-foreground leading-relaxed">{section.feedback}</p>

                                    {/* Strengths */}
                                    {section.strengths && section.strengths.length > 0 && (
                                      <div>
                                        <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-1.5 uppercase tracking-wider">
                                          ✓ {isAr ? 'نقاط القوة' : 'Strengths'}
                                        </p>
                                        <ul className="space-y-1">
                                          {section.strengths.map((s, i) => (
                                            <li key={i} className="text-sm text-emerald-700 dark:text-emerald-300 pl-2 border-l-2 border-emerald-500/30">{s}</li>
                                          ))}
                                        </ul>
                                      </div>
                                    )}

                                    {/* Issues */}
                                    {section.issues && section.issues.length > 0 && (
                                      <div>
                                        <p className="text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1.5 uppercase tracking-wider">
                                          ⚠ {isAr ? 'ملاحظات' : 'Issues'}
                                        </p>
                                        <ul className="space-y-1">
                                          {section.issues.map((issue, i) => (
                                            <li key={i} className="text-sm text-amber-700 dark:text-amber-300 pl-2 border-l-2 border-amber-500/30">{issue}</li>
                                          ))}
                                        </ul>
                                      </div>
                                    )}

                                    {/* Critical Issues */}
                                    {section.criticalIssues && section.criticalIssues.filter(Boolean).length > 0 && (
                                      <div className="rounded-md bg-red-50 dark:bg-red-950/30 p-3">
                                        <p className="text-xs font-semibold text-red-600 dark:text-red-400 mb-1.5 uppercase tracking-wider">
                                          🔴 {isAr ? 'مشاكل حرجة' : 'Critical Issues'}
                                        </p>
                                        <ul className="space-y-1">
                                          {section.criticalIssues.filter(Boolean).map((issue, i) => (
                                            <li key={i} className="text-sm text-red-700 dark:text-red-300 font-medium">{issue}</li>
                                          ))}
                                        </ul>
                                      </div>
                                    )}

                                    {/* Raw Details (for tech-savvy users) */}
                                    {section.details && Object.keys(section.details).length > 0 && (
                                      <details className="group">
                                        <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground transition-colors">
                                          🔍 {isAr ? 'عرض البيانات الخام' : 'View raw data'}
                                        </summary>
                                        <pre className="mt-2 text-xs bg-muted/50 rounded p-2 overflow-auto max-h-40 font-mono leading-relaxed">
                                          {JSON.stringify(section.details, null, 2)}
                                        </pre>
                                      </details>
                                    )}
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        )
                      })}
                    </CardContent>
                  </Card>

                  {/* Improvements & Strengths Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Critical Improvements */}
                    {result.improvements.length > 0 && (
                      <Card className="border-amber-500/20 bg-amber-500/5">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm flex items-center gap-2 text-amber-700 dark:text-amber-300">
                            <AlertOctagon className="w-4 h-4" />
                            {isAr ? `التحسينات المطلوبة (${result.improvements.length})` : `Improvements Needed (${result.improvements.length})`}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-2.5">
                            {result.improvements.map((item, i) => (
                              <li key={i} className="text-sm text-amber-800 dark:text-amber-200 flex items-start gap-2">
                                <span className="text-amber-500 mt-0.5 shrink-0 font-bold">{i + 1}.</span>
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    )}

                    {/* Strengths */}
                    {result.strengths.length > 0 && (
                      <Card className="border-emerald-500/20 bg-emerald-500/5">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm flex items-center gap-2 text-emerald-700 dark:text-emerald-300">
                            <Award className="w-4 h-4" />
                            {isAr ? `نقاط القوة (${result.strengths.length})` : `Strengths (${result.strengths.length})`}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-2.5">
                            {result.strengths.map((item, i) => (
                              <li key={i} className="text-sm text-emerald-800 dark:text-emerald-200 flex items-start gap-2">
                                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                </motion.div>
              </AnimatePresence>
            )}

            {/* Empty State */}
            {!result && !loading && (
              <Card>
                <CardContent className="py-14 text-center space-y-4">
                  <div className="relative w-24 h-24 mx-auto">
                    <div className="absolute inset-0 rounded-full bg-primary/5" />
                    <div className="absolute inset-4 rounded-full bg-primary/10 flex items-center justify-center">
                      <FileSearch className="w-10 h-10 text-primary/40" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">{isAr ? "الصق سيرتك الذاتية لبدء الفحص" : "Paste your resume to start scanning"}</h3>
                    <p className="text-muted-foreground text-sm mt-1.5 max-w-xs mx-auto">
                      {isAr
                        ? "سيتم تحليل سيرتك ضد 150+ معيار من أنظمة ATS الحقيقية"
                        : "Your resume will be analyzed against 150+ criteria from real ATS systems"}
                    </p>
                  </div>
                  <div className="flex flex-wrap justify-center gap-2">
                    {['Taleo', 'Workday', 'Greenhouse', 'Lever', 'iCIMS'].map(ats => (
                      <Badge key={ats} variant="outline" className="text-[10px] font-mono">{ats}</Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
