import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('site_stats')
        .select('*')
        .eq('key', 'total_resumes')
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      // Increment counter
      const { data: current, error: fetchErr } = await supabase
        .from('site_stats')
        .select('*')
        .eq('key', 'total_resumes')
        .single();
      if (fetchErr) throw fetchErr;
      const newVal = (current.value || 1233) + 1;
      const { data, error } = await supabase
        .from('site_stats')
        .update({ value: newVal })
        .eq('key', 'total_resumes')
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
