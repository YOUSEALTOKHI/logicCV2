import { Button } from "@/components/ui/button"
import { ArrowRight, Shield, CreditCard, Zap } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

export function CTASection() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  return (
    <section className="relative py-16 lg:py-24 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a1628] via-[#0f2044] to-[#162d5a]" />
      <div className="absolute inset-0 opacity-[0.04]" style={{
        backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)',
        backgroundSize: '32px 32px'
      }} />
      <div className="absolute top-0 end-1/4 w-80 h-80 bg-sky-400/10 rounded-full blur-[100px]" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6 text-balance">
            {isAr ? "هل أنت مستعد للحصول على وظيفة أحلامك؟" : "Ready to Land Your Dream Job?"}
          </h2>
          <p className="text-lg text-blue-100/70 mb-8 leading-relaxed">
            {isAr ? "ابدأ بتحسين سيرتك الذاتية اليوم واحصل على مقابلات أكثر" : "Start optimizing your resume today and get more interviews"}
          </p>
          <div className="flex flex-wrap justify-center gap-6 mb-8">
            {[
              { icon: Zap, textEn: "Free to start", textAr: "مجاني للبدء" },
              { icon: CreditCard, textEn: "No credit card required", textAr: "لا حاجة لبطاقة ائتمان" },
              { icon: Shield, textEn: "Results in seconds", textAr: "نتائج فورية" },
            ].map(({ icon: Icon, textEn, textAr }, i) => (
              <div key={i} className="flex items-center gap-2 text-blue-200/60">
                <Icon className="w-5 h-5" /><span className="text-sm">{isAr ? textAr : textEn}</span>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="bg-white text-[#0f2044] hover:bg-blue-50 shadow-lg shadow-black/20 hover:shadow-xl transition-all duration-300 hover:scale-[1.03] font-semibold">
              {isAr ? "ابدأ الفحص المجاني" : "Start Free Scan"}<ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <Button size="lg" className="bg-white/10 backdrop-blur-sm text-white border border-white/20 hover:bg-white/20 hover:border-white/30 transition-all duration-300 font-semibold">
              {isAr ? "عرض الخدمات" : "View Services"}
            </Button>
          </div>
          <div className="flex justify-center items-center gap-6 mt-10">
            <div className="flex items-center gap-2 text-blue-200/40 text-sm"><Shield className="w-4 h-4" />SSL Secured</div>
            <div className="text-blue-200/40 text-sm">GDPR Compliant</div>
            <div className="text-blue-200/40 text-sm">Money Back Guarantee</div>
          </div>
        </div>
      </div>
    </section>
  )
}
