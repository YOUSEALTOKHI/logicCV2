import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScanLine, FileSearch, DollarSign, MessageSquare, FileText, Mail, BarChart2, Target, BadgeCheck, Users, Globe, FileEdit } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

const features = [
  { icon: ScanLine, titleEn: "ATS Scanner", titleAr: "فحص ATS", descEn: "Check if your resume can pass applicant tracking systems", descAr: "تحقق من قدرة سيرتك الذاتية على تجاوز أنظمة تتبع المتقدمين", badge: "Free" },
  { icon: FileSearch, titleEn: "Job Matcher", titleAr: "مطابقة الوظائف", descEn: "Compare your CV with any job posting to see match percentage.", descAr: "قارن سيرتك مع أي وصف وظيفي لمعرفة نسبة التطابق.", badge: "Free" },
  { icon: DollarSign, titleEn: "Salary Insights", titleAr: "مقياس الراتب", descEn: "Get salary predictions based on your profile", descAr: "احصل على تقدير للراتب بناءً على ملفك", badge: "New" },
  { icon: MessageSquare, titleEn: "Interview Prep", titleAr: "تحضير المقابلة", descEn: "Practice with AI-powered mock interviews", descAr: "تدرب على مقابلات وهمية بالذكاء الاصطناعي", badge: "Pro" },
  { icon: FileText, titleEn: "Cover Letter", titleAr: "رسالة التقديم", descEn: "Create customized cover letters for each application.", descAr: "أنشئ رسائل تقديم مخصصة لكل طلب.", badge: "Pro" },
  { icon: Mail, titleEn: "Email Generator", titleAr: "مولد البريد", descEn: "Generate professional follow-up and application emails.", descAr: "أنشئ رسائل بريد احترافية للمتابعة والتقديم.", badge: "Pro" },
  { icon: BarChart2, titleEn: "Skill Gap Analysis", titleAr: "تحليل الفجوات", descEn: "Identify missing skills for your target role.", descAr: "حدد المهارات الناقصة للوظيفة المستهدفة." },
  { icon: Target, titleEn: "Keyword Optimization", titleAr: "تحسين الكلمات", descEn: "Optimize keywords to match job descriptions", descAr: "حسّن الكلمات المفتاحية لتطابق الوصف الوظيفي" },
  { icon: BadgeCheck, titleEn: "Verification Badge", titleAr: "شارة التحقق", descEn: "Get a QR code on your CV that employers can scan.", descAr: "احصل على رمز QR على سيرتك يمكن لأصحاب العمل مسحه.", badge: "Pro" },
  { icon: Users, titleEn: "Competitive Analysis", titleAr: "تحليل تنافسي", descEn: "Compare your resume against others in your field.", descAr: "قارن سيرتك بالآخرين في مجالك.", badge: "Pro" },
  { icon: Globe, titleEn: "Multi-Language", titleAr: "متعدد اللغات", descEn: "Full support for English and Arabic with professional translations.", descAr: "دعم كامل للعربية والإنجليزية بترجمات احترافية." },
  { icon: FileEdit, titleEn: "Professional Writing", titleAr: "كتابة احترافية", descEn: "Get your resume written by certified professionals.", descAr: "احصل على سيرة ذاتية مكتوبة بواسطة خبراء.", badge: "Premium" },
]

const getBadgeClass = (badge?: string) => {
  switch (badge) {
    case "Free": return "bg-emerald-500/10 text-emerald-600 border-emerald-500/20"
    case "New": return "bg-[#c9a84c]/10 text-[#c9a84c] border-[#c9a84c]/20"
    case "Pro": return "bg-blue-500/10 text-blue-600 border-blue-500/20"
    case "Premium": return "bg-gradient-to-r from-[#c9a84c]/20 to-[#0f2044]/20 text-[#0f2044] dark:text-[#c9a84c] border-[#c9a84c]/20"
    default: return ""
  }
}

export function FeaturesSection() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  return (
    <section id="features" className="py-20 lg:py-28 bg-muted/40">
      <div className="container mx-auto px-4">
        <div className="text-center mb-14">
          <Badge className="bg-primary/5 text-primary border-primary/10 mb-4 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest">
            {isAr ? "الأدوات" : "Tools"}
          </Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">{isAr ? "أدوات قوية لمستقبلك المهني" : "Powerful Tools for Your Career"}</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{isAr ? "كل ما تحتاجه للحصول على وظيفة أحلامك" : "Everything you need to land your dream job"}</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {features.map((feature, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 border border-border/50 bg-card/80 backdrop-blur-sm overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <CardHeader className="pb-2 relative">
                <div className="flex items-start justify-between">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0f2044] to-[#1a3a6a] flex items-center justify-center shadow-lg shadow-[#0f2044]/10 group-hover:shadow-[#0f2044]/20 transition-shadow">
                    <feature.icon className="w-6 h-6 text-[#c9a84c]" />
                  </div>
                  {feature.badge && <Badge variant="outline" className={`text-[10px] font-semibold ${getBadgeClass(feature.badge)}`}>{feature.badge}</Badge>}
                </div>
              </CardHeader>
              <CardContent className="relative">
                <CardTitle className="text-base mb-2 font-bold">{isAr ? feature.titleAr : feature.titleEn}</CardTitle>
                <p className="text-sm text-muted-foreground leading-relaxed">{isAr ? feature.descAr : feature.descEn}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}