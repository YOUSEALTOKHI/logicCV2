import { cn } from "@/lib/utils"

interface LogicCVLogoProps {
  className?: string
  size?: "sm" | "md" | "lg" | "xl"
  showText?: boolean
  showTagline?: boolean
  variant?: "light" | "dark" | "auto"
}

const SIZE_MAP = {
  sm: { icon: "w-8 h-8", text: "text-base", tagline: "text-[7px] tracking-[0.15em]" },
  md: { icon: "w-10 h-10", text: "text-lg", tagline: "text-[8px] tracking-[0.18em]" },
  lg: { icon: "w-12 h-12", text: "text-2xl", tagline: "text-[9px] tracking-[0.2em]" },
  xl: { icon: "w-16 h-16", text: "text-3xl", tagline: "text-[10px] tracking-[0.22em]" },
}

export function LogicCVLogo({
  className,
  size = "md",
  showText = true,
  showTagline = false,
  variant = "auto",
}: LogicCVLogoProps) {
  const s = SIZE_MAP[size]

  const isLight = variant === "light"
  const isDark = variant === "dark"
  const textColor = isLight ? "text-white" : isDark ? "text-[#0a1628]" : "text-[#0a1628] dark:text-white"
  const taglineColor = isLight ? "text-white/50" : isDark ? "text-[#0a1628]/50" : "text-[#0a1628]/50 dark:text-white/50"
  const cvColor = "text-[#c9a84c]"

  return (
    <div className={cn("flex items-center gap-2.5 group cursor-pointer select-none", className)}>
      {/* Shield + Document + Checkmark Icon */}
      <div className={cn("relative shrink-0", s.icon)}>
        <svg
          viewBox="0 0 120 140"
          className="w-full h-full drop-shadow-md transition-transform duration-300 group-hover:scale-105"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Shield shape — left gold, right blue */}
          <defs>
            <linearGradient id="shieldGoldGrad" x1="0" y1="0" x2="60" y2="130" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#d4af5a" />
              <stop offset="50%" stopColor="#c9a84c" />
              <stop offset="100%" stopColor="#a88a3a" />
            </linearGradient>
            <linearGradient id="shieldBlueGrad" x1="60" y1="0" x2="120" y2="130" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#1e4d8c" />
              <stop offset="50%" stopColor="#0f2044" />
              <stop offset="100%" stopColor="#0a1628" />
            </linearGradient>
            <linearGradient id="checkGrad" x1="42" y1="55" x2="90" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#1e4d8c" />
              <stop offset="100%" stopColor="#0f2044" />
            </linearGradient>
            <clipPath id="shieldClipLeft">
              <rect x="0" y="0" width="60" height="140" />
            </clipPath>
            <clipPath id="shieldClipRight">
              <rect x="60" y="0" width="60" height="140" />
            </clipPath>
          </defs>

          {/* Shield outline — left half (gold) */}
          <path
            d="M60 8L14 28C14 28 8 68 16 92C24 116 60 134 60 134"
            stroke="url(#shieldGoldGrad)"
            strokeWidth="6"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
            clipPath="url(#shieldClipLeft)"
          />

          {/* Shield outline — right half (blue) */}
          <path
            d="M60 8L106 28C106 28 112 68 104 92C96 116 60 134 60 134"
            stroke="url(#shieldBlueGrad)"
            strokeWidth="6"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
            clipPath="url(#shieldClipRight)"
          />

          {/* Shield top-right decorative sharp point */}
          <path
            d="M85 18L106 28"
            stroke="url(#shieldBlueGrad)"
            strokeWidth="6"
            strokeLinecap="round"
          />

          {/* Document / CV paper */}
          <rect x="34" y="36" width="40" height="52" rx="3" ry="3"
            fill="white" fillOpacity="0.05"
            stroke="#0f2044" strokeWidth="3"
          />
          {/* Document corner fold */}
          <path d="M62 36L74 36L74 48L62 48Z" fill="white" fillOpacity="0.1" />
          <path d="M62 36L62 48L74 36Z" fill="#e8e8e8" stroke="#0f2044" strokeWidth="1.5" strokeLinejoin="round" />

          {/* Document lines (text representation) */}
          <line x1="42" y1="56" x2="62" y2="56" stroke="#c9a84c" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="42" y1="64" x2="58" y2="64" stroke="#c9a84c" strokeWidth="2.5" strokeLinecap="round" opacity="0.7" />
          <line x1="42" y1="72" x2="54" y2="72" stroke="#c9a84c" strokeWidth="2.5" strokeLinecap="round" opacity="0.5" />

          {/* Small QR / badge icon in document */}
          <rect x="56" y="74" width="10" height="10" rx="1.5" stroke="#0f2044" strokeWidth="1.5" fill="none" opacity="0.4" />
          <rect x="58" y="76" width="3" height="3" rx="0.5" fill="#0f2044" opacity="0.3" />
          <rect x="62" y="76" width="2" height="2" rx="0.5" fill="#0f2044" opacity="0.3" />
          <rect x="58" y="80" width="2" height="2" rx="0.5" fill="#0f2044" opacity="0.3" />

          {/* Large Checkmark — sweeping across shield */}
          <path
            d="M38 78L52 94L88 48"
            stroke="url(#checkGrad)"
            strokeWidth="8"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
          />
        </svg>
      </div>

      {/* Wordmark */}
      {showText && (
        <div className="flex flex-col leading-none">
          <div className={cn("font-extrabold tracking-tight", s.text)}>
            <span className={textColor}>Logic</span>
            <span className={cvColor}>CV</span>
          </div>
          {showTagline && (
            <span className={cn("font-semibold uppercase mt-1", s.tagline, taglineColor)}>
              Build. Optimize. Succeed.
            </span>
          )}
        </div>
      )}
    </div>
  )
}
