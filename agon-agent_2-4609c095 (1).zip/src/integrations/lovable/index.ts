import { supabase } from "../supabase/client";

type SignInOptions = {
  redirect_uri?: string;
  extraParams?: Record<string, string>;
};

type OAuthResult = {
  error: any | null;
  redirected: boolean;
  tokens?: any;
};

// LogicCV OAuth integration (replaces third-party auth)
export const lovable = {
  auth: {
    signInWithOAuth: async (provider: "google" | "apple" | "microsoft", opts?: SignInOptions): Promise<OAuthResult> => {
      try {
        if (!supabase) {
          return { error: new Error("Authentication is not configured. Please use email/password login."), redirected: false };
        }
        const { data, error } = await supabase.auth.signInWithOAuth({
          provider: provider as any,
          options: {
            redirectTo: opts?.redirect_uri || window.location.origin,
          },
        });
        if (error) return { error, redirected: false };
        return { error: null, redirected: true };
      } catch (e) {
        return { error: e instanceof Error ? e : new Error(String(e)), redirected: false };
      }
    },
  },
};
