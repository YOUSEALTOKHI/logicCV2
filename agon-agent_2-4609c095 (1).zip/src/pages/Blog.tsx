import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { useLanguage } from "@/lib/i18n/language-context"
import { ScrollToTop } from "@/components/scroll-to-top"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, ArrowRight, Loader2 } from "lucide-react"

interface BlogPost {
  id: number
  slug: string
  title: string
  title_ar: string
  excerpt: string
  excerpt_ar: string
  content: string
  content_ar: string
  image: string
  category: string
  category_ar: string
  read_time: number
  created_at: string
  published: boolean
}

export default function BlogPage() {
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const [posts, setPosts] = useState<BlogPost[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/blog')
      .then(r => r.json())
      .then(data => { setPosts(data || []); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1">
        {/* Hero */}
        <section className="relative py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-[#0a1628] via-[#0f2044] to-[#1a3a6a]" />
          <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '32px 32px' }} />
          <div className="container mx-auto px-4 relative z-10 text-center">
            <h1 className="text-4xl lg:text-5xl font-black text-white mb-4">
              {isAr ? 'المدونة' : 'Blog & Resources'}
            </h1>
            <p className="text-lg text-blue-100/70 max-w-2xl mx-auto">
              {isAr ? 'نصائح ومقالات لتحسين سيرتك الذاتية ومسيرتك المهنية' : 'Tips and articles to improve your resume and career'}
            </p>
          </div>
        </section>

        {/* Posts */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4">
            {loading ? (
              <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {posts.map(post => (
                  <Link key={post.id} to={`/blog/${post.slug}`}>
                    <Card className="group overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-border/50 h-full">
                      <div className="aspect-video overflow-hidden">
                        <img src={post.image} alt={isAr ? post.title_ar : post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      </div>
                      <CardContent className="p-6">
                        <Badge className="mb-3 bg-primary/10 text-primary border-0">{isAr ? post.category_ar : post.category}</Badge>
                        <h3 className="text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-2">
                          {isAr ? post.title_ar : post.title}
                        </h3>
                        <p className="text-sm text-muted-foreground leading-relaxed mb-4 line-clamp-3">
                          {isAr ? post.excerpt_ar : post.excerpt}
                        </p>
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <div className="flex items-center gap-3">
                            <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{new Date(post.created_at).toLocaleDateString(isAr ? 'ar-SA' : 'en-US', { year: 'numeric', month: 'short', day: 'numeric' })}</span>
                            <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{post.read_time} {isAr ? 'دقائق' : 'min'}</span>
                          </div>
                          <ArrowRight className={`w-4 h-4 text-primary group-hover:translate-x-1 transition-transform ${isAr ? 'rotate-180' : ''}`} />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  )
}
