import { useEffect, useState } from "react"
import { useParams, Link } from "react-router-dom"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { useLanguage } from "@/lib/i18n/language-context"
import { ScrollToTop } from "@/components/scroll-to-top"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, ArrowLeft, Loader2 } from "lucide-react"

export default function BlogPostPage() {
  const { slug } = useParams<{ slug: string }>()
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const [post, setPost] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch(`/api/blog?slug=${slug}`)
      .then(r => r.json())
      .then(data => { setPost(data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [slug])

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <Loader2 className="w-8 h-8 animate-spin text-primary" />
    </div>
  )

  if (!post) return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">{isAr ? 'المقال غير موجود' : 'Post Not Found'}</h1>
          <Link to="/blog"><Button>{isAr ? 'العودة للمدونة' : 'Back to Blog'}</Button></Link>
        </div>
      </main>
      <Footer />
    </div>
  )

  return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1">
        <div className="relative h-[400px] overflow-hidden">
          <img src={post.image} alt={isAr ? post.title_ar : post.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-8">
            <div className="container mx-auto">
              <Badge className="mb-4 bg-white/20 text-white border-0 backdrop-blur-sm">{isAr ? post.category_ar : post.category}</Badge>
              <h1 className="text-3xl lg:text-4xl font-black text-white mb-4 max-w-3xl">{isAr ? post.title_ar : post.title}</h1>
              <div className="flex items-center gap-4 text-white/70 text-sm">
                <span className="flex items-center gap-1"><Calendar className="w-4 h-4" />{new Date(post.created_at).toLocaleDateString(isAr ? 'ar-SA' : 'en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" />{post.read_time} {isAr ? 'دقائق قراءة' : 'min read'}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-3xl mx-auto">
            <Link to="/blog" className="inline-flex items-center gap-2 text-primary hover:underline mb-8">
              <ArrowLeft className={`w-4 h-4 ${isAr ? 'rotate-180' : ''}`} />
              {isAr ? 'العودة للمدونة' : 'Back to Blog'}
            </Link>
            <article className="prose prose-lg dark:prose-invert max-w-none">
              <div className="text-foreground leading-relaxed whitespace-pre-line text-base">
                {isAr ? post.content_ar : post.content}
              </div>
            </article>
          </div>
        </div>
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  )
}
