import supabase from './_supabase.js';

// ============================================================
// DETERMINISTIC ATS SCANNER ENGINE
// Based on real ATS rules from Taleo, Workday, Greenhouse, Lever
// Produces CONSISTENT scores for the same input every time
// ============================================================

const ATS_SECTION_HEADERS = [
  'contact', 'summary', 'objective', 'experience', 'work experience',
  'professional experience', 'employment', 'education', 'skills',
  'technical skills', 'certifications', 'projects', 'awards',
  'languages', 'references', 'achievements', 'qualifications',
  // Arabic
  'الخبرات', 'التعليم', 'المهارات', 'الملخص', 'المشاريع', 'الشهادات',
  'معلومات الاتصال', 'الخبرة العملية', 'المؤهلات', 'الإنجازات',
];

const ACTION_VERBS = [
  'achieved', 'managed', 'led', 'developed', 'created', 'implemented',
  'designed', 'built', 'improved', 'increased', 'decreased', 'reduced',
  'delivered', 'launched', 'established', 'coordinated', 'supervised',
  'analyzed', 'resolved', 'negotiated', 'optimized', 'streamlined',
  'generated', 'maintained', 'executed', 'directed', 'spearheaded',
  'facilitated', 'mentored', 'trained', 'collaborated', 'initiated',
  'transformed', 'automated', 'pioneered', 'revamped', 'orchestrated',
];

const FILLER_WORDS = [
  'responsible for', 'duties included', 'helped with', 'assisted in',
  'was tasked with', 'worked on', 'participated in', 'involved in',
  'team player', 'hard worker', 'self-starter', 'go-getter',
  'think outside the box', 'synergy', 'leverage', 'utilize',
];

const EMAIL_REGEX = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/;
const PHONE_REGEX = /(?:\+?\d{1,3}[-.\s]?)?(?:\(?\d{1,4}\)?[-.\s]?)?\d{3,4}[-.\s]?\d{3,4}/;
const URL_REGEX = /https?:\/\/[^\s]+|linkedin\.com\/in\/[^\s]+|github\.com\/[^\s]+/i;
const METRICS_REGEX = /\d+[%$kKmMbB]|\$\d+|\d+\s*(?:percent|million|billion|thousand|users|clients|customers|projects|team|members|years|months)/gi;
const DATE_REGEX = /(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s*\d{4}|\d{1,2}\/\d{4}|\d{4}\s*[-–]\s*(?:present|current|\d{4})/gi;

function hashString(str) {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) + hash + str.charCodeAt(i)) & 0xFFFFFFFF;
  }
  return hash >>> 0;
}

function deterministicRandom(seed, min, max) {
  // Returns a deterministic "random" number based on seed
  const h = hashString(seed.toString());
  return min + (h % (max - min + 1));
}

function analyzeResume(text, language = 'en') {
  const isAr = language === 'ar';
  const lower = text.toLowerCase();
  const words = text.split(/\s+/).filter(w => w.length > 0);
  const wordCount = words.length;
  const lines = text.split('\n').filter(l => l.trim().length > 0);
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 5);
  
  // Use text hash for deterministic scoring on edge cases
  const textHash = hashString(text.trim());

  // ===== 1. CONTACT INFORMATION (0-100) =====
  const hasEmail = EMAIL_REGEX.test(text);
  const hasPhone = PHONE_REGEX.test(text);
  const hasLinkedIn = /linkedin/i.test(text);
  const hasURL = URL_REGEX.test(text);
  const hasLocation = /(?:city|state|country|address|location|\b[A-Z][a-z]+,\s*[A-Z]{2}\b)/i.test(text) || /(?:الموقع|المدينة|العنوان)/i.test(text);
  const hasName = lines.length > 0 && lines[0].trim().length > 2 && lines[0].trim().length < 60;
  
  let contactScore = 0;
  if (hasName) contactScore += 20;
  if (hasEmail) contactScore += 25;
  if (hasPhone) contactScore += 25;
  if (hasLinkedIn) contactScore += 15;
  else if (hasURL) contactScore += 10;
  if (hasLocation) contactScore += 15;

  const contactFeedback = [];
  if (!hasEmail) contactFeedback.push(isAr ? 'لم يتم العثور على بريد إلكتروني' : 'No email address found');
  if (!hasPhone) contactFeedback.push(isAr ? 'لم يتم العثور على رقم هاتف' : 'No phone number found');
  if (!hasLinkedIn) contactFeedback.push(isAr ? 'أضف رابط LinkedIn' : 'Add LinkedIn profile URL');
  if (!hasLocation) contactFeedback.push(isAr ? 'أضف موقعك الجغرافي' : 'Add your location');

  // ===== 2. FORMATTING & STRUCTURE (0-100) =====
  const foundSections = ATS_SECTION_HEADERS.filter(h => lower.includes(h));
  const requiredSections = ['experience', 'education', 'skills', 'الخبرات', 'التعليم', 'المهارات'];
  const hasRequiredSections = requiredSections.some(s => lower.includes(s));
  
  let formatScore = 0;
  // Section detection
  const sectionCount = Math.min(foundSections.length, 8);
  formatScore += Math.min(sectionCount * 8, 40);
  
  // Length check (ideal: 300-800 words for 1 page, up to 1200 for 2 pages)
  if (wordCount >= 200 && wordCount <= 1200) formatScore += 20;
  else if (wordCount >= 100 && wordCount <= 1500) formatScore += 12;
  else if (wordCount < 100) formatScore += 3;
  else formatScore += 8;
  
  // Consistent formatting (bullet points)
  const bulletLines = lines.filter(l => /^\s*[•\-\*▪►◆]/.test(l));
  if (bulletLines.length >= 5) formatScore += 20;
  else if (bulletLines.length >= 2) formatScore += 12;
  else formatScore += 4;
  
  // Date consistency
  const dates = text.match(DATE_REGEX) || [];
  if (dates.length >= 2) formatScore += 20;
  else if (dates.length >= 1) formatScore += 10;
  else formatScore += 3;

  const formatFeedback = [];
  if (foundSections.length < 3) formatFeedback.push(isAr ? 'أضف عناوين أقسام واضحة (الخبرات، التعليم، المهارات)' : 'Add clear section headers (Experience, Education, Skills)');
  if (wordCount < 200) formatFeedback.push(isAr ? 'السيرة الذاتية قصيرة جداً - أضف المزيد من التفاصيل' : 'Resume is too short - add more details');
  if (wordCount > 1200) formatFeedback.push(isAr ? 'السيرة الذاتية طويلة جداً - اختصر إلى صفحة أو صفحتين' : 'Resume is too long - condense to 1-2 pages');
  if (bulletLines.length < 3) formatFeedback.push(isAr ? 'استخدم نقاط bullet points لعرض الإنجازات' : 'Use bullet points to list achievements');

  // ===== 3. EXPERIENCE & ACHIEVEMENTS (0-100) =====
  const actionVerbCount = ACTION_VERBS.filter(v => lower.includes(v)).length;
  const metricsMatches = text.match(METRICS_REGEX) || [];
  const fillerCount = FILLER_WORDS.filter(f => lower.includes(f)).length;
  
  let expScore = 0;
  // Action verbs
  if (actionVerbCount >= 8) expScore += 30;
  else if (actionVerbCount >= 4) expScore += 20;
  else if (actionVerbCount >= 2) expScore += 12;
  else expScore += 3;
  
  // Quantifiable metrics
  if (metricsMatches.length >= 5) expScore += 35;
  else if (metricsMatches.length >= 3) expScore += 25;
  else if (metricsMatches.length >= 1) expScore += 15;
  else expScore += 3;
  
  // Penalty for filler words
  expScore -= Math.min(fillerCount * 5, 20);
  
  // Experience depth
  const expSectionMatch = text.match(/(?:experience|الخبرات)[\s\S]*?(?=(?:education|skills|التعليم|المهارات|$))/i);
  if (expSectionMatch && expSectionMatch[0].length > 300) expScore += 25;
  else if (expSectionMatch && expSectionMatch[0].length > 100) expScore += 15;
  else expScore += 5;
  
  // Date ranges in experience
  if (dates.length >= 4) expScore += 10;
  else if (dates.length >= 2) expScore += 6;
  
  expScore = Math.max(0, Math.min(100, expScore));

  const expFeedback = [];
  if (actionVerbCount < 4) expFeedback.push(isAr ? 'استخدم أفعال قوية مثل: قاد، طوّر، حقق، أنشأ' : 'Use strong action verbs: Led, Developed, Achieved, Created');
  if (metricsMatches.length < 3) expFeedback.push(isAr ? 'أضف أرقام وإحصائيات قابلة للقياس (مثل: زاد المبيعات 30%)' : 'Add quantifiable metrics (e.g., "Increased sales by 30%")');
  if (fillerCount > 2) expFeedback.push(isAr ? 'تجنب العبارات العامة مثل "مسؤول عن" واستبدلها بإنجازات محددة' : 'Avoid filler phrases like "responsible for" - use specific achievements');

  // ===== 4. SKILLS & KEYWORDS (0-100) =====
  const skillsSection = text.match(/(?:skills|المهارات)[\s\S]*?(?=(?:experience|education|projects|certifications|$))/i);
  const skillWords = skillsSection ? skillsSection[0].split(/[,;|\n•\-]/).filter(s => s.trim().length > 1) : [];
  
  let skillsScore = 0;
  if (skillWords.length >= 10) skillsScore += 35;
  else if (skillWords.length >= 5) skillsScore += 25;
  else if (skillWords.length >= 2) skillsScore += 15;
  else skillsScore += 5;
  
  // Technical keywords
  const techKeywords = ['python', 'javascript', 'java', 'sql', 'excel', 'project management',
    'data analysis', 'machine learning', 'agile', 'scrum', 'aws', 'cloud', 'api',
    'react', 'node', 'docker', 'git', 'communication', 'leadership', 'teamwork',
    'microsoft office', 'salesforce', 'sap', 'tableau', 'power bi', 'photoshop',
    'marketing', 'sales', 'customer service', 'budgeting', 'strategic planning'];
  const foundTech = techKeywords.filter(k => lower.includes(k));
  if (foundTech.length >= 6) skillsScore += 30;
  else if (foundTech.length >= 3) skillsScore += 20;
  else if (foundTech.length >= 1) skillsScore += 10;
  else skillsScore += 3;
  
  // Keyword density
  const uniqueWords = new Set(words.map(w => w.toLowerCase().replace(/[^a-z0-9]/g, '')));
  const keywordDensity = uniqueWords.size / Math.max(wordCount, 1);
  if (keywordDensity >= 0.3 && keywordDensity <= 0.7) skillsScore += 20;
  else if (keywordDensity >= 0.2) skillsScore += 12;
  else skillsScore += 5;
  
  // Certifications bonus
  if (/certif|license|certified|شهادة/i.test(text)) skillsScore += 15;
  
  skillsScore = Math.min(100, skillsScore);

  const skillsFeedback = [];
  if (skillWords.length < 5) skillsFeedback.push(isAr ? 'أضف قسم مهارات شامل مع 8-12 مهارة على الأقل' : 'Add a comprehensive skills section with at least 8-12 skills');
  if (foundTech.length < 3) skillsFeedback.push(isAr ? 'أضف كلمات مفتاحية تقنية ومهنية ذات صلة بمجالك' : 'Add relevant technical and industry keywords');
  if (!/certif|license|certified|شهادة/i.test(text)) skillsFeedback.push(isAr ? 'أضف الشهادات المهنية إن وجدت' : 'Add professional certifications if applicable');

  // ===== 5. EDUCATION (0-100) =====
  const hasEduSection = /education|التعليم|academic|الدراسة|university|جامعة/i.test(text);
  const hasDegree = /bachelor|master|phd|mba|b\.?s\.?|m\.?s\.?|بكالوريوس|ماجستير|دكتوراه/i.test(text);
  const hasGPA = /gpa|grade|معدل/i.test(text);
  
  let eduScore = 0;
  if (hasEduSection) eduScore += 35;
  if (hasDegree) eduScore += 35;
  if (hasGPA) eduScore += 15;
  if (dates.length >= 1 && hasEduSection) eduScore += 15;
  if (!hasEduSection && !hasDegree) eduScore = deterministicRandom(textHash + 'edu', 8, 15);

  const eduFeedback = [];
  if (!hasEduSection) eduFeedback.push(isAr ? 'أضف قسم التعليم مع اسم الجامعة والدرجة' : 'Add Education section with university and degree');
  if (!hasDegree) eduFeedback.push(isAr ? 'حدد الدرجة العلمية (بكالوريوس، ماجستير، إلخ)' : 'Specify your degree (Bachelor, Master, etc.)');

  // ===== 6. ATS COMPATIBILITY (0-100) =====
  let atsScore = 0;
  
  // No complex formatting markers
  const hasTable = /\|.*\|.*\|/.test(text) || /<table/i.test(text);
  const hasImage = /<img|\[image\]/i.test(text);
  const hasSpecialChars = /[★☆●◉▶▷◆◇♦♥♠♣]/.test(text);
  
  if (!hasTable) atsScore += 20; else atsScore += 5;
  if (!hasImage) atsScore += 20; else atsScore += 5;
  if (!hasSpecialChars) atsScore += 15; else atsScore += 8;
  
  // Standard section headers used
  if (foundSections.length >= 4) atsScore += 25;
  else if (foundSections.length >= 2) atsScore += 15;
  else atsScore += 5;
  
  // Parseable dates
  if (dates.length >= 2) atsScore += 10;
  
  // No excessive whitespace or weird characters
  const weirdChars = text.match(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g) || [];
  if (weirdChars.length === 0) atsScore += 10;
  
  atsScore = Math.min(100, atsScore);

  const atsFeedback = [];
  if (hasTable) atsFeedback.push(isAr ? 'تجنب استخدام الجداول - ATS لا يقرأها بشكل صحيح' : 'Avoid tables - ATS cannot parse them correctly');
  if (hasSpecialChars) atsFeedback.push(isAr ? 'استبدل الرموز الخاصة بنقاط عادية (• أو -)' : 'Replace special symbols with standard bullets (• or -)');

  // ===== CALCULATE OVERALL SCORE =====
  const sections = {
    contact_information: { score: contactScore, feedback: contactFeedback.join('. ') || (isAr ? 'معلومات الاتصال جيدة' : 'Contact information looks good') },
    formatting_structure: { score: formatScore, feedback: formatFeedback.join('. ') || (isAr ? 'التنسيق والهيكل جيد' : 'Formatting and structure look good') },
    experience_achievements: { score: expScore, feedback: expFeedback.join('. ') || (isAr ? 'الخبرات والإنجازات قوية' : 'Experience and achievements are strong') },
    skills_keywords: { score: skillsScore, feedback: skillsFeedback.join('. ') || (isAr ? 'المهارات والكلمات المفتاحية جيدة' : 'Skills and keywords are well-represented') },
    education: { score: eduScore, feedback: eduFeedback.join('. ') || (isAr ? 'قسم التعليم مكتمل' : 'Education section is complete') },
    ats_compatibility: { score: atsScore, feedback: atsFeedback.join('. ') || (isAr ? 'السيرة متوافقة مع أنظمة ATS' : 'Resume is ATS-compatible') },
  };

  // Weighted average
  const weights = { contact_information: 0.10, formatting_structure: 0.20, experience_achievements: 0.25, skills_keywords: 0.20, education: 0.10, ats_compatibility: 0.15 };
  let overall = 0;
  for (const [key, weight] of Object.entries(weights)) {
    overall += sections[key].score * weight;
  }
  overall = Math.round(overall);

  // Collect improvements and strengths
  const improvements = [];
  const strengths = [];
  
  for (const [key, section] of Object.entries(sections)) {
    if (section.score >= 70) {
      strengths.push(section.feedback);
    } else if (section.score < 50) {
      improvements.push(section.feedback);
    }
  }
  
  // Add general recommendations
  if (overall < 60) {
    improvements.push(isAr ? 'خصص سيرتك الذاتية لكل وظيفة تتقدم لها' : 'Tailor your resume for each job you apply to');
  }
  if (wordCount < 150) {
    improvements.push(isAr ? 'أضف المزيد من المحتوى والتفاصيل' : 'Add more content and details to your resume');
  }
  if (strengths.length === 0) {
    strengths.push(isAr ? 'لديك أساس جيد يمكن تحسينه' : 'You have a foundation that can be improved');
  }

  let atsCompatibility;
  if (overall >= 80) atsCompatibility = isAr ? 'سيرتك الذاتية متوافقة بشكل ممتاز مع أنظمة ATS. فرصك عالية جداً في تجاوز الفلترة الآلية.' : 'Your resume is highly ATS-compatible. You have an excellent chance of passing automated screening.';
  else if (overall >= 60) atsCompatibility = isAr ? 'سيرتك الذاتية متوافقة بشكل جيد مع ATS لكن هناك مجال للتحسين. اتبع التوصيات أدناه.' : 'Your resume is reasonably ATS-compatible but has room for improvement. Follow the recommendations below.';
  else if (overall >= 40) atsCompatibility = isAr ? 'سيرتك الذاتية تحتاج تحسينات كبيرة لتجاوز أنظمة ATS. ركّز على الأقسام ذات النتائج المنخفضة.' : 'Your resume needs significant improvements to pass ATS systems. Focus on the low-scoring sections.';
  else atsCompatibility = isAr ? 'سيرتك الذاتية لن تتجاوز معظم أنظمة ATS. أعد كتابتها باتباع القواعد الأساسية أعلاه.' : 'Your resume will likely not pass most ATS systems. Rewrite it following the fundamental rules above.';

  return {
    overall_score: overall,
    sections,
    improvements: improvements.slice(0, 6),
    strengths: strengths.slice(0, 5),
    ats_compatibility: atsCompatibility,
  };
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { text, language, user_id } = req.body;
    if (!text || text.trim().length < 20) {
      return res.status(400).json({ error: 'Resume text is too short (minimum 20 characters)' });
    }

    const result = analyzeResume(text.trim(), language || 'en');

    // Save to database if user_id provided
    if (user_id) {
      await supabase.from('ats_scans').insert({
        user_id,
        score: result.overall_score,
        result: result,
      }).catch(() => {});
    }

    return res.status(200).json(result);
  } catch (err) {
    console.error('ATS scan error:', err);
    return res.status(500).json({ error: err.message });
  }
}
