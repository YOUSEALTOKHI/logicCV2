import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('site_counters')
        .select('*')
        .eq('key', 'resumes_optimized')
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      // Increment counter (called on user signup)
      const { data: current, error: fetchErr } = await supabase
        .from('site_counters')
        .select('value')
        .eq('key', 'resumes_optimized')
        .single();
      if (fetchErr) throw fetchErr;

      const newValue = (current.value || 0) + 1;
      const { data, error } = await supabase
        .from('site_counters')
        .update({ value: newValue, updated_at: new Date().toISOString() })
        .eq('key', 'resumes_optimized')
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
