import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { BrowserRouter, Route, Routes } from "react-router-dom"
import { ThemeProvider } from "next-themes"
import { Toaster as Sonner } from "@/components/ui/sonner"
import { Toaster } from "@/components/ui/toaster"
import { TooltipProvider } from "@/components/ui/tooltip"
import { LanguageProvider } from "@/lib/i18n/language-context"
import { AuthProvider } from "@/lib/auth/auth-context"
import { ProtectedRoute } from "@/components/auth/protected-route"
import Index from "./pages/Index"
import NotFound from "./pages/NotFound"
import LoginPage from "./pages/Login"
import SignupPage from "./pages/Signup"
import ForgotPasswordPage from "./pages/ForgotPassword"
import ResetPasswordPage from "./pages/ResetPassword"
import DashboardPage from "./pages/Dashboard"
import DashboardSettings from "./pages/DashboardSettings"
import DashboardResumes from "./pages/DashboardResumes"
import DashboardReviews from "./pages/DashboardReviews"
import DashboardSubscription from "./pages/DashboardSubscription"
import AdminDashboard from "./pages/AdminDashboard"
import AdminOrders from "./pages/AdminOrders"
import AdminMarketing from "./pages/AdminMarketing"
import AdminPaymentGateways from "./pages/AdminPaymentGateways"
import AdminUsers from "./pages/AdminUsers"
import AdminReviews from "./pages/AdminReviews"
import ATSScanner from "./pages/ATSScanner"
import PlanAIAssistant from "./pages/PlanAIAssistant"
import JobMatcher from "./pages/JobMatcher"
import CVBuilder from "./pages/CVBuilder"
import EmployeeChat from "./pages/EmployeeChat"
import EmployeeCVBot from "./pages/EmployeeCVBot"
import SupportDashboard from "./pages/SupportDashboard"
import SupportTickets from "./pages/SupportTickets"
import PaymentPage from "./pages/Payment"
import AboutPage from "./pages/About"
import BlogPage from "./pages/Blog"
import BlogPostPage from "./pages/BlogPost"
import CareersPage from "./pages/Careers"
import PrivacyPolicy from "./pages/PrivacyPolicy"
import TermsOfService from "./pages/TermsOfService"
import RefundPolicy from "./pages/RefundPolicy"

const queryClient = new QueryClient()

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
      <LanguageProvider>
        <BrowserRouter>
          <AuthProvider>
            <TooltipProvider>
              <Toaster />
              <Sonner />
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/blog" element={<BlogPage />} />
                <Route path="/blog/:slug" element={<BlogPostPage />} />
                <Route path="/careers" element={<CareersPage />} />
                <Route path="/privacy" element={<PrivacyPolicy />} />
                <Route path="/terms" element={<TermsOfService />} />
                <Route path="/refund" element={<RefundPolicy />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/signup" element={<SignupPage />} />
                <Route path="/forgot-password" element={<ForgotPasswordPage />} />
                <Route path="/reset-password" element={<ResetPasswordPage />} />
                <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
                <Route path="/dashboard/settings" element={<ProtectedRoute><DashboardSettings /></ProtectedRoute>} />
                <Route path="/dashboard/resumes" element={<ProtectedRoute><DashboardResumes /></ProtectedRoute>} />
                <Route path="/dashboard/reviews" element={<ProtectedRoute><DashboardReviews /></ProtectedRoute>} />
                <Route path="/dashboard/subscription" element={<ProtectedRoute><DashboardSubscription /></ProtectedRoute>} />
                <Route path="/dashboard/ats-scanner" element={<ProtectedRoute><ATSScanner /></ProtectedRoute>} />
                <Route path="/dashboard/ai-assistant" element={<ProtectedRoute><PlanAIAssistant /></ProtectedRoute>} />
                <Route path="/dashboard/job-matcher" element={<ProtectedRoute><JobMatcher /></ProtectedRoute>} />
                <Route path="/dashboard/cv-builder" element={<ProtectedRoute><CVBuilder /></ProtectedRoute>} />
                <Route path="/employee/chat" element={<ProtectedRoute><EmployeeChat /></ProtectedRoute>} />
                <Route path="/employee/cv-bot" element={<ProtectedRoute><EmployeeCVBot /></ProtectedRoute>} />
                <Route path="/support" element={<ProtectedRoute requiredRole="support"><SupportDashboard /></ProtectedRoute>} />
                <Route path="/support/tickets" element={<ProtectedRoute><SupportTickets /></ProtectedRoute>} />
                <Route path="/admin" element={<ProtectedRoute requiredRole="admin"><AdminDashboard /></ProtectedRoute>} />
                <Route path="/admin/orders" element={<ProtectedRoute requiredRole="admin"><AdminOrders /></ProtectedRoute>} />
                <Route path="/admin/users" element={<ProtectedRoute requiredRole="admin"><AdminUsers /></ProtectedRoute>} />
                <Route path="/admin/reviews" element={<ProtectedRoute requiredRole="admin"><AdminReviews /></ProtectedRoute>} />
                <Route path="/admin/marketing" element={<ProtectedRoute requiredRole="admin"><AdminMarketing /></ProtectedRoute>} />
                <Route path="/admin/payment-gateways" element={<ProtectedRoute requiredRole="admin"><AdminPaymentGateways /></ProtectedRoute>} />
                <Route path="/payment" element={<PaymentPage />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </TooltipProvider>
          </AuthProvider>
        </BrowserRouter>
      </LanguageProvider>
    </ThemeProvider>
  </QueryClientProvider>
)

export default App