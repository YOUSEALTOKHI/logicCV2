import { useAuth } from "@/lib/auth/auth-context"
import { useLanguage } from "@/lib/i18n/language-context"
import { X } from "lucide-react"

interface AdBannerProps {
  position?: 'header' | 'content' | 'sidebar' | 'footer'
  isPremiumUser?: boolean
}

export function AdBanner({ position = 'content', isPremiumUser }: AdBannerProps) {
  const { isPremium, plan } = useAuth()
  const { language } = useLanguage()
  const isAr = language === 'ar'

  // Hide ads for paid subscribers
  if (isPremiumUser || isPremium || (plan && plan !== 'free')) return null

  return (
    <div className="w-full max-w-5xl mx-auto py-3 px-4">
      <div className="relative rounded-lg border border-border/30 bg-muted/20 dark:bg-muted/10 overflow-hidden" style={{ minHeight: position === 'sidebar' ? '250px' : '90px' }}>
        <div className="absolute top-1.5 end-2 flex items-center gap-1">
          <span className="text-[9px] text-muted-foreground/40 uppercase tracking-widest font-medium">
            {isAr ? 'إعلان' : 'Ad'}
          </span>
        </div>
        <div className="flex items-center justify-center h-full py-6">
          {/* Google AdSense placeholder - replace data-ad-slot with real values */}
          <ins className="adsbygoogle"
            style={{ display: 'block', width: '100%', height: position === 'sidebar' ? '250px' : '90px' }}
            data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
            data-ad-slot="XXXXXXXXXX"
            data-ad-format="auto"
            data-full-width-responsive="true" />
          <div className="text-center pointer-events-none">
            <div className="w-10 h-10 mx-auto mb-1 rounded-lg bg-muted/50 dark:bg-muted/30 flex items-center justify-center">
              <svg className="w-5 h-5 text-muted-foreground/30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
            </div>
            <p className="text-[10px] text-muted-foreground/30">
              {isAr ? 'اشترك لإزالة الإعلانات' : 'Subscribe to remove ads'}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

// Legacy export for backward compatibility
export function BannerAd({ isPremiumUser = false }: { isPremiumUser?: boolean }) {
  return <AdBanner isPremiumUser={isPremiumUser} />
}
