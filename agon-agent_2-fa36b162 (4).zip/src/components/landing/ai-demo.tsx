import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { useLanguage } from "@/lib/i18n/language-context"
import { Sparkles, Loader2, Copy, Check, ArrowRight, Wand2 } from "lucide-react"
import { useNavigate } from "react-router-dom"

const EXAMPLES = [
  { inputEn: "I worked at a company and did marketing stuff.", inputAr: "عملت في شركة وسويت أشياء تسويقية.", outputEn: "Spearheaded digital marketing initiatives at [Company], driving a 45% increase in lead generation through data-driven campaigns across multiple channels, resulting in $2.3M in attributed revenue.", outputAr: "قدت مبادرات التسويق الرقمي في [الشركة]، محققاً زيادة 45% في جذب العملاء المحتملين من خلال حملات مبنية على البيانات عبر قنوات متعددة، مما أسفر عن إيرادات بقيمة 2.3 مليون دولار." },
  { inputEn: "Managed a team and did some projects.", inputAr: "أدرت فريق وعملت بعض المشاريع.", outputEn: "Led a cross-functional team of 12 professionals, delivering 8 high-impact projects on time and under budget, achieving 98% client satisfaction and reducing operational costs by 30%.", outputAr: "قدت فريقاً متعدد التخصصات من 12 متخصصاً، وأنجزت 8 مشاريع عالية التأثير في الوقت المحدد وضمن الميزانية، محققاً رضا عملاء بنسبة 98% وخفض التكاليف التشغيلية بنسبة 30%." },
]

export function AIDemo() {
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const navigate = useNavigate()
  const [input, setInput] = useState("")
  const [output, setOutput] = useState("")
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)
  const [mode, setMode] = useState<'bullet' | 'improve'>('improve')

  const tryExample = (idx: number) => {
    const ex = EXAMPLES[idx]
    setInput(isAr ? ex.inputAr : ex.inputEn)
    setOutput("")
  }

  const generate = () => {
    if (!input.trim()) return
    setLoading(true)
    setOutput("")
    const matchedEx = EXAMPLES.find(e => (isAr ? e.inputAr : e.inputEn) === input.trim())
    const result = matchedEx ? (isAr ? matchedEx.outputAr : matchedEx.outputEn) : (isAr
      ? `تم تحسين النص بنجاح: ${input.trim()} — مع إضافة أرقام قابلة للقياس ونتائج ملموسة وكلمات مفتاحية قوية تتوافق مع أنظمة ATS.`
      : `Enhanced: ${input.trim()} — with quantifiable metrics, measurable outcomes, and ATS-optimized action verbs that demonstrate impact and leadership.`)

    let idx = 0
    const interval = setInterval(() => {
      if (idx < result.length) {
        setOutput(result.slice(0, idx + 1))
        idx++
      } else {
        clearInterval(interval)
        setLoading(false)
      }
    }, 20)
  }

  const copy = () => {
    navigator.clipboard.writeText(output)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <section className="py-20 lg:py-28 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Badge className="bg-purple-500/10 text-purple-600 border-purple-500/20 mb-4 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest">
            <Wand2 className="w-3 h-3 mr-1" />{isAr ? "جرب الذكاء الاصطناعي" : "Try AI Now"}
          </Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            {isAr ? "شاهد قوة الذكاء الاصطناعي" : "See AI in Action"}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {isAr ? "حسّن وصف خبراتك فوراً - بدون تسجيل" : "Improve your experience descriptions instantly — no signup needed"}
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Card className="border-border/50 overflow-hidden">
            <CardContent className="p-0">
              <div className="flex border-b border-border">
                <button onClick={() => setMode('improve')} className={`flex-1 p-3 text-sm font-semibold text-center transition-colors ${mode === 'improve' ? 'bg-primary/5 text-primary border-b-2 border-primary' : 'text-muted-foreground hover:bg-muted/50'}`}>
                  <Sparkles className="w-4 h-4 inline mr-1" />{isAr ? 'تحسين النص' : 'Improve Text'}
                </button>
                <button onClick={() => setMode('bullet')} className={`flex-1 p-3 text-sm font-semibold text-center transition-colors ${mode === 'bullet' ? 'bg-primary/5 text-primary border-b-2 border-primary' : 'text-muted-foreground hover:bg-muted/50'}`}>
                  <Wand2 className="w-4 h-4 inline mr-1" />{isAr ? 'إنشاء نقاط' : 'Generate Bullets'}
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="flex gap-2 flex-wrap">
                  <span className="text-xs text-muted-foreground">{isAr ? 'جرب:' : 'Try:'}</span>
                  {EXAMPLES.map((_, i) => <Button key={i} variant="outline" size="sm" className="text-xs h-7" onClick={() => tryExample(i)}>{isAr ? `مثال ${i + 1}` : `Example ${i + 1}`}</Button>)}
                </div>
                <Textarea value={input} onChange={e => setInput(e.target.value)} placeholder={isAr ? 'اكتب وصف خبرتك هنا...' : 'Type your experience description here...'} className="min-h-[80px]" dir={isAr ? 'rtl' : 'ltr'} />
                <Button onClick={generate} disabled={loading || !input.trim()} className="w-full bg-[#0f2044] text-white hover:bg-[#162d5a]">
                  {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />{isAr ? 'جاري التحسين...' : 'Improving...'}</> : <><Sparkles className="w-4 h-4 mr-2" />{isAr ? 'حسّن بالذكاء الاصطناعي' : 'Improve with AI'}</>}
                </Button>
                {output && (
                  <div className="relative bg-emerald-500/5 border border-emerald-500/20 rounded-xl p-4">
                    <div className="flex items-center justify-between mb-2">
                      <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 text-xs"><Sparkles className="w-3 h-3 mr-1" />{isAr ? 'النتيجة المحسّنة' : 'AI Enhanced'}</Badge>
                      <Button variant="ghost" size="sm" onClick={copy} className="h-7 text-xs">{copied ? <Check className="w-3 h-3 mr-1" /> : <Copy className="w-3 h-3 mr-1" />}{copied ? (isAr ? 'تم النسخ' : 'Copied') : (isAr ? 'نسخ' : 'Copy')}</Button>
                    </div>
                    <p className="text-sm text-foreground leading-relaxed" dir={isAr ? 'rtl' : 'ltr'}>{output}<span className={loading ? 'animate-pulse' : 'hidden'}>|</span></p>
                  </div>
                )}
                <Button onClick={() => navigate('/signup')} variant="outline" className="w-full border-[#c9a84c]/30 text-[#c9a84c] hover:bg-[#c9a84c]/10">
                  {isAr ? 'سجل للحصول على تحسينات غير محدودة' : 'Sign Up for Unlimited Improvements'}<ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
