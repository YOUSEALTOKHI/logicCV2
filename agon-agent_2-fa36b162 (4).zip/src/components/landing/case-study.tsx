import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useLanguage } from "@/lib/i18n/language-context"
import { ArrowRight, TrendingUp, Clock, Target, CheckCircle } from "lucide-react"

export function CaseStudy() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  const timeline = [
    { dayEn: "Day 1", dayAr: "اليوم 1", titleEn: "Uploaded Resume", titleAr: "رفع السيرة", descEn: "ATS Score: 32%", descAr: "نتيجة ATS: 32%", color: "bg-red-500" },
    { dayEn: "Day 1", dayAr: "اليوم 1", titleEn: "AI Optimization", titleAr: "تحسين بالذكاء", descEn: "Keywords added, format fixed", descAr: "تم إضافة كلمات مفتاحية وتنسيق", color: "bg-[#c9a84c]" },
    { dayEn: "Day 2", dayAr: "اليوم 2", titleEn: "Expert Review", titleAr: "مراجعة خبير", descEn: "ATS Score: 94%", descAr: "نتيجة ATS: 94%", color: "bg-emerald-500" },
    { dayEn: "Day 7", dayAr: "اليوم 7", titleEn: "3 Interviews!", titleAr: "3 مقابلات!", descEn: "Got callbacks from top companies", descAr: "حصل على ردود من شركات كبرى", color: "bg-blue-500" },
    { dayEn: "Day 14", dayAr: "اليوم 14", titleEn: "Job Offer! 🎉", titleAr: "عرض وظيفي! 🎉", descEn: "$85K → $102K salary", descAr: "85 ألف → 102 ألف دولار", color: "bg-green-500" },
  ]

  return (
    <section className="py-20 lg:py-28 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Badge className="bg-blue-500/10 text-blue-600 border-blue-500/20 mb-4 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest">
            {isAr ? "دراسة حالة" : "Case Study"}
          </Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            {isAr ? "كيف حصل أحمد على وظيفة أحلامه" : "How Ahmed Landed His Dream Job"}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {isAr ? "من سيرة ذاتية مرفوضة إلى عرض وظيفي بزيادة 20% في الراتب" : "From a rejected resume to a job offer with 20% salary increase"}
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid lg:grid-cols-3 gap-6 mb-10">
            <Card className="border-red-500/20 bg-red-500/5">
              <CardContent className="p-6 text-center">
                <p className="text-sm font-semibold text-red-600 mb-2">{isAr ? 'قبل LogicCV' : 'Before LogicCV'}</p>
                <div className="text-4xl font-bold text-red-600 mb-2">32%</div>
                <p className="text-xs text-muted-foreground">{isAr ? 'نتيجة ATS' : 'ATS Score'}</p>
                <div className="mt-3 text-sm text-red-600/80">0 {isAr ? 'مقابلات في 3 أشهر' : 'interviews in 3 months'}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 flex items-center justify-center">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 rounded-full bg-[#c9a84c]/10 flex items-center justify-center mx-auto mb-3">
                  <TrendingUp className="w-8 h-8 text-[#c9a84c]" />
                </div>
                <p className="font-bold text-foreground">{isAr ? 'تحسين LogicCV' : 'LogicCV Optimization'}</p>
                <p className="text-xs text-muted-foreground mt-1">{isAr ? 'خلال 48 ساعة' : 'Within 48 hours'}</p>
              </CardContent>
            </Card>
            <Card className="border-emerald-500/20 bg-emerald-500/5">
              <CardContent className="p-6 text-center">
                <p className="text-sm font-semibold text-emerald-600 mb-2">{isAr ? 'بعد LogicCV' : 'After LogicCV'}</p>
                <div className="text-4xl font-bold text-emerald-600 mb-2">94%</div>
                <p className="text-xs text-muted-foreground">{isAr ? 'نتيجة ATS' : 'ATS Score'}</p>
                <div className="mt-3 text-sm text-emerald-600/80">3 {isAr ? 'مقابلات في أسبوع' : 'interviews in 1 week'}</div>
              </CardContent>
            </Card>
          </div>

          <div className="relative">
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-border hidden lg:block" />
            <div className="space-y-4">
              {timeline.map((t, i) => (
                <div key={i} className="flex gap-4 items-start">
                  <div className="hidden lg:flex flex-col items-center">
                    <div className={`w-12 h-12 rounded-full ${t.color} flex items-center justify-center text-white shadow-lg z-10`}>
                      <CheckCircle className="w-5 h-5" />
                    </div>
                  </div>
                  <Card className="flex-1 border-border/50">
                    <CardContent className="p-4 flex items-center gap-4">
                      <div className={`lg:hidden w-10 h-10 rounded-full ${t.color} flex items-center justify-center text-white flex-shrink-0`}>
                        <CheckCircle className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">{isAr ? t.dayAr : t.dayEn}</Badge>
                          <span className="font-bold text-sm">{isAr ? t.titleAr : t.titleEn}</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">{isAr ? t.descAr : t.descEn}</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
