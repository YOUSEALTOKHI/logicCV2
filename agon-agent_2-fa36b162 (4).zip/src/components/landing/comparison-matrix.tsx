// Removed - competitor comparison removed to avoid directing users to competitors
export function ComparisonMatrix() {
  return null
}
