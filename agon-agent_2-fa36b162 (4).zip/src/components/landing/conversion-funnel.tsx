import { Badge } from "@/components/ui/badge"
import { useLanguage } from "@/lib/i18n/language-context"
import { Users, Upload, Sparkles, MessageSquare, Briefcase, ArrowDown } from "lucide-react"

const steps = [
  { icon: Users, pct: "100%", labelEn: "Visitors", labelAr: "الزوار", countEn: "10,000+", countAr: "10,000+", color: "from-blue-500 to-blue-600" },
  { icon: Upload, pct: "45%", labelEn: "CV Upload", labelAr: "رفع السيرة", countEn: "4,500", countAr: "4,500", color: "from-indigo-500 to-indigo-600" },
  { icon: Sparkles, pct: "78%", labelEn: "Optimization", labelAr: "التحسين", countEn: "3,510", countAr: "3,510", color: "from-[#c9a84c] to-[#b8993f]" },
  { icon: MessageSquare, pct: "62%", labelEn: "Interviews", labelAr: "المقابلات", countEn: "2,176", countAr: "2,176", color: "from-emerald-500 to-emerald-600" },
  { icon: Briefcase, pct: "41%", labelEn: "Hired!", labelAr: "تم التوظيف!", countEn: "892", countAr: "892", color: "from-green-500 to-green-600" },
]

export function ConversionFunnel() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  return (
    <section className="py-20 lg:py-28 bg-gradient-to-br from-[#0a1628] via-[#0f2044] to-[#162d5a] relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '32px 32px' }} />
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-14">
          <Badge className="bg-[#c9a84c]/15 text-[#c9a84c] border-[#c9a84c]/20 mb-4 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest">
            {isAr ? "مسار النجاح" : "Success Path"}
          </Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            {isAr ? "من الزيارة إلى التوظيف" : "From Visit to Hired"}
          </h2>
          <p className="text-lg text-blue-200/60 max-w-2xl mx-auto">
            {isAr ? "شاهد كيف يحول LogicCV الزوار إلى موظفين" : "See how LogicCV converts visitors into hired professionals"}
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          {steps.map((step, i) => (
            <div key={i}>
              <div className="flex items-center gap-4 lg:gap-6" style={{ paddingLeft: `${i * 3}%`, paddingRight: `${i * 3}%` }}>
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center shadow-lg flex-shrink-0`}>
                  <step.icon className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1 bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white font-bold text-lg">{isAr ? step.labelAr : step.labelEn}</p>
                      <p className="text-blue-200/50 text-sm">{isAr ? step.countAr : step.countEn} {isAr ? 'مستخدم' : 'users'}</p>
                    </div>
                    <div className="text-2xl font-bold text-[#c9a84c]">{step.pct}</div>
                  </div>
                  <div className="mt-2 w-full bg-white/10 rounded-full h-2">
                    <div className={`h-full rounded-full bg-gradient-to-r ${step.color}`} style={{ width: step.pct }} />
                  </div>
                </div>
              </div>
              {i < steps.length - 1 && (
                <div className="flex justify-center py-2"><ArrowDown className="w-5 h-5 text-[#c9a84c]/40" /></div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
