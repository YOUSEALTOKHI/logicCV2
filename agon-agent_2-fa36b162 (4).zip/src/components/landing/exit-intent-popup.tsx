import { useState, useEffect, useCallback } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useLanguage } from "@/lib/i18n/language-context"
import { useNavigate } from "react-router-dom"
import { Gift, Sparkles, X, Loader2, CheckCircle, ArrowRight } from "lucide-react"

export function ExitIntentPopup() {
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [shown, setShown] = useState(false)

  const handleMouseLeave = useCallback((e: MouseEvent) => {
    if (e.clientY <= 5 && !shown && !sessionStorage.getItem('exit_popup_shown')) {
      setOpen(true)
      setShown(true)
      sessionStorage.setItem('exit_popup_shown', 'true')
    }
  }, [shown])

  useEffect(() => {
    const timer = setTimeout(() => {
      document.addEventListener('mouseleave', handleMouseLeave)
    }, 10000)
    return () => {
      clearTimeout(timer)
      document.removeEventListener('mouseleave', handleMouseLeave)
    }
  }, [handleMouseLeave])

  const handleSubmit = async () => {
    if (!email.trim()) return
    setLoading(true)
    try {
      await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, source: 'exit_intent' }),
      })
      setSubmitted(true)
    } catch {} finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden border-0">
        <div className="bg-gradient-to-br from-[#0a1628] to-[#162d5a] p-8 text-center">
          {submitted ? (
            <div>
              <CheckCircle className="w-16 h-16 text-emerald-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">{isAr ? 'تم بنجاح!' : 'Success!'}</h3>
              <p className="text-blue-200/70 mb-4">{isAr ? 'تحقق من بريدك الإلكتروني' : 'Check your email for the free scan'}</p>
              <Button onClick={() => setOpen(false)} className="bg-[#c9a84c] text-[#0a1628] hover:bg-[#d4af5a]">{isAr ? 'إغلاق' : 'Close'}</Button>
            </div>
          ) : (
            <>
              <div className="w-16 h-16 rounded-full bg-[#c9a84c]/20 flex items-center justify-center mx-auto mb-4">
                <Gift className="w-8 h-8 text-[#c9a84c]" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">
                {isAr ? 'لحظة! 🎁' : 'Wait! 🎁'}
              </h3>
              <p className="text-blue-200/70 mb-1 text-lg font-semibold">
                {isAr ? 'احصل على فحص ATS مجاني' : 'Get a Free ATS Scan'}
              </p>
              <p className="text-blue-200/50 mb-6 text-sm">
                {isAr ? 'أدخل بريدك واحصل على تقرير مفصل لسيرتك الذاتية' : 'Enter your email and get a detailed CV analysis report'}
              </p>
              <div className="flex gap-2">
                <Input value={email} onChange={e => setEmail(e.target.value)} type="email" placeholder={isAr ? 'بريدك الإلكتروني' : 'your@email.com'} className="bg-white/10 border-white/20 text-white placeholder:text-white/30" />
                <Button onClick={handleSubmit} disabled={loading} className="bg-[#c9a84c] text-[#0a1628] hover:bg-[#d4af5a] font-bold whitespace-nowrap">
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <>{isAr ? 'أرسل' : 'Send'}</>}
                </Button>
              </div>
              <button onClick={() => navigate('/signup')} className="mt-4 text-[#c9a84c] text-sm font-semibold hover:underline flex items-center justify-center gap-1 mx-auto">
                <Sparkles className="w-3 h-3" />{isAr ? 'أو ابدأ مجاناً الآن' : 'Or start free now'}<ArrowRight className="w-3 h-3" />
              </button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
