import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { useLanguage } from "@/lib/i18n/language-context"

const faqs = [
  { qEn: "What is an ATS and why does my resume need to be ATS-friendly?", qAr: "ما هو ATS ولماذا يجب أن تكون سيرتي الذاتية متوافقة معه؟", aEn: "An ATS (Applicant Tracking System) is software used by employers to collect, scan, and rank job applications. Over 98% of Fortune 500 companies use ATS. Our tool ensures your resume is optimized to pass these systems.", aAr: "ATS (نظام تتبع المتقدمين) هو برنامج تستخدمه الشركات لجمع وفحص وترتيب طلبات التوظيف. أكثر من 98% من شركات Fortune 500 تستخدم ATS. أداتنا تضمن أن سيرتك الذاتية محسّنة لتجاوز هذه الأنظمة." },
  { qEn: "How does the free ATS scanner work?", qAr: "كيف يعمل فحص ATS المجاني؟", aEn: "Upload your resume in PDF or DOCX format. Our AI-powered scanner analyzes your resume against 30+ parameters. Within seconds, you'll receive a detailed report with your ATS compatibility score.", aAr: "ارفع سيرتك الذاتية بصيغة PDF أو DOCX. يقوم ماسحنا المدعوم بالذكاء الاصطناعي بتحليل سيرتك الذاتية مقابل أكثر من 30 معيار. خلال ثوانٍ، ستحصل على تقرير مفصل مع نتيجة توافق ATS." },
  { qEn: "What's included in the professional CV writing service?", qAr: "ماذا يتضمن خدمة كتابة السيرة الذاتية الاحترافية؟", aEn: "A consultation, professionally written resume, ATS optimization, keyword enhancement, proper formatting, and revisions. You'll receive your resume in both PDF and DOCX formats.", aAr: "استشارة، سيرة ذاتية مكتوبة باحترافية، تحسين ATS، تعزيز الكلمات المفتاحية، تنسيق مناسب، ومراجعات. ستحصل على سيرتك الذاتية بصيغتي PDF و DOCX." },
  { qEn: "How long does it take to receive my professionally written CV?", qAr: "كم يستغرق استلام سيرتي الذاتية المكتوبة احترافياً؟", aEn: "Basic (48 hours), Pro (24 hours), Premium (12 hours), Express (3 hours).", aAr: "أساسي (48 ساعة)، احترافي (24 ساعة)، مميز (12 ساعة)، سريع (3 ساعات)." },
  { qEn: "What if I'm not satisfied with the CV?", qAr: "ماذا لو لم أكن راضياً عن السيرة الذاتية؟", aEn: "We offer revisions with every plan. Basic includes 1 revision, Pro and Premium offer unlimited revisions. We also offer a money-back guarantee within 7 days.", aAr: "نقدم مراجعات مع كل باقة. الأساسي يتضمن تعديل واحد، الاحترافي والمميز يقدمان تعديلات غير محدودة. كما نقدم ضمان استرداد المال خلال 7 أيام." },
  { qEn: "Is my data secure?", qAr: "هل بياناتي آمنة؟", aEn: "We use bank-level encryption (SSL/TLS). Your information is stored securely and never shared with third parties. We are fully GDPR compliant.", aAr: "نستخدم تشفير بمستوى البنوك (SSL/TLS). معلوماتك محفوظة بأمان ولا تُشارك مع أطراف ثالثة أبداً. نحن متوافقون بالكامل مع GDPR." },
]

export function FAQSection() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  return (
    <section id="faq" className="py-16 lg:py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            {isAr ? "الأسئلة الشائعة" : "Frequently Asked Questions"}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {isAr ? "اعثر على إجابات للأسئلة الشائعة" : "Find answers to common questions"}
          </p>
        </div>
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left text-foreground hover:text-[#0f2044]">
                  {isAr ? faq.qAr : faq.qEn}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  {isAr ? faq.aAr : faq.aEn}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}
