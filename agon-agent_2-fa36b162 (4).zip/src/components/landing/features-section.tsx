import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScanLine, FileSearch, DollarSign, MessageSquare, FileText, Mail, BarChart2, Target, BadgeCheck, Users, Globe, FileEdit, Sparkles, Bot, Linkedin, Shield } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

const allFeatures = [
  // Free features
  { icon: ScanLine, titleEn: "ATS Scanner", titleAr: "فحص ATS", descEn: "Check if your resume can pass applicant tracking systems instantly.", descAr: "تحقق فوراً من قدرة سيرتك الذاتية على تجاوز أنظمة تتبع المتقدمين.", plan: "free" },
  { icon: FileSearch, titleEn: "Job Matcher", titleAr: "مطابقة الوظائف", descEn: "Compare your CV with any job posting to see match percentage.", descAr: "قارن سيرتك مع أي وصف وظيفي لمعرفة نسبة التطابق.", plan: "free" },
  { icon: Globe, titleEn: "Multi-Language Support", titleAr: "دعم متعدد اللغات", descEn: "Full support for English and Arabic with professional translations.", descAr: "دعم كامل للعربية والإنجليزية بترجمات احترافية.", plan: "free" },
  { icon: Target, titleEn: "Keyword Optimization", titleAr: "تحسين الكلمات المفتاحية", descEn: "Optimize keywords to match job descriptions and boost ATS score.", descAr: "حسّن الكلمات المفتاحية لتطابق الوصف الوظيفي وتعزز نتيجة ATS.", plan: "free" },

  // Basic features
  { icon: FileEdit, titleEn: "Professional CV Writing", titleAr: "كتابة سيرة ذاتية احترافية", descEn: "Get your resume written by certified professionals with ATS optimization.", descAr: "احصل على سيرة ذاتية مكتوبة بواسطة خبراء معتمدين مع تحسين ATS.", plan: "basic" },
  { icon: BarChart2, titleEn: "Skill Gap Analysis", titleAr: "تحليل الفجوات المهارية", descEn: "Identify missing skills for your target role and get recommendations.", descAr: "حدد المهارات الناقصة للوظيفة المستهدفة واحصل على توصيات.", plan: "basic" },
  { icon: DollarSign, titleEn: "Salary Insights", titleAr: "مقياس الراتب المتوقع", descEn: "Get salary predictions based on your profile, skills, and market data.", descAr: "احصل على تقدير للراتب بناءً على ملفك ومهاراتك وبيانات السوق.", plan: "basic" },

  // Pro features
  { icon: Bot, titleEn: "AI CV Builder", titleAr: "منشئ السيرة بالذكاء الاصطناعي", descEn: "Create a professional CV in minutes with AI-powered assistance.", descAr: "أنشئ سيرة ذاتية احترافية في دقائق بمساعدة الذكاء الاصطناعي.", plan: "pro" },
  { icon: MessageSquare, titleEn: "Interview Prep", titleAr: "تحضير المقابلة", descEn: "Practice with AI-powered mock interviews tailored to your role.", descAr: "تدرب على مقابلات وهمية بالذكاء الاصطناعي مخصصة لدورك.", plan: "pro" },
  { icon: FileText, titleEn: "Cover Letter Generator", titleAr: "مولد رسائل التقديم", descEn: "Create customized cover letters for each job application.", descAr: "أنشئ رسائل تقديم مخصصة لكل طلب وظيفة.", plan: "pro" },
  { icon: Mail, titleEn: "Email Generator", titleAr: "مولد البريد الاحترافي", descEn: "Generate professional follow-up and application emails.", descAr: "أنشئ رسائل بريد احترافية للمتابعة والتقديم.", plan: "pro" },
  { icon: BadgeCheck, titleEn: "CV Verification Badge", titleAr: "شارة التحقق من السيرة", descEn: "Get a QR code on your CV that employers can scan to verify.", descAr: "احصل على رمز QR على سيرتك يمكن لأصحاب العمل مسحه للتحقق.", plan: "pro" },
  { icon: Users, titleEn: "Competitive Analysis", titleAr: "تحليل تنافسي", descEn: "Compare your resume against others in your field.", descAr: "قارن سيرتك الذاتية بالآخرين في مجالك.", plan: "pro" },

  // Premium features
  { icon: Sparkles, titleEn: "Unlimited AI Assistant", titleAr: "مساعد ذكي غير محدود", descEn: "Unlimited AI-powered CV improvements and career consultations.", descAr: "تحسينات غير محدودة للسيرة الذاتية واستشارات مهنية بالذكاء الاصطناعي.", plan: "premium" },
  { icon: Linkedin, titleEn: "LinkedIn Optimization", titleAr: "تحسين حساب لينكد إن", descEn: "AI-powered LinkedIn profile optimization with expert endorsement.", descAr: "تحسين حساب لينكد إن بالذكاء الاصطناعي مع تزكية من خبراء.", plan: "premium" },
  { icon: Shield, titleEn: "Priority Support & VIP", titleAr: "دعم ذو أولوية و VIP", descEn: "12-hour express delivery, career consultation, and priority support.", descAr: "تسليم سريع خلال 12 ساعة، استشارة مهنية، ودعم ذو أولوية.", plan: "premium" },
]

const planConfig: Record<string, { labelEn: string; labelAr: string; badgeClass: string }> = {
  free: { labelEn: "Free", labelAr: "مجاني", badgeClass: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20 dark:text-emerald-400" },
  basic: { labelEn: "Basic", labelAr: "أساسي", badgeClass: "bg-blue-500/10 text-blue-600 border-blue-500/20 dark:text-blue-400" },
  pro: { labelEn: "Pro", labelAr: "احترافي", badgeClass: "bg-[#c9a84c]/10 text-[#c9a84c] border-[#c9a84c]/20" },
  premium: { labelEn: "Premium", labelAr: "مميز", badgeClass: "bg-gradient-to-r from-[#c9a84c]/20 to-purple-500/20 text-[#0f2044] dark:text-[#c9a84c] border-[#c9a84c]/20" },
}

export function FeaturesSection() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  const renderFeatures = (plan: string) => {
    const features = allFeatures.filter(f => f.plan === plan)
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {features.map((feature, index) => {
          const cfg = planConfig[feature.plan]
          return (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 border border-border/50 bg-card/80 backdrop-blur-sm overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <CardHeader className="pb-2 relative">
                <div className="flex items-start justify-between">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0f2044] to-[#1a3a6a] flex items-center justify-center shadow-lg shadow-[#0f2044]/10 group-hover:shadow-[#0f2044]/20 transition-shadow">
                    <feature.icon className="w-6 h-6 text-[#c9a84c]" />
                  </div>
                  <Badge variant="outline" className={`text-[10px] font-semibold ${cfg.badgeClass}`}>
                    {isAr ? cfg.labelAr : cfg.labelEn}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="relative">
                <CardTitle className="text-base mb-2 font-bold">{isAr ? feature.titleAr : feature.titleEn}</CardTitle>
                <p className="text-sm text-muted-foreground leading-relaxed">{isAr ? feature.descAr : feature.descEn}</p>
              </CardContent>
            </Card>
          )
        })}
      </div>
    )
  }

  return (
    <section id="features" className="py-20 lg:py-28 bg-muted/40">
      <div className="container mx-auto px-4">
        <div className="text-center mb-14">
          <Badge className="bg-primary/5 text-primary border-primary/10 mb-4 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest">
            {isAr ? 'الأدوات والمميزات' : 'Tools & Features'}
          </Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            {isAr ? 'أدوات قوية لمستقبلك المهني' : 'Powerful Tools for Your Career'}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {isAr ? 'كل ما تحتاجه للحصول على وظيفة أحلامك - مرتبة حسب الباقة' : 'Everything you need to land your dream job — organized by plan'}
          </p>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="flex flex-wrap justify-center gap-2 mb-10 bg-transparent h-auto">
            <TabsTrigger value="all" className="rounded-full px-5 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              {isAr ? 'الكل' : 'All'}
            </TabsTrigger>
            <TabsTrigger value="free" className="rounded-full px-5 py-2 data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
              {isAr ? 'مجاني' : 'Free'}
            </TabsTrigger>
            <TabsTrigger value="basic" className="rounded-full px-5 py-2 data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              {isAr ? 'أساسي' : 'Basic'}
            </TabsTrigger>
            <TabsTrigger value="pro" className="rounded-full px-5 py-2 data-[state=active]:bg-[#c9a84c] data-[state=active]:text-[#0a1628]">
              {isAr ? 'احترافي' : 'Pro'}
            </TabsTrigger>
            <TabsTrigger value="premium" className="rounded-full px-5 py-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#c9a84c] data-[state=active]:to-purple-600 data-[state=active]:text-white">
              {isAr ? 'مميز' : 'Premium'}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {allFeatures.map((feature, index) => {
                const cfg = planConfig[feature.plan]
                return (
                  <Card key={index} className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 border border-border/50 bg-card/80 backdrop-blur-sm overflow-hidden relative">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    <CardHeader className="pb-2 relative">
                      <div className="flex items-start justify-between">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0f2044] to-[#1a3a6a] flex items-center justify-center shadow-lg shadow-[#0f2044]/10">
                          <feature.icon className="w-6 h-6 text-[#c9a84c]" />
                        </div>
                        <Badge variant="outline" className={`text-[10px] font-semibold ${cfg.badgeClass}`}>
                          {isAr ? cfg.labelAr : cfg.labelEn}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="relative">
                      <CardTitle className="text-base mb-2 font-bold">{isAr ? feature.titleAr : feature.titleEn}</CardTitle>
                      <p className="text-sm text-muted-foreground leading-relaxed">{isAr ? feature.descAr : feature.descEn}</p>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>
          <TabsContent value="free">{renderFeatures('free')}</TabsContent>
          <TabsContent value="basic">{renderFeatures('basic')}</TabsContent>
          <TabsContent value="pro">{renderFeatures('pro')}</TabsContent>
          <TabsContent value="premium">{renderFeatures('premium')}</TabsContent>
        </Tabs>
      </div>
    </section>
  )
}
