import { Upload, Search, TrendingUp, Briefcase } from "lucide-react"

const steps = [
  { icon: Upload, step: 1, title: "Upload Your CV", description: "Upload your resume for a free ATS scan", color: "bg-primary" },
  { icon: Search, step: 2, title: "Get Instant Feedback", description: "Receive an in-depth analysis of your CV", color: "bg-secondary" },
  { icon: TrendingUp, step: 3, title: "Improve & Succeed", description: "Optimize your resume and boost your chances", color: "bg-accent" },
  { icon: Briefcase, step: 4, title: "Land Your Dream Job", description: "With an optimized resume, you are 3x more likely to get interview callbacks.", color: "bg-green-500" },
]

export function HowItWorks() {
  return (
    <section id="how-it-works" className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">How LogicCV Works</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Get your resume optimized in three simple steps</p>
        </div>
        <div className="relative">
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-primary via-secondary to-accent -translate-y-1/2" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((item) => (
              <div key={item.step} className="relative flex flex-col items-center text-center">
                <div className={`relative z-10 w-20 h-20 rounded-full ${item.color} flex items-center justify-center mb-6 shadow-lg`}>
                  <item.icon className="w-8 h-8 text-primary-foreground" />
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-card rounded-full flex items-center justify-center shadow-md">
                    <span className="text-sm font-bold text-foreground">{item.step}</span>
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
