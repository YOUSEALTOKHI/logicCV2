import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useLanguage } from "@/lib/i18n/language-context"
import { Mail, Gift, CheckCircle, Loader2, FileText, Sparkles, Shield } from "lucide-react"

export function LeadCapture() {
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim()) return
    setLoading(true)
    try {
      await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, source: 'lead_capture' }),
      })
      setSuccess(true)
    } catch {} finally {
      setLoading(false)
    }
  }

  return (
    <section className="py-16 bg-gradient-to-r from-[#0f2044] via-[#162d5a] to-[#0f2044] relative overflow-hidden">
      <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
      <div className="container mx-auto px-4 relative z-10">
        <Card className="max-w-2xl mx-auto bg-white/5 backdrop-blur-xl border-white/10">
          <CardContent className="p-8 text-center">
            {success ? (
              <div className="py-4">
                <CheckCircle className="w-16 h-16 text-emerald-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">{isAr ? 'شكراً لك!' : 'Thank You!'}</h3>
                <p className="text-blue-200/70">{isAr ? 'تحقق من بريدك الإلكتروني للحصول على تقرير CV المجاني' : 'Check your email for your free CV analysis report'}</p>
              </div>
            ) : (
              <>
                <div className="w-16 h-16 rounded-2xl bg-[#c9a84c]/20 flex items-center justify-center mx-auto mb-4">
                  <Gift className="w-8 h-8 text-[#c9a84c]" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">
                  {isAr ? 'احصل على تقرير CV مجاني' : 'Get Your Free CV Analysis Report'}
                </h3>
                <p className="text-blue-200/60 mb-6 max-w-md mx-auto">
                  {isAr ? 'أدخل بريدك الإلكتروني واحصل على تحليل شامل لسيرتك الذاتية مع نصائح تحسين مخصصة' : 'Enter your email and get a comprehensive CV analysis with personalized improvement tips'}
                </p>
                <form onSubmit={handleSubmit} className="flex gap-3 max-w-md mx-auto">
                  <Input value={email} onChange={e => setEmail(e.target.value)} type="email" placeholder={isAr ? 'بريدك الإلكتروني' : 'your@email.com'} required className="bg-white/10 border-white/20 text-white placeholder:text-blue-200/40" />
                  <Button type="submit" disabled={loading} className="bg-[#c9a84c] text-[#0a1628] hover:bg-[#d4af5a] font-bold whitespace-nowrap">
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Mail className="w-4 h-4 mr-2" />{isAr ? 'أرسل' : 'Get Report'}</>}
                  </Button>
                </form>
                <div className="flex justify-center gap-6 mt-4 text-xs text-blue-200/40">
                  <span className="flex items-center gap-1"><FileText className="w-3 h-3" />{isAr ? 'تقرير مفصل' : 'Detailed Report'}</span>
                  <span className="flex items-center gap-1"><Sparkles className="w-3 h-3" />{isAr ? 'نصائح AI' : 'AI Tips'}</span>
                  <span className="flex items-center gap-1"><Shield className="w-3 h-3" />{isAr ? 'لا سبام' : 'No Spam'}</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
