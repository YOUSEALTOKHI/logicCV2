import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { useLanguage } from "@/lib/i18n/language-context"
import { ScanLine, CheckCircle, XCircle, AlertTriangle, Loader2, Sparkles, ArrowRight } from "lucide-react"
import { useNavigate } from "react-router-dom"

const ATS_KEYWORDS = [
  "experience", "skills", "education", "achievements", "results", "managed", "developed",
  "leadership", "communication", "teamwork", "project management", "analytical",
  "problem-solving", "certified", "bachelor", "master", "proficient", "responsible",
  "collaborated", "implemented", "increased", "decreased", "optimized", "delivered"
]

interface SimResult {
  pass: boolean
  score: number
  found: string[]
  missing: string[]
  suggestions: string[]
}

export function LiveATSSimulator() {
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const navigate = useNavigate()
  const [text, setText] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<SimResult | null>(null)

  const analyze = () => {
    if (!text.trim()) return
    setLoading(true)
    setTimeout(() => {
      const lower = text.toLowerCase()
      const found = ATS_KEYWORDS.filter(k => lower.includes(k))
      const missing = ATS_KEYWORDS.filter(k => !lower.includes(k)).slice(0, 6)
      const wordCount = text.split(/\s+/).length
      const hasEmail = /[\w.-]+@[\w.-]+/.test(text)
      const hasPhone = /[\d\-+()]{7,}/.test(text)
      const hasSections = /experience|education|skills/i.test(text)
      let score = Math.min(100, Math.round((found.length / 12) * 50 + (wordCount > 100 ? 15 : 5) + (hasEmail ? 10 : 0) + (hasPhone ? 10 : 0) + (hasSections ? 15 : 0)))
      const suggestions: string[] = []
      if (!hasEmail) suggestions.push(isAr ? "أضف بريدك الإلكتروني" : "Add your email address")
      if (!hasPhone) suggestions.push(isAr ? "أضف رقم هاتفك" : "Add your phone number")
      if (!hasSections) suggestions.push(isAr ? "أضف أقسام: الخبرة، التعليم، المهارات" : "Add sections: Experience, Education, Skills")
      if (wordCount < 150) suggestions.push(isAr ? "أضف المزيد من التفاصيل (150+ كلمة)" : "Add more detail (150+ words recommended)")
      if (found.length < 5) suggestions.push(isAr ? "استخدم كلمات مفتاحية أكثر مثل: managed, developed, implemented" : "Use more action keywords: managed, developed, implemented")
      missing.slice(0, 3).forEach(k => suggestions.push(isAr ? `أضف كلمة: ${k}` : `Add keyword: "${k}"`))
      setResult({ pass: score >= 60, score, found, missing, suggestions: suggestions.slice(0, 5) })
      setLoading(false)
    }, 1500)
  }

  return (
    <section id="ats-simulator" className="py-20 lg:py-28 bg-gradient-to-b from-background to-muted/40">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 mb-4 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest">
            {isAr ? "تجربة مباشرة" : "Live Demo"}
          </Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            {isAr ? "محاكاة ATS المباشرة" : "Live ATS Simulation"}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {isAr ? "الصق سيرتك الذاتية وشاهد النتيجة فوراً - هل ستتجاوز أنظمة التتبع؟" : "Paste your resume and see instantly - will it pass ATS systems?"}
          </p>
        </div>

        <div className="max-w-4xl mx-auto grid lg:grid-cols-2 gap-6">
          <Card className="border-border/50">
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <ScanLine className="w-5 h-5 text-primary" />
                <h3 className="font-bold">{isAr ? "الصق سيرتك الذاتية" : "Paste Your Resume"}</h3>
              </div>
              <Textarea
                value={text}
                onChange={e => { setText(e.target.value); setResult(null) }}
                placeholder={isAr ? "الصق نص سيرتك الذاتية هنا..." : "Paste your resume text here..."}
                className="min-h-[250px] text-sm"
                dir={isAr ? "rtl" : "ltr"}
              />
              <Button onClick={analyze} disabled={loading || !text.trim()} className="w-full bg-[#0f2044] text-white hover:bg-[#162d5a]">
                {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />{isAr ? "جاري الفحص..." : "Scanning..."}</> : <><ScanLine className="w-4 h-4 mr-2" />{isAr ? "فحص ATS الآن" : "Run ATS Check"}</>}
              </Button>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="p-6">
              {!result && !loading && (
                <div className="flex flex-col items-center justify-center h-full text-center py-12">
                  <ScanLine className="w-16 h-16 text-muted-foreground/30 mb-4" />
                  <p className="text-muted-foreground">{isAr ? "الصق سيرتك وابدأ الفحص" : "Paste your resume and run the check"}</p>
                </div>
              )}
              {loading && (
                <div className="flex flex-col items-center justify-center h-full py-12">
                  <Loader2 className="w-12 h-12 animate-spin text-primary mb-4" />
                  <p className="text-muted-foreground">{isAr ? "جاري تحليل سيرتك..." : "Analyzing your resume..."}</p>
                </div>
              )}
              {result && (
                <div className="space-y-5">
                  <div className="text-center">
                    <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-lg font-bold ${result.pass ? 'bg-emerald-500/10 text-emerald-600' : 'bg-red-500/10 text-red-600'}`}>
                      {result.pass ? <CheckCircle className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
                      {result.pass ? (isAr ? 'ناجح' : 'PASS') : (isAr ? 'راسب' : 'FAIL')}
                    </div>
                    <div className={`text-4xl font-bold mt-3 ${result.score >= 80 ? 'text-emerald-600' : result.score >= 60 ? 'text-yellow-600' : 'text-red-600'}`}>{result.score}%</div>
                  </div>
                  <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                    <div className={`h-full rounded-full transition-all duration-1000 ${result.score >= 80 ? 'bg-emerald-500' : result.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`} style={{ width: `${result.score}%` }} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold mb-2 flex items-center gap-1"><CheckCircle className="w-4 h-4 text-emerald-500" />{isAr ? 'كلمات مفتاحية موجودة' : 'Keywords Found'} ({result.found.length})</p>
                    <div className="flex flex-wrap gap-1">
                      {result.found.slice(0, 8).map(k => <Badge key={k} variant="outline" className="text-xs bg-emerald-500/5 text-emerald-600 border-emerald-500/20">{k}</Badge>)}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-semibold mb-2 flex items-center gap-1"><AlertTriangle className="w-4 h-4 text-amber-500" />{isAr ? 'تحسينات مطلوبة' : 'Improvements'}</p>
                    <ul className="space-y-1.5">
                      {result.suggestions.map((s, i) => <li key={i} className="text-xs text-muted-foreground flex items-start gap-1.5"><span className="text-amber-500 mt-0.5">→</span>{s}</li>)}
                    </ul>
                  </div>
                  <Button onClick={() => navigate('/signup')} className="w-full bg-[#c9a84c] text-[#0a1628] hover:bg-[#d4af5a] font-bold">
                    <Sparkles className="w-4 h-4 mr-2" />{isAr ? 'احصل على تحليل كامل مجاناً' : 'Get Full Analysis Free'}<ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
