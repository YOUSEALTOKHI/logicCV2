import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { useLanguage } from "@/lib/i18n/language-context"
import { Zap, Award, Star, TrendingUp } from "lucide-react"

export function PerformanceIndicators() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  const indicators = [
    { icon: Zap, titleEn: "Platform Performance", titleAr: "أداء المنصة", pct: 98, labelEn: "Uptime & Speed", labelAr: "وقت التشغيل والسرعة", color: "bg-emerald-500" },
    { icon: Award, titleEn: "Feature Completion", titleAr: "اكتمال المميزات", pct: 95, labelEn: "All tools active", labelAr: "جميع الأدوات فعالة", color: "bg-blue-500" },
    { icon: Star, titleEn: "User Satisfaction", titleAr: "رضا المستخدمين", pct: 97, labelEn: "Based on 500+ reviews", labelAr: "بناءً على 500+ تقييم", color: "bg-[#c9a84c]" },
    { icon: TrendingUp, titleEn: "Market Readiness", titleAr: "جاهزية السوق", pct: 92, labelEn: "Enterprise ready", labelAr: "جاهز للمؤسسات", color: "bg-purple-500" },
  ]

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-center gap-3 mb-10">
          <Badge className="bg-[#c9a84c]/10 text-[#c9a84c] border-[#c9a84c]/20 px-4 py-1.5"><Star className="w-3 h-3 mr-1" />{isAr ? 'الأعلى تقييماً' : 'Top Rated'}</Badge>
          <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 px-4 py-1.5"><Award className="w-3 h-3 mr-1" />{isAr ? 'أفضل منصة عربية' : 'Best Arabic Platform'}</Badge>
          <Badge className="bg-blue-500/10 text-blue-600 border-blue-500/20 px-4 py-1.5"><Zap className="w-3 h-3 mr-1" />{isAr ? 'الأسرع في السوق' : 'Fastest in Market'}</Badge>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto">
          {indicators.map((ind, i) => (
            <Card key={i} className="border-border/50">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-3">
                  <ind.icon className={`w-5 h-5 ${ind.color === 'bg-emerald-500' ? 'text-emerald-500' : ind.color === 'bg-blue-500' ? 'text-blue-500' : ind.color === 'bg-[#c9a84c]' ? 'text-[#c9a84c]' : 'text-purple-500'}`} />
                  <span className="text-sm font-bold">{isAr ? ind.titleAr : ind.titleEn}</span>
                </div>
                <div className="flex items-end gap-1 mb-2">
                  <span className="text-3xl font-bold">{ind.pct}</span><span className="text-muted-foreground text-sm mb-1">%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2 mb-2">
                  <div className={`h-full rounded-full ${ind.color} transition-all duration-1000`} style={{ width: `${ind.pct}%` }} />
                </div>
                <p className="text-xs text-muted-foreground">{isAr ? ind.labelAr : ind.labelEn}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
