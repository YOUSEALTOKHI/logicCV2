import { useEffect, useState, useRef } from "react"
import { useLanguage } from "@/lib/i18n/language-context"
import { FileText, Users, MessageSquare, TrendingUp } from "lucide-react"

function useAnimatedCounter(target: number, duration = 2000) {
  const [count, setCount] = useState(0)
  const ref = useRef<HTMLDivElement>(null)
  const started = useRef(false)

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !started.current) {
        started.current = true
        const start = Date.now()
        const tick = () => {
          const elapsed = Date.now() - start
          const progress = Math.min(elapsed / duration, 1)
          const eased = 1 - Math.pow(1 - progress, 3)
          setCount(Math.round(eased * target))
          if (progress < 1) requestAnimationFrame(tick)
        }
        requestAnimationFrame(tick)
      }
    }, { threshold: 0.3 })
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [target, duration])

  return { count, ref }
}

// Base fake numbers - real signups add on top
const BASE_STATS = { cvs_optimized: 1847, active_users: 342, interviews_generated: 5621, cvs_today: 37 }

export function RealtimeCounters() {
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const [stats, setStats] = useState(BASE_STATS)

  useEffect(() => {
    // Fetch real stats from DB and add to base
    fetch('/api/stats').then(r => r.json()).then(data => {
      if (data && !data.error) {
        setStats(prev => ({
          cvs_optimized: BASE_STATS.cvs_optimized + (parseInt(data.cvs_optimized) || 0),
          active_users: BASE_STATS.active_users + (parseInt(data.active_users) || 0),
          interviews_generated: BASE_STATS.interviews_generated + (parseInt(data.interviews_generated) || 0),
          cvs_today: BASE_STATS.cvs_today + (parseInt(data.cvs_today) || 0),
        }))
      }
    }).catch(() => {})

    // Simulate live increments for engagement
    const interval = setInterval(() => {
      setStats(prev => ({
        ...prev,
        cvs_today: prev.cvs_today + (Math.random() > 0.7 ? 1 : 0),
        active_users: Math.max(prev.active_users + (Math.random() > 0.5 ? 1 : -1), BASE_STATS.active_users - 20),
      }))
    }, 8000)
    return () => clearInterval(interval)
  }, [])

  const counters = [
    { icon: FileText, value: stats.cvs_today, labelEn: "CVs Optimized Today", labelAr: "سير ذاتية محسّنة اليوم", color: "text-[#c9a84c]", bg: "bg-[#c9a84c]/10" },
    { icon: Users, value: stats.active_users, labelEn: "Active Users Now", labelAr: "مستخدمون نشطون الآن", color: "text-emerald-500", bg: "bg-emerald-500/10", live: true },
    { icon: MessageSquare, value: stats.interviews_generated, labelEn: "Interviews Generated", labelAr: "مقابلات تم الحصول عليها", color: "text-blue-500", bg: "bg-blue-500/10" },
    { icon: TrendingUp, value: stats.cvs_optimized, labelEn: "Total CVs Optimized", labelAr: "إجمالي السير المحسّنة", color: "text-purple-500", bg: "bg-purple-500/10" },
  ]

  return (
    <section className="py-12 bg-background border-y border-border/50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {counters.map((c, i) => {
            const { count, ref } = useAnimatedCounter(c.value)
            return (
              <div key={i} ref={ref} className="text-center">
                <div className={`w-14 h-14 rounded-2xl ${c.bg} flex items-center justify-center mx-auto mb-3`}>
                  <c.icon className={`w-7 h-7 ${c.color}`} />
                </div>
                <div className="flex items-center justify-center gap-1">
                  <span className={`text-3xl lg:text-4xl font-bold ${c.color}`}>{count.toLocaleString()}</span>
                  {c.live && <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />}
                </div>
                <p className="text-sm text-muted-foreground mt-1">{isAr ? c.labelAr : c.labelEn}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
