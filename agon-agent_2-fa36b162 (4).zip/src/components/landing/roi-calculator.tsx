import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { useLanguage } from "@/lib/i18n/language-context"
import { Calculator, TrendingUp, DollarSign, Target, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useNavigate } from "react-router-dom"

export function ROICalculator() {
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const navigate = useNavigate()
  const [applications, setApplications] = useState(20)
  const [salary, setSalary] = useState(60000)

  const currentRate = 0.05
  const optimizedRate = 0.18
  const currentInterviews = Math.round(applications * currentRate)
  const optimizedInterviews = Math.round(applications * optimizedRate)
  const salaryIncrease = Math.round(salary * 0.15)
  const serviceCost = 79
  const roi = Math.round(((salaryIncrease - serviceCost) / serviceCost) * 100)

  return (
    <section className="py-20 lg:py-28 bg-gradient-to-b from-muted/40 to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Badge className="bg-[#c9a84c]/10 text-[#c9a84c] border-[#c9a84c]/20 mb-4 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest">
            <Calculator className="w-3 h-3 mr-1" />{isAr ? "حاسبة العائد" : "ROI Calculator"}
          </Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            {isAr ? "احسب عائد استثمارك" : "Calculate Your Return on Investment"}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {isAr ? "اكتشف كم ستوفر وكم ستكسب بتحسين سيرتك الذاتية" : "See how much you'll save and earn by optimizing your resume"}
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="border-border/50 overflow-hidden">
            <CardContent className="p-0">
              <div className="grid lg:grid-cols-2">
                <div className="p-8 space-y-8">
                  <div>
                    <div className="flex justify-between mb-3">
                      <label className="text-sm font-semibold">{isAr ? 'عدد التقديمات شهرياً' : 'Monthly Applications'}</label>
                      <span className="text-sm font-bold text-primary">{applications}</span>
                    </div>
                    <Slider value={[applications]} onValueChange={v => setApplications(v[0])} min={5} max={100} step={5} className="w-full" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-3">
                      <label className="text-sm font-semibold">{isAr ? 'الراتب المتوقع (سنوي)' : 'Expected Salary (Annual)'}</label>
                      <span className="text-sm font-bold text-primary">${salary.toLocaleString()}</span>
                    </div>
                    <Slider value={[salary]} onValueChange={v => setSalary(v[0])} min={20000} max={200000} step={5000} className="w-full" />
                  </div>
                  <div className="bg-muted/50 rounded-xl p-4 space-y-3">
                    <div className="flex justify-between text-sm"><span className="text-muted-foreground">{isAr ? 'تكلفة الخدمة' : 'Service Cost'}</span><span className="font-bold">${serviceCost}</span></div>
                    <div className="flex justify-between text-sm"><span className="text-muted-foreground">{isAr ? 'زيادة الراتب المتوقعة' : 'Expected Salary Increase'}</span><span className="font-bold text-emerald-600">+${salaryIncrease.toLocaleString()}</span></div>
                    <div className="border-t pt-3 flex justify-between"><span className="font-semibold">{isAr ? 'العائد على الاستثمار' : 'ROI'}</span><span className="font-bold text-2xl text-[#c9a84c]">{roi}%</span></div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-[#0a1628] to-[#162d5a] p-8 text-white flex flex-col justify-center">
                  <h3 className="text-xl font-bold mb-6">{isAr ? 'النتائج المتوقعة' : 'Expected Results'}</h3>
                  <div className="space-y-5">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center"><Target className="w-6 h-6 text-[#c9a84c]" /></div>
                      <div>
                        <div className="text-sm text-blue-200/60">{isAr ? 'المقابلات' : 'Interviews'}</div>
                        <div className="flex items-center gap-2"><span className="text-red-400 line-through">{currentInterviews}</span><ArrowRight className="w-4 h-4 text-[#c9a84c]" /><span className="text-2xl font-bold text-[#c9a84c]">{optimizedInterviews}</span></div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center"><TrendingUp className="w-6 h-6 text-emerald-400" /></div>
                      <div>
                        <div className="text-sm text-blue-200/60">{isAr ? 'معدل القبول' : 'Acceptance Rate'}</div>
                        <div className="flex items-center gap-2"><span className="text-red-400 line-through">{Math.round(currentRate * 100)}%</span><ArrowRight className="w-4 h-4 text-emerald-400" /><span className="text-2xl font-bold text-emerald-400">{Math.round(optimizedRate * 100)}%</span></div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center"><DollarSign className="w-6 h-6 text-[#c9a84c]" /></div>
                      <div>
                        <div className="text-sm text-blue-200/60">{isAr ? 'زيادة الراتب' : 'Salary Boost'}</div>
                        <div className="text-2xl font-bold text-[#c9a84c]">+${salaryIncrease.toLocaleString()}/{isAr ? 'سنة' : 'yr'}</div>
                      </div>
                    </div>
                  </div>
                  <Button onClick={() => navigate('/signup')} className="mt-8 bg-[#c9a84c] text-[#0a1628] hover:bg-[#d4af5a] font-bold w-full">
                    {isAr ? 'ابدأ الآن وحقق العائد' : 'Start Now & Get Returns'}<ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
