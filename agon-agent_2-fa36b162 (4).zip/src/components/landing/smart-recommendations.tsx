import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useLanguage } from "@/lib/i18n/language-context"
import { useNavigate } from "react-router-dom"
import { GraduationCap, Briefcase, Rocket, ArrowRight, Sparkles } from "lucide-react"

const personas = [
  {
    id: 'beginner',
    iconComp: GraduationCap,
    titleEn: "I'm a Fresh Graduate",
    titleAr: "أنا خريج جديد",
    descEn: "New to the job market? We'll help you build a standout resume from scratch.",
    descAr: "جديد في سوق العمل؟ سنساعدك على بناء سيرة ذاتية مميزة من الصفر.",
    ctaEn: "Build My First CV",
    ctaAr: "ابنِ أول سيرة ذاتية",
    features: ["CV Builder", "ATS Scanner", "Templates"],
    featuresAr: ["منشئ السيرة", "فحص ATS", "قوالب"],
    color: "from-blue-500 to-indigo-600",
    route: "/signup",
  },
  {
    id: 'professional',
    iconComp: Briefcase,
    titleEn: "I'm a Professional",
    titleAr: "أنا محترف",
    descEn: "Looking to level up? Optimize your existing CV and land better opportunities.",
    descAr: "تبحث عن ترقية؟ حسّن سيرتك الحالية واحصل على فرص أفضل.",
    ctaEn: "Optimize My CV",
    ctaAr: "حسّن سيرتي الذاتية",
    features: ["ATS Optimization", "Job Matcher", "AI Assistant"],
    featuresAr: ["تحسين ATS", "مطابقة الوظائف", "مساعد ذكي"],
    color: "from-[#c9a84c] to-[#b8993f]",
    route: "/signup",
  },
  {
    id: 'executive',
    iconComp: Rocket,
    titleEn: "I'm an Executive",
    titleAr: "أنا تنفيذي",
    descEn: "C-level or senior? Get premium, white-glove CV writing and LinkedIn optimization.",
    descAr: "مدير تنفيذي أو كبير؟ احصل على كتابة سيرة ذاتية VIP وتحسين لينكد إن.",
    ctaEn: "Get VIP Service",
    ctaAr: "احصل على خدمة VIP",
    features: ["Expert Writing", "LinkedIn", "Interview Prep"],
    featuresAr: ["كتابة خبير", "لينكد إن", "تحضير المقابلة"],
    color: "from-purple-500 to-purple-700",
    route: "/payment?plan=premium",
  },
]

export function SmartRecommendations() {
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const navigate = useNavigate()
  const [selected, setSelected] = useState<string | null>(null)

  return (
    <section className="py-20 lg:py-28 bg-muted/40">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Badge className="bg-primary/5 text-primary border-primary/10 mb-4 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest">
            <Sparkles className="w-3 h-3 mr-1" />{isAr ? 'مخصص لك' : 'Personalized'}
          </Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            {isAr ? 'ما هو مستواك المهني؟' : "What's Your Career Level?"}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {isAr ? 'اختر مستواك واحصل على توصيات مخصصة' : 'Choose your level and get personalized recommendations'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {personas.map(p => (
            <Card
              key={p.id}
              className={`cursor-pointer transition-all duration-300 border-2 ${selected === p.id ? 'border-primary shadow-xl scale-[1.02]' : 'border-border/50 hover:border-primary/30 hover:shadow-lg hover:-translate-y-1'}`}
              onClick={() => setSelected(p.id)}
            >
              <CardContent className="p-6 text-center">
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${p.color} flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                  <p.iconComp className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-bold mb-2">{isAr ? p.titleAr : p.titleEn}</h3>
                <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{isAr ? p.descAr : p.descEn}</p>
                <div className="flex flex-wrap justify-center gap-1.5 mb-4">
                  {(isAr ? p.featuresAr : p.features).map((f, i) => <Badge key={i} variant="outline" className="text-xs">{f}</Badge>)}
                </div>
                <Button onClick={() => navigate(p.route)} className={`w-full font-bold ${selected === p.id ? 'bg-[#c9a84c] text-[#0a1628] hover:bg-[#d4af5a]' : ''}`}>
                  {isAr ? p.ctaAr : p.ctaEn}<ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
