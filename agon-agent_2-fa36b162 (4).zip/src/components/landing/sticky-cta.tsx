import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/lib/i18n/language-context"
import { useNavigate } from "react-router-dom"
import { Sparkles, X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

export function StickyCTA() {
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const navigate = useNavigate()
  const [visible, setVisible] = useState(false)
  const [dismissed, setDismissed] = useState(false)

  useEffect(() => {
    const onScroll = () => {
      setVisible(window.scrollY > 800)
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  if (dismissed) return null

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-0 left-0 right-0 z-50 bg-gradient-to-r from-[#0a1628] via-[#0f2044] to-[#162d5a] border-t border-white/10 shadow-2xl"
        >
          <div className="container mx-auto px-4 py-3 flex items-center justify-between gap-4">
            <div className="hidden sm:block">
              <p className="text-white font-bold text-sm">
                {isAr ? '🚀 حسّن سيرتك الذاتية واحصل على مقابلات أكثر بـ 3 أضعاف' : '🚀 Get 3x More Interviews in Just 7 Days'}
              </p>
              <p className="text-blue-200/50 text-xs">
                {isAr ? 'فحص ATS مجاني • نتائج فورية • بدون بطاقة ائتمان' : 'Free ATS Scan • Instant Results • No Credit Card'}
              </p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0 ml-auto">
              <Button onClick={() => navigate('/signup')} className="bg-[#c9a84c] text-[#0a1628] hover:bg-[#d4af5a] font-bold shadow-lg shadow-[#c9a84c]/20 text-sm">
                <Sparkles className="w-4 h-4 mr-1" />{isAr ? 'ابدأ الفحص المجاني' : 'Start Free Scan Now'}
              </Button>
              <button onClick={() => setDismissed(true)} className="text-white/40 hover:text-white/70 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
