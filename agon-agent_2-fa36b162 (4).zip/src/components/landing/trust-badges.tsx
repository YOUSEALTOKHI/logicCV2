import { useLanguage } from "@/lib/i18n/language-context"
import { Shield, Lock, Award, Users, Globe, CheckCircle } from "lucide-react"

export function TrustBadges() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  const badges = [
    { icon: Shield, labelEn: "SSL Secured", labelAr: "مشفر بـ SSL", color: "text-emerald-500" },
    { icon: Lock, labelEn: "GDPR Compliant", labelAr: "متوافق مع GDPR", color: "text-blue-500" },
    { icon: Award, labelEn: "Top Rated Platform", labelAr: "منصة مصنفة الأولى", color: "text-[#c9a84c]" },
    { icon: Users, labelEn: "Used by Professionals", labelAr: "يستخدمها المحترفون", color: "text-purple-500" },
    { icon: Globe, labelEn: "Best Arabic Platform", labelAr: "أفضل منصة عربية", color: "text-indigo-500" },
    { icon: CheckCircle, labelEn: "Money-Back Guarantee", labelAr: "ضمان استرداد المال", color: "text-emerald-600" },
  ]

  return (
    <section className="py-8 bg-muted/30 border-y border-border/30">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-center gap-x-8 gap-y-4">
          {badges.map((b, i) => (
            <div key={i} className="flex items-center gap-2 text-sm">
              <b.icon className={`w-5 h-5 ${b.color}`} />
              <span className="text-muted-foreground font-medium">{isAr ? b.labelAr : b.labelEn}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
