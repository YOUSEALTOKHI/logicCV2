import { Link } from "react-router-dom"
import { Mail, Phone, MapPin, Twitter, Linkedin, Instagram, Facebook, Youtube } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { LogicCVLogo } from "@/components/ui/logiccv-logo"

export function Footer() {
  const { language, dir } = useLanguage()

  const c = language === 'ar' ? {
    description: "منصة تحسين السيرة الذاتية بالذكاء الاصطناعي. حسّن سيرتك الذاتية لتتجاوز أنظمة ATS واحصل على وظيفة أحلامك.",
    quickLinks: "روابط سريعة", howItWorks: "كيف يعمل", features: "المميزات",
    pricing: "الأسعار", blog: "المدونة", about: "من نحن",
    support: "الدعم", faq: "الأسئلة الشائعة", contactUs: "اتصل بنا",
    privacy: "سياسة الخصوصية", terms: "شروط الخدمة", refund: "سياسة الاسترداد",
    contact: "التواصل", sslSecured: "مشفر بـ SSL", gdprCompliant: "متوافق مع GDPR",
    moneyBack: "ضمان استرداد المال",
    copyright: `${new Date().getFullYear()} LogicCV. جميع الحقوق محفوظة.`,
    madeWith: "صُنع بـ ❤️ لمساعدة المهنيين حول العالم",
  } : {
    description: "AI-powered resume optimization platform. Get your CV past ATS systems and land your dream job.",
    quickLinks: "Quick Links", howItWorks: "How It Works", features: "Features",
    pricing: "Pricing", blog: "Blog", about: "About Us",
    support: "Support", faq: "FAQ", contactUs: "Contact Us",
    privacy: "Privacy Policy", terms: "Terms of Service", refund: "Refund Policy",
    contact: "Contact", sslSecured: "SSL Secured", gdprCompliant: "GDPR Compliant",
    moneyBack: "Money Back Guarantee",
    copyright: `${new Date().getFullYear()} LogicCV. All rights reserved.`,
    madeWith: "Made with ❤️ to help professionals worldwide",
  }

  const socialLinks = [
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Linkedin, href: "#", label: "LinkedIn" },
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Facebook, href: "#", label: "Facebook" },
    { icon: Youtube, href: "#", label: "YouTube" },
  ]

  return (
    <footer className="relative overflow-hidden" dir={dir}>
      {/* Gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a1628] via-[#0f2044] to-[#0a1628]" />
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

      <div className="container mx-auto px-4 py-14 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div className="space-y-5">
            <Link to="/" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
              <LogicCVLogo variant="light" size="md" />
            </Link>
            <p className="text-sm text-blue-100/60 leading-relaxed">{c.description}</p>
            <div className="flex items-center gap-3">
              {socialLinks.map(({ icon: Icon, href, label }) => (
                <a key={label} href={href} aria-label={label} className="w-9 h-9 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/15 hover:border-white/20 transition-all duration-200">
                  <Icon className="w-4 h-4 text-blue-100/70" />
                </a>
              ))}
            </div>
          </div>
          <div>
            <h3 className="font-bold text-white text-base mb-5">{c.quickLinks}</h3>
            <ul className="space-y-3">
              {[
                { href: "/#how-it-works", label: c.howItWorks },
                { href: "/#features", label: c.features },
                { href: "/#pricing", label: c.pricing },
                { href: "/blog", label: c.blog },
                { href: "/about", label: c.about },
              ].map((l, i) => (
                <li key={i}>
                  <Link to={l.href} className="text-sm text-blue-100/60 hover:text-white transition-colors duration-200 flex items-center gap-1.5">
                    <span className="w-1 h-1 rounded-full bg-[#c9a84c]/60" />
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-white text-base mb-5">{c.support}</h3>
            <ul className="space-y-3">
              {[
                { href: "/#faq", label: c.faq },
                { href: "#", label: c.contactUs },
                { href: "/privacy", label: c.privacy },
                { href: "/terms", label: c.terms },
                { href: "/refund", label: c.refund },
              ].map((l, i) => (
                <li key={i}>
                  <a href={l.href} className="text-sm text-blue-100/60 hover:text-white transition-colors duration-200 flex items-center gap-1.5">
                    <span className="w-1 h-1 rounded-full bg-[#c9a84c]/60" />
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-white text-base mb-5">{c.contact}</h3>
            <ul className="space-y-4">
              <li className="flex items-center gap-3 text-sm text-blue-100/60">
                <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center shrink-0">
                  <Mail className="w-4 h-4 text-[#c9a84c]" />
                </div>
                support@logiccv.com
              </li>
              <li className="flex items-center gap-3 text-sm text-blue-100/60">
                <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center shrink-0">
                  <Phone className="w-4 h-4 text-[#c9a84c]" />
                </div>
                +1 (555) 123-4567
              </li>
              <li className="flex items-start gap-3 text-sm text-blue-100/60">
                <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center shrink-0 mt-0.5">
                  <MapPin className="w-4 h-4 text-[#c9a84c]" />
                </div>
                <span>123 Career Street,<br />San Francisco, CA 94105</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex flex-col sm:flex-row items-center gap-2">
              <p className="text-sm text-blue-100/50">&copy; {c.copyright}</p>
              <span className="hidden sm:inline text-blue-100/20">•</span>
              <p className="text-xs text-blue-100/30">{c.madeWith}</p>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-xs text-blue-100/40 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
                {c.sslSecured}
              </span>
              <span className="text-xs text-blue-100/40">{c.gdprCompliant}</span>
              <span className="text-xs text-blue-100/40">{c.moneyBack}</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
