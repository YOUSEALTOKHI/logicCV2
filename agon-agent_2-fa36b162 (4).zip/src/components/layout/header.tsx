import { useState, useEffect } from "react"
import { Link, useNavigate } from "react-router-dom"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, Moon, Sun, Globe, Check, Settings, LogOut, User } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { LogicCVLogo } from "@/components/ui/logiccv-logo"
import { useAuth } from "@/lib/auth/auth-context"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export function Header() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const { theme, setTheme } = useTheme()
  const { language, setLanguage, t, dir } = useLanguage()
  const { user, signOut } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener("scroll", onScroll, { passive: true })
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  const navLinks = [
    { href: "/#how-it-works", label: t.nav.howItWorks },
    { href: "/#features", label: t.nav.features },
    { href: "/#pricing", label: t.nav.pricing },
    { href: "/blog", label: t.nav.blog },
    { href: "/about", label: t.nav.about },
  ]

  const handleSignOut = async () => {
    await signOut()
    navigate("/")
  }

  const handleNavClick = (href: string) => {
    if (href.startsWith("/#")) {
      const id = href.slice(2)
      if (window.location.pathname === "/") {
        const el = document.getElementById(id)
        if (el) el.scrollIntoView({ behavior: "smooth" })
      } else {
        navigate("/")
        setTimeout(() => {
          const el = document.getElementById(id)
          if (el) el.scrollIntoView({ behavior: "smooth" })
        }, 300)
      }
    } else {
      navigate(href)
    }
  }

  /* ── colour helpers ──
     • Before scroll → transparent header, text is always white (over dark hero)
     • After scroll  → solid bg, text adapts to light/dark mode              */
  const navTextClass = scrolled
    ? "text-gray-700 hover:text-gray-900 dark:text-gray-200 dark:hover:text-white"
    : "text-white/70 hover:text-white"

  const iconBtnClass = scrolled
    ? "text-gray-600 hover:text-gray-900 hover:bg-black/5 dark:text-gray-300 dark:hover:text-white dark:hover:bg-white/10"
    : "text-white/60 hover:text-white hover:bg-white/10"

  const loginBtnClass = scrolled
    ? "text-gray-700 hover:text-gray-900 hover:bg-black/5 dark:text-gray-200 dark:hover:text-white dark:hover:bg-white/10"
    : "text-white/70 hover:text-white hover:bg-white/10"

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 w-full h-20 transition-all duration-300 ${
        scrolled
          ? "bg-white/80 dark:bg-gray-900/90 backdrop-blur-xl border-b border-black/[0.06] dark:border-white/[0.08] shadow-sm"
          : "bg-transparent border-b border-transparent"
      }`}
      dir={dir}
    >
      <div className="container mx-auto flex h-full items-center justify-between px-4 lg:px-6">
        <Link to="/" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex items-center gap-2">
          <LogicCVLogo size="md" variant={scrolled ? "auto" : "light"} />
        </Link>

        <nav className="hidden md:flex items-center gap-8 mx-4">
          {navLinks.map((link) => (
            <button
              key={link.href}
              onClick={() => handleNavClick(link.href)}
              className={`text-[13px] font-semibold tracking-wide transition-colors duration-200 bg-transparent border-none cursor-pointer ${navTextClass}`}
              style={{ fontFamily: "'Playfair Display', 'Noto Kufi Arabic', serif" }}
            >
              {link.label}
            </button>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-1.5">
          {/* Theme toggle */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className={`transition-colors ${iconBtnClass}`}>
                <Sun className="h-[18px] w-[18px] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <Moon className="absolute h-[18px] w-[18px] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setTheme("light")} className="flex items-center gap-2">
                <Sun className="w-4 h-4" /> {language === 'ar' ? 'فاتح' : 'Light'} {theme === "light" && <Check className="w-4 h-4 ms-auto" />}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTheme("dark")} className="flex items-center gap-2">
                <Moon className="w-4 h-4" /> {language === 'ar' ? 'داكن' : 'Dark'} {theme === "dark" && <Check className="w-4 h-4 ms-auto" />}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTheme("system")} className="flex items-center gap-2">
                <Settings className="w-4 h-4" /> {language === 'ar' ? 'تلقائي' : 'System'} {theme === "system" && <Check className="w-4 h-4 ms-auto" />}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Language toggle */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className={`transition-colors ${iconBtnClass}`}>
                <Globe className="h-[18px] w-[18px]" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setLanguage("en")} className="flex items-center gap-2">
                🇺🇸 English {language === "en" && <Check className="w-4 h-4 ms-auto" />}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLanguage("ar")} className="flex items-center gap-2">
                🇸🇦 العربية {language === "ar" && <Check className="w-4 h-4 ms-auto" />}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User / Auth buttons */}
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className={`gap-2 ${scrolled ? "hover:bg-black/5 dark:hover:bg-white/10" : "hover:bg-white/10"}`}>
                  <Avatar className="w-7 h-7">
                    <AvatarFallback className="bg-[#c9a84c] text-[#0a1628] text-xs font-bold">
                      <User className="w-3.5 h-3.5" />
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => navigate("/dashboard")}>
                  {t.nav.dashboard}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate("/dashboard/settings")}>
                  <Settings className="w-4 h-4 mr-2" />{language === 'ar' ? 'الإعدادات' : 'Settings'}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleSignOut}>
                  <LogOut className="w-4 h-4 mr-2" />{t.nav.logout}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Button
                variant="ghost"
                className={`font-semibold text-[13px] transition-colors ${loginBtnClass}`}
                style={{ fontFamily: "'Playfair Display', 'Noto Kufi Arabic', serif" }}
                onClick={() => navigate("/login")}
              >
                {t.nav.login}
              </Button>
              <Button
                className="rounded-full px-5 h-9 text-[13px] font-bold shadow-lg shadow-[#c9a84c]/20 bg-[#c9a84c] text-[#0a1628] hover:bg-[#d4b85e] transition-all duration-200"
                style={{ fontFamily: "'Playfair Display', 'Noto Kufi Arabic', serif" }}
                onClick={() => navigate("/signup")}
              >
                {t.nav.signup}
              </Button>
            </>
          )}
        </div>

        {/* Mobile menu */}
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon" className={scrolled ? "text-gray-700 dark:text-gray-200" : "text-white/80 hover:bg-white/10"}>
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side={dir === 'rtl' ? 'left' : 'right'} className="w-[300px] bg-background border-border">
            <div className="flex flex-col gap-6 mt-8">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  className="text-base font-semibold text-foreground/80 hover:text-foreground transition-colors text-start bg-transparent border-none cursor-pointer"
                  style={{ fontFamily: "'Playfair Display', 'Noto Kufi Arabic', serif" }}
                  onClick={() => { handleNavClick(link.href); setIsOpen(false) }}
                >
                  {link.label}
                </button>
              ))}
              <div className="flex items-center gap-2 py-4 border-t border-border">
                <Button variant="outline" size="sm" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} className="flex-1">
                  {theme === 'dark' ? <Sun className="w-4 h-4 me-2" /> : <Moon className="w-4 h-4 me-2" />}
                  {theme === 'dark' ? (language === 'ar' ? 'فاتح' : 'Light') : (language === 'ar' ? 'داكن' : 'Dark')}
                </Button>
                <Button variant="outline" size="sm" onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')} className="flex-1">
                  <Globe className="w-4 h-4 me-2" />
                  {language === 'en' ? 'العربية' : 'English'}
                </Button>
              </div>
              <div className="border-t border-border pt-6 flex flex-col gap-3">
                {user ? (
                  <>
                    <Button
                      className="bg-[#c9a84c] text-[#0a1628] rounded-full font-bold hover:bg-[#d4b85e]"
                      style={{ fontFamily: "'Playfair Display', 'Noto Kufi Arabic', serif" }}
                      onClick={() => { navigate("/dashboard"); setIsOpen(false) }}
                    >
                      {t.nav.dashboard}
                    </Button>
                    <Button variant="ghost" className="text-foreground/70 hover:text-foreground" onClick={() => { handleSignOut(); setIsOpen(false) }}>
                      {t.nav.logout}
                    </Button>
                  </>
                ) : (
                  <>
                    <Button
                      variant="ghost"
                      className="justify-start font-semibold text-foreground/80 hover:text-foreground"
                      style={{ fontFamily: "'Playfair Display', 'Noto Kufi Arabic', serif" }}
                      onClick={() => { navigate("/login"); setIsOpen(false) }}
                    >
                      {t.nav.login}
                    </Button>
                    <Button
                      className="bg-[#c9a84c] text-[#0a1628] hover:bg-[#d4b85e] rounded-full font-bold shadow-lg shadow-[#c9a84c]/20"
                      style={{ fontFamily: "'Playfair Display', 'Noto Kufi Arabic', serif" }}
                      onClick={() => { navigate("/signup"); setIsOpen(false) }}
                    >
                      {t.nav.signup}
                    </Button>
                  </>
                )}
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  )
}
