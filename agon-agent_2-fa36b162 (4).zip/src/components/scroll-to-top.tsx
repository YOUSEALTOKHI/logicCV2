import { useState, useEffect, useCallback } from "react"
import { ChevronUp, ChevronDown } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

export function ScrollToTop() {
  const [showUp, setShowUp] = useState(false)
  const [showDown, setShowDown] = useState(true)
  const [chatOpen, setChatOpen] = useState(false)
  const [position, setPosition] = useState<'right' | 'left'>('right')

  const checkScroll = useCallback(() => {
    const scrollY = window.scrollY
    const maxScroll = document.documentElement.scrollHeight - window.innerHeight
    setShowUp(scrollY > 300)
    setShowDown(scrollY < maxScroll - 100)
  }, [])

  useEffect(() => {
    window.addEventListener('scroll', checkScroll, { passive: true })
    checkScroll()
    return () => window.removeEventListener('scroll', checkScroll)
  }, [checkScroll])

  // Observe chatbot state
  useEffect(() => {
    const observer = new MutationObserver(() => {
      const chatEl = document.querySelector('[data-chatbot-open="true"]')
      setChatOpen(!!chatEl)
    })
    observer.observe(document.body, { attributes: true, subtree: true, attributeFilter: ['data-chatbot-open'] })
    return () => observer.disconnect()
  }, [])

  // Check if chatbot is open and adjust position
  useEffect(() => {
    setPosition(chatOpen ? 'left' : 'right')
  }, [chatOpen])

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' })
  const scrollToBottom = () => window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' })

  const posClass = position === 'right' ? 'right-6' : 'left-6'

  return (
    <AnimatePresence>
      {(showUp || showDown) && (
        <motion.div
          key={position}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          className={`fixed bottom-24 ${posClass} z-40 flex flex-col gap-2`}
        >
          {showUp && (
            <motion.button
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 10, opacity: 0 }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={scrollToTop}
              className="w-11 h-11 rounded-full bg-[#0f2044] text-white shadow-lg shadow-[#0f2044]/30 flex items-center justify-center hover:bg-[#162d5a] transition-colors"
              aria-label="Scroll to top"
            >
              <ChevronUp className="w-5 h-5" />
            </motion.button>
          )}
          {showDown && (
            <motion.button
              initial={{ y: -10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -10, opacity: 0 }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={scrollToBottom}
              className="w-11 h-11 rounded-full bg-[#c9a84c] text-white shadow-lg shadow-[#c9a84c]/30 flex items-center justify-center hover:bg-[#b8993f] transition-colors"
              aria-label="Scroll to bottom"
            >
              <ChevronDown className="w-5 h-5" />
            </motion.button>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  )
}
