import { useNavigate } from "react-router-dom"
import { ArrowLeft } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

interface BackButtonProps {
  variant?: "default" | "light"
  className?: string
}

export function BackButton({ variant = "default", className = "" }: BackButtonProps) {
  const navigate = useNavigate()
  const { language } = useLanguage()
  const isAr = language === 'ar'

  return (
    <button
      onClick={() => navigate(-1)}
      className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 group ${
        variant === "light"
          ? "text-white/80 hover:text-white hover:bg-white/10 backdrop-blur-sm"
          : "text-muted-foreground hover:text-foreground hover:bg-muted"
      } ${className}`}
    >
      <ArrowLeft className={`w-4 h-4 transition-transform group-hover:${isAr ? 'translate-x-1' : '-translate-x-1'} ${isAr ? 'rotate-180' : ''}`} />
      {isAr ? "رجوع" : "Back"}
    </button>
  )
}
