import { createContext, useContext, useEffect, useState, ReactNode } from "react"
import { User, Session } from "@supabase/supabase-js"
import { supabase } from "@/integrations/supabase/client"
import { useNavigate } from "react-router-dom"

type AppRole = "admin" | "user" | "employee" | "support"
type SubscriptionPlan = "free" | "basic" | "pro" | "premium"

interface AuthContextType {
  user: User | null
  session: Session | null
  loading: boolean
  roles: AppRole[]
  plan: SubscriptionPlan
  isPremium: boolean
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: any }>
  signIn: (email: string, password: string) => Promise<{ error: any }>
  signOut: () => Promise<void>
  hasRole: (role: AppRole) => boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [loading, setLoading] = useState(true)
  const [roles, setRoles] = useState<AppRole[]>([])
  const [plan, setPlan] = useState<SubscriptionPlan>("free")

  const fetchUserData = async (userId: string) => {
    const [rolesRes, subRes] = await Promise.all([
      supabase.from("user_roles").select("role").eq("user_id", userId),
      supabase.from("subscriptions").select("plan, status").eq("user_id", userId).eq("status", "active").maybeSingle(),
    ])
    if (rolesRes.data) setRoles(rolesRes.data.map(r => r.role as AppRole))
    if (subRes.data) setPlan(subRes.data.plan as SubscriptionPlan)
  }

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      setSession(session)
      setUser(session?.user ?? null)
      if (session?.user) {
        setTimeout(() => fetchUserData(session.user.id), 0)
      } else {
        setRoles([])
        setPlan("free")
      }
      setLoading(false)
    })

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setUser(session?.user ?? null)
      if (session?.user) fetchUserData(session.user.id)
      setLoading(false)
    })

    return () => subscription.unsubscribe()
  }, [])

  const signUp = async (email: string, password: string, fullName: string) => {
    const { error } = await supabase.auth.signUp({
      email, password,
      options: { data: { full_name: fullName }, emailRedirectTo: window.location.origin }
    })
    return { error }
  }

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    return { error }
  }

  const signOut = async () => {
    await supabase.auth.signOut()
    setUser(null)
    setSession(null)
    setRoles([])
    setPlan("free")
  }

  const hasRole = (role: AppRole) => roles.includes(role)
  const isPremium = plan !== "free"

  return (
    <AuthContext.Provider value={{ user, session, loading, roles, plan, isPremium, signUp, signIn, signOut, hasRole }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) throw new Error("useAuth must be used within AuthProvider")
  return context
}
