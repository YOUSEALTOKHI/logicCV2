// Security utilities for protecting against malicious content

const MALICIOUS_PATTERNS = [
  /javascript:/gi,
  /data:text\/html/gi,
  /vbscript:/gi,
  /<script[\s>]/gi,
  /on\w+\s*=/gi,
  /eval\s*\(/gi,
  /document\.cookie/gi,
  /document\.write/gi,
  /window\.location/gi,
  /\.innerHTML/gi,
  /base64/gi,
  /fromCharCode/gi,
  /&#x/gi,
  /\\u00/gi,
]

const MALICIOUS_URL_PATTERNS = [
  /^javascript:/i,
  /^data:/i,
  /^vbscript:/i,
  /\.exe$/i,
  /\.bat$/i,
  /\.cmd$/i,
  /\.scr$/i,
  /\.pif$/i,
  /\.com$/i,
  /\.vbs$/i,
  /\.ws$/i,
  /\.wsf$/i,
  /\.ps1$/i,
]

const MALICIOUS_FILE_EXTENSIONS = [
  '.exe', '.bat', '.cmd', '.scr', '.pif', '.com', '.vbs', '.ws',
  '.wsf', '.ps1', '.msi', '.dll', '.sys', '.reg', '.inf',
  '.hta', '.cpl', '.msc', '.jar', '.jnlp', '.svg',
]

export function isMaliciousText(text: string): boolean {
  return MALICIOUS_PATTERNS.some(pattern => pattern.test(text))
}

export function isMaliciousUrl(url: string): boolean {
  return MALICIOUS_URL_PATTERNS.some(pattern => pattern.test(url))
}

export function isMaliciousFile(filename: string): boolean {
  const ext = filename.toLowerCase().slice(filename.lastIndexOf('.'))
  return MALICIOUS_FILE_EXTENSIONS.includes(ext)
}

export function sanitizeText(text: string): string {
  return text
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;')
}

export function sanitizeUrl(url: string): string | null {
  try {
    const parsed = new URL(url)
    if (!['http:', 'https:', 'mailto:'].includes(parsed.protocol)) {
      return null
    }
    return parsed.href
  } catch {
    return null
  }
}

export interface SecurityCheckResult {
  safe: boolean
  type?: 'text' | 'url' | 'file'
  message?: string
}

export function checkSecurity(content: string, type: 'text' | 'url' | 'file' = 'text'): SecurityCheckResult {
  if (type === 'text' && isMaliciousText(content)) {
    return { safe: false, type: 'text', message: '⚠️ Hacker — Do not open this content. Malicious code detected.' }
  }
  if (type === 'url' && isMaliciousUrl(content)) {
    return { safe: false, type: 'url', message: '⚠️ Hacker — Do not open this link. Malicious URL detected.' }
  }
  if (type === 'file' && isMaliciousFile(content)) {
    return { safe: false, type: 'file', message: '⚠️ Hacker — Do not open this file. Potentially dangerous file type.' }
  }
  return { safe: true }
}
