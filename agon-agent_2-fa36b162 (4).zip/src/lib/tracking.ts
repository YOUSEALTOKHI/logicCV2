// Feature 15: Heatmap-Based Layout Tracking
const SESSION_ID = Math.random().toString(36).slice(2) + Date.now().toString(36)

export function trackEvent(eventType: string, eventData?: Record<string, any>) {
  try {
    fetch('/api/tracking', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event_type: eventType,
        event_data: eventData || {},
        session_id: SESSION_ID,
      }),
    }).catch(() => {})
  } catch {}
}

// Track scroll depth
let maxScrollDepth = 0
if (typeof window !== 'undefined') {
  window.addEventListener('scroll', () => {
    const scrollPct = Math.round((window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100)
    if (scrollPct > maxScrollDepth + 10) {
      maxScrollDepth = scrollPct
      trackEvent('scroll_depth', { depth: scrollPct })
    }
  }, { passive: true })

  // Track clicks on CTAs
  document.addEventListener('click', (e) => {
    const target = e.target as HTMLElement
    const button = target.closest('button, a')
    if (button) {
      const text = button.textContent?.trim().slice(0, 50)
      const rect = button.getBoundingClientRect()
      trackEvent('cta_click', {
        text,
        x: Math.round(rect.x),
        y: Math.round(rect.y + window.scrollY),
        tag: button.tagName,
      })
    }
  })
}

export function getSessionId() { return SESSION_ID }
