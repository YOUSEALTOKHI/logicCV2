import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { handleGoogleRedirect } from "./lib/googleAuth";

// Handle Google OAuth redirect callback
handleGoogleRedirect();

const rootElement = document.getElementById("root");

if (rootElement) {
  createRoot(rootElement).render(<App />);
}
