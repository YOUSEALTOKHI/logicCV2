import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { useLanguage } from "@/lib/i18n/language-context"
import { ScrollToTop } from "@/components/scroll-to-top"
import { Shield, Target, Users, Award, Zap, Globe, Heart, CheckCircle2 } from "lucide-react"

const team = [
  { name: "Sarah Mitchell", nameAr: "سارة ميتشل", role: "CEO & Founder", roleAr: "المؤسسة والرئيسة التنفيذية", initials: "SM", color: "bg-[#0f2044]" },
  { name: "Ahmed Hassan", nameAr: "أحمد حسن", role: "CTO", roleAr: "المدير التقني", initials: "AH", color: "bg-[#c9a84c]" },
  { name: "Emily Chen", nameAr: "إيملي تشين", role: "Head of AI", roleAr: "رئيسة قسم الذكاء الاصطناعي", initials: "EC", color: "bg-sky-600" },
  { name: "Omar Khalil", nameAr: "عمر خليل", role: "Lead CV Writer", roleAr: "كبير كتّاب السير الذاتية", initials: "OK", color: "bg-emerald-600" },
  { name: "Lisa Park", nameAr: "ليزا بارك", role: "UX Designer", roleAr: "مصممة تجربة المستخدم", initials: "LP", color: "bg-purple-600" },
  { name: "David Brown", nameAr: "ديفيد براون", role: "Customer Success", roleAr: "مدير نجاح العملاء", initials: "DB", color: "bg-rose-600" },
]

const values = [
  { icon: Target, titleEn: "Precision", titleAr: "الدقة", descEn: "Every CV we optimize is meticulously analyzed against 30+ ATS parameters.", descAr: "كل سيرة ذاتية نحسّنها يتم تحليلها بدقة مقابل أكثر من 30 معيار ATS." },
  { icon: Heart, titleEn: "Care", titleAr: "الاهتمام", descEn: "We treat every career journey with the attention it deserves.", descAr: "نتعامل مع كل مسيرة مهنية بالاهتمام الذي تستحقه." },
  { icon: Zap, titleEn: "Innovation", titleAr: "الابتكار", descEn: "Continuously improving our AI to stay ahead of ATS systems.", descAr: "نحسّن ذكاءنا الاصطناعي باستمرار للبقاء في المقدمة." },
  { icon: Globe, titleEn: "Accessibility", titleAr: "الوصول", descEn: "Available in multiple languages, serving professionals worldwide.", descAr: "متاح بعدة لغات، نخدم المهنيين حول العالم." },
]

export default function AboutPage() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1">
        {/* Hero */}
        <section className="relative py-20 lg:py-28 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-[#0a1628] via-[#0f2044] to-[#1a3a6a]" />
          <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '32px 32px' }} />
          <div className="container mx-auto px-4 relative z-10 text-center">
            <h1 className="text-4xl lg:text-6xl font-black text-white mb-6">
              {isAr ? 'من نحن' : 'About LogicCV'}
            </h1>
            <p className="text-xl text-blue-100/70 max-w-3xl mx-auto leading-relaxed">
              {isAr
                ? 'نحن فريق من خبراء التوظيف والتكنولوجيا، نجمع بين الذكاء الاصطناعي المتقدم والخبرة البشرية لمساعدة المهنيين في الحصول على وظائف أحلامهم.'
                : 'We are a team of recruitment experts and technologists, combining advanced AI with human expertise to help professionals land their dream jobs.'}
            </p>
          </div>
        </section>

        {/* Mission */}
        <section className="py-16 lg:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-6">
                  {isAr ? 'مهمتنا' : 'Our Mission'}
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                  {isAr
                    ? 'مهمتنا هي إزالة الحواجز بين المهنيين الموهوبين وفرص العمل المثالية. نؤمن بأن كل شخص يستحق أن تُقدَّم مهاراته بأفضل صورة ممكنة.'
                    : 'Our mission is to remove barriers between talented professionals and their ideal job opportunities. We believe everyone deserves to have their skills presented in the best possible way.'}
                </p>
                <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                  {isAr
                    ? 'منذ تأسيسنا، ساعدنا أكثر من 1,200 مهني في تحسين سيرهم الذاتية وزيادة فرصهم في الحصول على مقابلات عمل بنسبة 3 أضعاف.'
                    : 'Since our founding, we have helped over 1,200 professionals optimize their resumes and triple their chances of landing job interviews.'}
                </p>
                <div className="grid grid-cols-2 gap-6">
                  {[
                    { num: "1,233+", labelEn: "Resumes Optimized", labelAr: "سيرة ذاتية محسّنة" },
                    { num: "95%", labelEn: "Success Rate", labelAr: "معدل النجاح" },
                    { num: "50+", labelEn: "Countries Served", labelAr: "دولة نخدمها" },
                    { num: "4.9/5", labelEn: "Customer Rating", labelAr: "تقييم العملاء" },
                  ].map((s, i) => (
                    <div key={i} className="text-center p-4 rounded-xl bg-muted/50">
                      <div className="text-2xl font-black text-primary">{s.num}</div>
                      <div className="text-sm text-muted-foreground">{isAr ? s.labelAr : s.labelEn}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="rounded-2xl overflow-hidden shadow-2xl">
                <img src="/images/about-mission.jpg" alt="Our Mission" className="w-full h-[400px] object-cover" />
              </div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="py-16 lg:py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground text-center mb-12">
              {isAr ? 'قيمنا' : 'Our Values'}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((v, i) => (
                <div key={i} className="bg-card rounded-xl p-6 shadow-sm hover:shadow-lg transition-shadow border border-border/50">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                    <v.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-bold text-foreground mb-2">{isAr ? v.titleAr : v.titleEn}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{isAr ? v.descAr : v.descEn}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Team */}
        <section className="py-16 lg:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
                {isAr ? 'فريقنا' : 'Meet Our Team'}
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                {isAr ? 'خبراء متخصصون في التوظيف والتكنولوجيا' : 'Experts in recruitment and technology'}
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
              {team.map((m, i) => (
                <div key={i} className="bg-card rounded-xl p-6 text-center shadow-sm hover:shadow-lg transition-all hover:-translate-y-1 border border-border/50">
                  <div className={`w-16 h-16 rounded-full ${m.color} text-white flex items-center justify-center mx-auto mb-4 text-xl font-bold`}>
                    {m.initials}
                  </div>
                  <h3 className="font-bold text-foreground">{isAr ? m.nameAr : m.name}</h3>
                  <p className="text-sm text-muted-foreground">{isAr ? m.roleAr : m.role}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Team Photo */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="rounded-2xl overflow-hidden shadow-2xl max-w-4xl mx-auto">
              <img src="/images/about-team.jpg" alt="Our Team" className="w-full h-[350px] object-cover" />
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 text-center">
            <div className="bg-gradient-to-br from-[#0a1628] via-[#0f2044] to-[#162d5a] rounded-2xl p-12">
              <h2 className="text-3xl font-bold text-white mb-4">
                {isAr ? 'هل أنت مستعد لتحسين سيرتك الذاتية؟' : 'Ready to Optimize Your Resume?'}
              </h2>
              <p className="text-blue-100/70 mb-8 max-w-xl mx-auto">
                {isAr ? 'انضم لأكثر من 1,200 مهني حسّنوا سيرهم الذاتية مع LogicCV' : 'Join over 1,200 professionals who optimized their resumes with LogicCV'}
              </p>
              <a href="/#pricing" className="inline-flex items-center gap-2 bg-white text-[#0f2044] px-8 py-3 rounded-full font-bold hover:bg-blue-50 transition-colors shadow-lg">
                {isAr ? 'ابدأ الآن' : 'Get Started Now'}
                <CheckCircle2 className="w-5 h-5" />
              </a>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  )
}
