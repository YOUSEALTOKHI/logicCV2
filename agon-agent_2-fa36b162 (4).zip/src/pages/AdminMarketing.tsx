import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { supabase } from "@/integrations/supabase/client"
import { Megaphone, Plus, Trash2, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Pixel {
  id: string; name: string; pixel_type: string; pixel_id: string
  is_active: boolean; placement: string; custom_code: string | null
}

const pixelTypes = ["facebook", "google_analytics", "google_ads", "tiktok", "snapchat", "twitter", "linkedin", "custom"]

export default function AdminMarketing() {
  const [pixels, setPixels] = useState<Pixel[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [form, setForm] = useState({ name: "", pixel_type: "facebook", pixel_id: "", placement: "all", custom_code: "" })
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    const { data } = await supabase.from("marketing_pixels").select("*").order("created_at", { ascending: false })
    if (data) setPixels(data as Pixel[])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  const addPixel = async () => {
    const { error } = await supabase.from("marketing_pixels").insert(form)
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" })
    else { toast({ title: "Pixel added" }); setDialogOpen(false); setForm({ name: "", pixel_type: "facebook", pixel_id: "", placement: "all", custom_code: "" }); load() }
  }

  const toggleActive = async (id: string, is_active: boolean) => {
    await supabase.from("marketing_pixels").update({ is_active }).eq("id", id)
    load()
  }

  const deletePixel = async (id: string) => {
    await supabase.from("marketing_pixels").delete().eq("id", id)
    toast({ title: "Deleted" }); load()
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Megaphone className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold">Marketing & Tracking</h1>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="w-4 h-4 mr-2" />Add Pixel</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Add Tracking Pixel</DialogTitle></DialogHeader>
              <div className="space-y-4">
                <div><Label>Name</Label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Facebook Main Pixel" /></div>
                <div><Label>Type</Label>
                  <Select value={form.pixel_type} onValueChange={v => setForm(f => ({ ...f, pixel_type: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{pixelTypes.map(t => <SelectItem key={t} value={t}>{t.replace("_", " ")}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Pixel ID / Tracking ID</Label><Input value={form.pixel_id} onChange={e => setForm(f => ({ ...f, pixel_id: e.target.value }))} placeholder="e.g. 123456789" /></div>
                <div><Label>Placement</Label>
                  <Select value={form.placement} onValueChange={v => setForm(f => ({ ...f, placement: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Pages</SelectItem>
                      <SelectItem value="head">Head Only</SelectItem>
                      <SelectItem value="body">Body Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {form.pixel_type === "custom" && (
                  <div><Label>Custom Code</Label><Textarea value={form.custom_code} onChange={e => setForm(f => ({ ...f, custom_code: e.target.value }))} placeholder="<script>...</script>" rows={4} /></div>
                )}
                <Button className="w-full" onClick={addPixel}>Save Pixel</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : (
          <Card>
            <CardHeader><CardTitle>Tracking Pixels ({pixels.length})</CardTitle></CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>ID</TableHead>
                    <TableHead>Placement</TableHead>
                    <TableHead>Active</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pixels.map(p => (
                    <TableRow key={p.id}>
                      <TableCell className="font-medium">{p.name}</TableCell>
                      <TableCell className="capitalize">{p.pixel_type.replace("_", " ")}</TableCell>
                      <TableCell className="font-mono text-xs">{p.pixel_id}</TableCell>
                      <TableCell className="capitalize">{p.placement}</TableCell>
                      <TableCell><Switch checked={p.is_active} onCheckedChange={v => toggleActive(p.id, v)} /></TableCell>
                      <TableCell><Button size="sm" variant="ghost" onClick={() => deletePixel(p.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button></TableCell>
                    </TableRow>
                  ))}
                  {pixels.length === 0 && (
                    <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No pixels configured</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  )
}
