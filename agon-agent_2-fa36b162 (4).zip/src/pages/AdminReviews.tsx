import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { supabase } from "@/integrations/supabase/client"
import { Star, Loader2, Check, X } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Review {
  id: string; user_id: string; rating: number; comment: string; is_approved: boolean; created_at: string
}

export default function AdminReviews() {
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    const { data } = await supabase.from("reviews").select("*").order("created_at", { ascending: false })
    if (data) setReviews(data)
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  const toggleApproval = async (id: string, is_approved: boolean) => {
    const { error } = await supabase.from("reviews").update({ is_approved }).eq("id", id)
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" })
    else { toast({ title: is_approved ? "Approved" : "Rejected" }); load() }
  }

  const deleteReview = async (id: string) => {
    await supabase.from("reviews").delete().eq("id", id)
    toast({ title: "Deleted" }); load()
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <Star className="w-8 h-8 text-primary" />
          <h1 className="text-3xl font-bold">Reviews Management</h1>
        </div>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : (
          <Card>
            <CardHeader><CardTitle>All Reviews ({reviews.length})</CardTitle></CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rating</TableHead>
                    <TableHead>Comment</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reviews.map(r => (
                    <TableRow key={r.id}>
                      <TableCell>
                        <div className="flex gap-0.5">{Array.from({ length: r.rating }).map((_, i) => <Star key={i} className="w-4 h-4 fill-accent text-accent" />)}</div>
                      </TableCell>
                      <TableCell className="max-w-xs truncate">{r.comment}</TableCell>
                      <TableCell>
                        <Badge className={r.is_approved ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400"}>
                          {r.is_approved ? "Approved" : "Pending"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs">{new Date(r.created_at).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button size="sm" variant="ghost" onClick={() => toggleApproval(r.id, !r.is_approved)}>
                            {r.is_approved ? <X className="w-4 h-4" /> : <Check className="w-4 h-4" />}
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => deleteReview(r.id)}>
                            <X className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                  {reviews.length === 0 && (
                    <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No reviews yet</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  )
}
