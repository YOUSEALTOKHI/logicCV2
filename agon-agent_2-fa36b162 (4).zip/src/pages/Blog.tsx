import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { useLanguage } from "@/lib/i18n/language-context"
import { ScrollToTop } from "@/components/scroll-to-top"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, ArrowRight, Loader2, BookOpen, User } from "lucide-react"

interface BlogPost {
  id: number
  slug: string
  title: string
  excerpt: string
  content: string
  cover_image: string | null
  image?: string
  category: string
  read_time: number
  created_at: string
  published: boolean
}

export default function BlogPage() {
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const [posts, setPosts] = useState<BlogPost[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/blog')
      .then(r => r.json())
      .then(data => { setPosts(data || []); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const fallbackImage = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" fill="%230f2044"><rect width="800" height="400"/><text x="400" y="200" fill="%23c9a84c" font-size="40" text-anchor="middle" dominant-baseline="middle" font-family="sans-serif">LogicCV</text></svg>')

  return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1">
        <section className="relative py-16 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-[#0a1628] via-[#0f2044] to-[#1a3a6a]" />
          <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '32px 32px' }} />
          <div className="container mx-auto px-4 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 bg-[#c9a84c]/15 text-[#c9a84c] border border-[#c9a84c]/20 px-4 py-2 rounded-full text-sm font-semibold mb-6">
              <BookOpen className="w-4 h-4" />
              {isAr ? 'مقالات ونصائح' : 'Articles & Tips'}
            </div>
            <h1 className="text-4xl lg:text-5xl font-bold text-white mb-4">
              {isAr ? 'المدونة والموارد' : 'Blog & Resources'}
            </h1>
            <p className="text-lg text-blue-100/70 max-w-2xl mx-auto">
              {isAr ? 'نصائح ومقالات احترافية لتحسين سيرتك الذاتية ومسيرتك المهنية' : 'Professional tips and articles to improve your resume and career'}
            </p>
          </div>
        </section>

        <section className="py-16 bg-background">
          <div className="container mx-auto px-4">
            {loading ? (
              <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
            ) : posts.length === 0 ? (
              <div className="text-center py-20">
                <BookOpen className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground text-lg">{isAr ? 'لا توجد مقالات بعد' : 'No articles yet'}</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {posts.map(post => (
                  <Link key={post.id} to={`/blog/${post.slug}`}>
                    <Card className="group overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-border/50 h-full bg-card">
                      <div className="aspect-video overflow-hidden bg-muted">
                        <img
                          src={post.cover_image || post.image || fallbackImage}
                          alt={post.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          onError={(e) => { (e.target as HTMLImageElement).src = fallbackImage }}
                        />
                      </div>
                      <CardContent className="p-6">
                        <Badge className="mb-3 bg-primary/10 text-primary border-0 dark:bg-primary/20">{post.category}</Badge>
                        <h3 className="text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-2">
                          {post.title}
                        </h3>
                        <p className="text-sm text-muted-foreground leading-relaxed mb-4 line-clamp-3">
                          {post.excerpt}
                        </p>
                        {(post as any).author && (
                          <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                            <User className="w-3.5 h-3.5" />{(post as any).author}
                          </p>
                        )}
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <div className="flex items-center gap-3">
                            <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{new Date(post.created_at).toLocaleDateString(isAr ? 'ar-SA' : 'en-US', { year: 'numeric', month: 'short', day: 'numeric' })}</span>
                            <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{post.read_time} {isAr ? 'دقائق' : 'min'}</span>
                          </div>
                          <ArrowRight className={`w-4 h-4 text-primary group-hover:translate-x-1 transition-transform ${isAr ? 'rotate-180' : ''}`} />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  )
}
