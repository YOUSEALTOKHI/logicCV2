import { useEffect, useState } from "react"
import { useParams, Link } from "react-router-dom"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { useLanguage } from "@/lib/i18n/language-context"
import { ScrollToTop } from "@/components/scroll-to-top"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, ArrowLeft, Loader2, User } from "lucide-react"

export default function BlogPostPage() {
  const { slug } = useParams<{ slug: string }>()
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const [post, setPost] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch(`/api/blog?slug=${slug}`)
      .then(r => r.json())
      .then(data => { setPost(data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [slug])

  const fallbackImage = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" fill="%230f2044"><rect width="800" height="400"/><text x="400" y="200" fill="%23c9a84c" font-size="40" text-anchor="middle" dominant-baseline="middle" font-family="sans-serif">LogicCV</text></svg>')

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <Loader2 className="w-8 h-8 animate-spin text-primary" />
    </div>
  )

  if (!post) return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">{isAr ? 'المقال غير موجود' : 'Post Not Found'}</h1>
          <Link to="/blog"><Button>{isAr ? 'العودة للمدونة' : 'Back to Blog'}</Button></Link>
        </div>
      </main>
      <Footer />
    </div>
  )

  const heroImage = post.cover_image || post.image || fallbackImage

  // Render markdown-like content with ## headings and bullet points
  const renderContent = (text: string) => {
    if (!text) return null
    const lines = text.split('\n')
    const elements: JSX.Element[] = []
    
    lines.forEach((line, i) => {
      const trimmed = line.trim()
      if (trimmed.startsWith('### ')) {
        elements.push(<h3 key={i} className="text-lg font-bold text-foreground mt-6 mb-2">{trimmed.slice(4)}</h3>)
      } else if (trimmed.startsWith('## ')) {
        elements.push(<h2 key={i} className="text-xl font-bold text-foreground mt-8 mb-3">{trimmed.slice(3)}</h2>)
      } else if (trimmed.startsWith('• ') || trimmed.startsWith('- ')) {
        const content = trimmed.slice(2)
        // Handle **bold** in bullet points
        const parts = content.split(/\*\*(.*?)\*\*/)
        elements.push(
          <li key={i} className="text-muted-foreground ml-4 mb-1.5 list-disc">
            {parts.map((part, j) => j % 2 === 1 ? <strong key={j} className="text-foreground">{part}</strong> : part)}
          </li>
        )
      } else if (trimmed === '') {
        elements.push(<div key={i} className="h-3" />)
      } else {
        // Handle **bold** in regular text
        const parts = trimmed.split(/\*\*(.*?)\*\*/)
        elements.push(
          <p key={i} className="text-muted-foreground leading-relaxed mb-2">
            {parts.map((part, j) => j % 2 === 1 ? <strong key={j} className="text-foreground">{part}</strong> : part)}
          </p>
        )
      }
    })
    
    return elements
  }

  return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1">
        <div className="relative h-[400px] overflow-hidden">
          <img 
            src={heroImage} 
            alt={post.title} 
            className="w-full h-full object-cover" 
            onError={(e) => { (e.target as HTMLImageElement).src = fallbackImage }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-8">
            <div className="container mx-auto">
              <Badge className="mb-4 bg-white/20 text-white border-0 backdrop-blur-sm">{post.category}</Badge>
              <h1 className="text-3xl lg:text-4xl font-black text-white mb-4 max-w-3xl">{post.title}</h1>
              <div className="flex items-center gap-4 text-white/70 text-sm flex-wrap">
                {post.author && (
                  <span className="flex items-center gap-1"><User className="w-4 h-4" />{post.author}</span>
                )}
                <span className="flex items-center gap-1"><Calendar className="w-4 h-4" />{new Date(post.created_at).toLocaleDateString(isAr ? 'ar-SA' : 'en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" />{post.read_time} {isAr ? 'دقائق قراءة' : 'min read'}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-3xl mx-auto">
            <Link to="/blog" className="inline-flex items-center gap-2 text-primary hover:underline mb-8">
              <ArrowLeft className={`w-4 h-4 ${isAr ? 'rotate-180' : ''}`} />
              {isAr ? 'العودة للمدونة' : 'Back to Blog'}
            </Link>
            <article className="max-w-none">
              {renderContent(post.content)}
            </article>
            
            {post.tags && (
              <div className="mt-12 pt-8 border-t border-border">
                <div className="flex flex-wrap gap-2">
                  {post.tags.split(',').map((tag: string, i: number) => (
                    <Badge key={i} variant="outline" className="text-xs">{tag.trim()}</Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  )
}
