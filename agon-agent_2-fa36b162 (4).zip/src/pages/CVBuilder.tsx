import { useState, useRef } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useLanguage } from "@/lib/i18n/language-context"
import { useAuth } from "@/lib/auth/auth-context"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/integrations/supabase/client"
import {
  User, Briefcase, GraduationCap, Wrench, FolderKanban, Eye,
  Plus, Trash2, Download, Sparkles, Loader2, Save,
} from "lucide-react"
import jsPDF from "jspdf"
import html2canvas from "html2canvas"

interface Experience {
  id: string; company: string; position: string;
  startDate: string; endDate: string; current: boolean; description: string;
}
interface Education {
  id: string; school: string; degree: string;
  startDate: string; endDate: string; description: string;
}
interface Skill { id: string; name: string; level: number }
interface Project { id: string; name: string; description: string; link: string }

interface CVData {
  personal: {
    fullName: string; title: string; email: string; phone: string;
    location: string; website: string; summary: string;
  }
  experiences: Experience[]
  educations: Education[]
  skills: Skill[]
  projects: Project[]
  template: "modern" | "classic" | "creative"
  primaryColor: string
}

const initialData: CVData = {
  personal: { fullName: "", title: "", email: "", phone: "", location: "", website: "", summary: "" },
  experiences: [],
  educations: [],
  skills: [],
  projects: [],
  template: "modern",
  primaryColor: "#2563eb",
}

const uid = () => Math.random().toString(36).slice(2, 10)

export default function CVBuilderPage() {
  const { t, dir } = useLanguage()
  const { user } = useAuth()
  const { toast } = useToast()
  const [data, setData] = useState<CVData>(initialData)
  const [aiLoading, setAiLoading] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const previewRef = useRef<HTMLDivElement>(null)

  const updatePersonal = (field: keyof CVData["personal"], value: string) =>
    setData((d) => ({ ...d, personal: { ...d.personal, [field]: value } }))

  // Experience
  const addExp = () => setData((d) => ({
    ...d, experiences: [...d.experiences, { id: uid(), company: "", position: "", startDate: "", endDate: "", current: false, description: "" }],
  }))
  const updateExp = (id: string, field: keyof Experience, value: any) =>
    setData((d) => ({ ...d, experiences: d.experiences.map((e) => e.id === id ? { ...e, [field]: value } : e) }))
  const removeExp = (id: string) =>
    setData((d) => ({ ...d, experiences: d.experiences.filter((e) => e.id !== id) }))

  // Education
  const addEdu = () => setData((d) => ({
    ...d, educations: [...d.educations, { id: uid(), school: "", degree: "", startDate: "", endDate: "", description: "" }],
  }))
  const updateEdu = (id: string, field: keyof Education, value: string) =>
    setData((d) => ({ ...d, educations: d.educations.map((e) => e.id === id ? { ...e, [field]: value } : e) }))
  const removeEdu = (id: string) =>
    setData((d) => ({ ...d, educations: d.educations.filter((e) => e.id !== id) }))

  // Skills
  const addSkill = () => setData((d) => ({
    ...d, skills: [...d.skills, { id: uid(), name: "", level: 3 }],
  }))
  const updateSkill = (id: string, field: keyof Skill, value: any) =>
    setData((d) => ({ ...d, skills: d.skills.map((s) => s.id === id ? { ...s, [field]: value } : s) }))
  const removeSkill = (id: string) =>
    setData((d) => ({ ...d, skills: d.skills.filter((s) => s.id !== id) }))

  // Projects
  const addProject = () => setData((d) => ({
    ...d, projects: [...d.projects, { id: uid(), name: "", description: "", link: "" }],
  }))
  const updateProject = (id: string, field: keyof Project, value: string) =>
    setData((d) => ({ ...d, projects: d.projects.map((p) => p.id === id ? { ...p, [field]: value } : p) }))
  const removeProject = (id: string) =>
    setData((d) => ({ ...d, projects: d.projects.filter((p) => p.id !== id) }))

  const handleAIImprove = async (
    text: string,
    field: string,
    apply: (improved: string) => void,
    aiKey: string,
  ) => {
    if (!text.trim()) {
      toast({ title: t.builder.enterText, variant: "destructive" })
      return
    }
    setAiLoading(aiKey)
    try {
      const { data: res, error } = await supabase.functions.invoke("ai-tools", {
        body: { mode: "improve_text", payload: { text, field } },
      })
      if (error) throw error
      if (res?.error) throw new Error(res.error)
      apply(res.result)
      toast({ title: t.builder.aiSuccess })
    } catch (e: any) {
      toast({ title: t.builder.aiError, description: e.message, variant: "destructive" })
    } finally {
      setAiLoading(null)
    }
  }

  const handleSave = async () => {
    if (!user) return
    setSaving(true)
    try {
      const { error } = await supabase.from("cv_creations").insert({
        user_id: user.id,
        cv_data: data as any,
      })
      if (error) throw error
      toast({ title: t.builder.saved })
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" })
    } finally {
      setSaving(false)
    }
  }

  const handleExport = async () => {
    if (!previewRef.current) return
    try {
      const canvas = await html2canvas(previewRef.current, { scale: 2, backgroundColor: "#ffffff" })
      const imgData = canvas.toDataURL("image/png")
      const pdf = new jsPDF({ unit: "mm", format: "a4" })
      const pdfWidth = pdf.internal.pageSize.getWidth()
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width
      pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight)
      pdf.save(`${data.personal.fullName || "resume"}.pdf`)
      toast({ title: t.builder.exportSuccess })
    } catch (e: any) {
      toast({ title: "Export failed", description: e.message, variant: "destructive" })
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6" dir={dir}>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-black tracking-tight">{t.builder.title}</h1>
            <p className="text-muted-foreground mt-1">{t.builder.subtitle}</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Select value={data.template} onValueChange={(v: any) => setData((d) => ({ ...d, template: v }))}>
              <SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="modern">{t.builder.modern}</SelectItem>
                <SelectItem value="classic">{t.builder.classic}</SelectItem>
                <SelectItem value="creative">{t.builder.creative}</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={handleSave} disabled={saving || !user}>
              {saving ? <Loader2 className="w-4 h-4 me-2 animate-spin" /> : <Save className="w-4 h-4 me-2" />}
              {t.builder.save}
            </Button>
            <Button onClick={handleExport}>
              <Download className="w-4 h-4 me-2" /> {t.builder.export}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {/* Editor */}
          <Card className="border-2">
            <CardContent className="p-0">
              <Tabs defaultValue="personal" className="w-full">
                <TabsList className="grid grid-cols-5 w-full rounded-none">
                  <TabsTrigger value="personal" className="text-xs"><User className="w-3.5 h-3.5 me-1" />{t.builder.personal}</TabsTrigger>
                  <TabsTrigger value="experience" className="text-xs"><Briefcase className="w-3.5 h-3.5 me-1" />{t.builder.experience}</TabsTrigger>
                  <TabsTrigger value="education" className="text-xs"><GraduationCap className="w-3.5 h-3.5 me-1" />{t.builder.education}</TabsTrigger>
                  <TabsTrigger value="skills" className="text-xs"><Wrench className="w-3.5 h-3.5 me-1" />{t.builder.skills}</TabsTrigger>
                  <TabsTrigger value="projects" className="text-xs"><FolderKanban className="w-3.5 h-3.5 me-1" />{t.builder.projects}</TabsTrigger>
                </TabsList>

                <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                  <TabsContent value="personal" className="space-y-3 mt-0">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div><Label>{t.builder.fullName}</Label><Input value={data.personal.fullName} onChange={(e) => updatePersonal("fullName", e.target.value)} /></div>
                      <div><Label>{t.builder.profTitle}</Label><Input value={data.personal.title} onChange={(e) => updatePersonal("title", e.target.value)} /></div>
                      <div><Label>{t.builder.email}</Label><Input type="email" value={data.personal.email} onChange={(e) => updatePersonal("email", e.target.value)} /></div>
                      <div><Label>{t.builder.phone}</Label><Input value={data.personal.phone} onChange={(e) => updatePersonal("phone", e.target.value)} /></div>
                      <div><Label>{t.builder.location}</Label><Input value={data.personal.location} onChange={(e) => updatePersonal("location", e.target.value)} /></div>
                      <div><Label>{t.builder.website}</Label><Input value={data.personal.website} onChange={(e) => updatePersonal("website", e.target.value)} /></div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label>{t.builder.summary}</Label>
                        <Button size="sm" variant="ghost" disabled={aiLoading === "summary"}
                          onClick={() => handleAIImprove(data.personal.summary, "summary",
                            (v) => updatePersonal("summary", v), "summary")}>
                          {aiLoading === "summary" ? <Loader2 className="w-3 h-3 me-1 animate-spin" /> : <Sparkles className="w-3 h-3 me-1" />}
                          {t.builder.improve}
                        </Button>
                      </div>
                      <Textarea
                        value={data.personal.summary}
                        onChange={(e) => updatePersonal("summary", e.target.value)}
                        placeholder={t.builder.summaryPlaceholder}
                        className="min-h-[100px] resize-none"
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="experience" className="space-y-4 mt-0">
                    {data.experiences.map((exp) => (
                      <Card key={exp.id} className="border">
                        <CardContent className="p-4 space-y-3">
                          <div className="flex justify-end">
                            <Button size="sm" variant="ghost" onClick={() => removeExp(exp.id)}>
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div><Label>{t.builder.company}</Label><Input value={exp.company} onChange={(e) => updateExp(exp.id, "company", e.target.value)} /></div>
                            <div><Label>{t.builder.position}</Label><Input value={exp.position} onChange={(e) => updateExp(exp.id, "position", e.target.value)} /></div>
                            <div><Label>{t.builder.startDate}</Label><Input value={exp.startDate} onChange={(e) => updateExp(exp.id, "startDate", e.target.value)} placeholder="2022-01" /></div>
                            <div><Label>{t.builder.endDate}</Label><Input value={exp.endDate} onChange={(e) => updateExp(exp.id, "endDate", e.target.value)} placeholder="2024-06" disabled={exp.current} /></div>
                          </div>
                          <div className="flex items-center justify-between">
                            <Label className="text-xs font-normal flex items-center gap-2">
                              <input type="checkbox" checked={exp.current} onChange={(e) => updateExp(exp.id, "current", e.target.checked)} />
                              {t.builder.current}
                            </Label>
                            <Button size="sm" variant="ghost" disabled={aiLoading === `exp-${exp.id}`}
                              onClick={() => handleAIImprove(exp.description, "experience",
                                (v) => updateExp(exp.id, "description", v), `exp-${exp.id}`)}>
                              {aiLoading === `exp-${exp.id}` ? <Loader2 className="w-3 h-3 me-1 animate-spin" /> : <Sparkles className="w-3 h-3 me-1" />}
                              {t.builder.improve}
                            </Button>
                          </div>
                          <Textarea value={exp.description} onChange={(e) => updateExp(exp.id, "description", e.target.value)}
                            className="min-h-[80px] resize-none" placeholder={t.builder.description} />
                        </CardContent>
                      </Card>
                    ))}
                    <Button variant="outline" className="w-full" onClick={addExp}>
                      <Plus className="w-4 h-4 me-2" /> {t.builder.addExp}
                    </Button>
                  </TabsContent>

                  <TabsContent value="education" className="space-y-4 mt-0">
                    {data.educations.map((edu) => (
                      <Card key={edu.id} className="border">
                        <CardContent className="p-4 space-y-3">
                          <div className="flex justify-end">
                            <Button size="sm" variant="ghost" onClick={() => removeEdu(edu.id)}>
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div><Label>{t.builder.school}</Label><Input value={edu.school} onChange={(e) => updateEdu(edu.id, "school", e.target.value)} /></div>
                            <div><Label>{t.builder.degree}</Label><Input value={edu.degree} onChange={(e) => updateEdu(edu.id, "degree", e.target.value)} /></div>
                            <div><Label>{t.builder.startDate}</Label><Input value={edu.startDate} onChange={(e) => updateEdu(edu.id, "startDate", e.target.value)} placeholder="2018" /></div>
                            <div><Label>{t.builder.endDate}</Label><Input value={edu.endDate} onChange={(e) => updateEdu(edu.id, "endDate", e.target.value)} placeholder="2022" /></div>
                          </div>
                          <Textarea value={edu.description} onChange={(e) => updateEdu(edu.id, "description", e.target.value)}
                            className="min-h-[60px] resize-none" placeholder={t.builder.description} />
                        </CardContent>
                      </Card>
                    ))}
                    <Button variant="outline" className="w-full" onClick={addEdu}>
                      <Plus className="w-4 h-4 me-2" /> {t.builder.addEdu}
                    </Button>
                  </TabsContent>

                  <TabsContent value="skills" className="space-y-3 mt-0">
                    {data.skills.map((s) => (
                      <div key={s.id} className="flex items-center gap-2">
                        <Input className="flex-1" placeholder={t.builder.skillName} value={s.name} onChange={(e) => updateSkill(s.id, "name", e.target.value)} />
                        <Select value={String(s.level)} onValueChange={(v) => updateSkill(s.id, "level", parseInt(v))}>
                          <SelectTrigger className="w-[110px]"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {[1, 2, 3, 4, 5].map((n) => (
                              <SelectItem key={n} value={String(n)}>{"★".repeat(n)}{"☆".repeat(5 - n)}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Button size="sm" variant="ghost" onClick={() => removeSkill(s.id)}>
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                    ))}
                    <Button variant="outline" className="w-full" onClick={addSkill}>
                      <Plus className="w-4 h-4 me-2" /> {t.builder.addSkill}
                    </Button>
                  </TabsContent>

                  <TabsContent value="projects" className="space-y-4 mt-0">
                    {data.projects.map((p) => (
                      <Card key={p.id} className="border">
                        <CardContent className="p-4 space-y-3">
                          <div className="flex justify-end">
                            <Button size="sm" variant="ghost" onClick={() => removeProject(p.id)}>
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </div>
                          <div><Label>{t.builder.projectName}</Label><Input value={p.name} onChange={(e) => updateProject(p.id, "name", e.target.value)} /></div>
                          <div><Label>{t.builder.projectLink}</Label><Input value={p.link} onChange={(e) => updateProject(p.id, "link", e.target.value)} /></div>
                          <Textarea value={p.description} onChange={(e) => updateProject(p.id, "description", e.target.value)}
                            className="min-h-[60px] resize-none" placeholder={t.builder.description} />
                        </CardContent>
                      </Card>
                    ))}
                    <Button variant="outline" className="w-full" onClick={addProject}>
                      <Plus className="w-4 h-4 me-2" /> {t.builder.addProject}
                    </Button>
                  </TabsContent>
                </div>
              </Tabs>
            </CardContent>
          </Card>

          {/* Preview */}
          <Card className="border-2 sticky top-20 self-start">
            <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm flex items-center gap-2"><Eye className="w-4 h-4" />{t.builder.preview}</CardTitle>
              <Badge variant="outline">{t.builder[data.template]}</Badge>
            </CardHeader>
            <CardContent>
              <div className="bg-white rounded-lg shadow-inner overflow-hidden max-h-[75vh] overflow-y-auto">
                <CVPreview ref={previewRef} data={data} />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}

// === Preview component ===
import { forwardRef } from "react"

const CVPreview = forwardRef<HTMLDivElement, { data: CVData }>(({ data }, ref) => {
  const { personal, experiences, educations, skills, projects, template, primaryColor } = data
  const accent = primaryColor

  if (template === "creative") {
    return (
      <div ref={ref} dir="ltr" className="bg-white text-gray-900 p-8 font-sans" style={{ minHeight: "297mm", width: "210mm", maxWidth: "100%" }}>
        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-1 text-white p-6 rounded-lg" style={{ background: accent }}>
            <h1 className="text-2xl font-black">{personal.fullName || "Your Name"}</h1>
            <p className="text-sm opacity-90 mt-1">{personal.title}</p>
            <div className="mt-6 text-xs space-y-1">
              {personal.email && <p>{personal.email}</p>}
              {personal.phone && <p>{personal.phone}</p>}
              {personal.location && <p>{personal.location}</p>}
              {personal.website && <p className="break-all">{personal.website}</p>}
            </div>
            {skills.length > 0 && (
              <div className="mt-6">
                <h3 className="text-sm font-bold uppercase mb-2 border-b border-white/30 pb-1">Skills</h3>
                {skills.map((s) => (
                  <div key={s.id} className="text-xs mb-1">
                    <p>{s.name}</p>
                    <div className="h-1 bg-white/20 rounded mt-0.5"><div className="h-full bg-white rounded" style={{ width: `${s.level * 20}%` }} /></div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="col-span-2 space-y-5">
            {personal.summary && <Section title="Summary" color={accent}><p className="text-sm">{personal.summary}</p></Section>}
            {experiences.length > 0 && <Section title="Experience" color={accent}>
              {experiences.map((e) => <ExpItem key={e.id} e={e} color={accent} />)}
            </Section>}
            {educations.length > 0 && <Section title="Education" color={accent}>
              {educations.map((e) => <EduItem key={e.id} e={e} color={accent} />)}
            </Section>}
            {projects.length > 0 && <Section title="Projects" color={accent}>
              {projects.map((p) => (
                <div key={p.id} className="mb-2">
                  <p className="text-sm font-bold">{p.name} {p.link && <span className="text-xs text-gray-500">— {p.link}</span>}</p>
                  <p className="text-xs text-gray-700">{p.description}</p>
                </div>
              ))}
            </Section>}
          </div>
        </div>
      </div>
    )
  }

  // modern + classic share base structure
  const isClassic = template === "classic"
  return (
    <div ref={ref} dir="ltr" className={`bg-white text-gray-900 p-8 ${isClassic ? "font-serif" : "font-sans"}`}
      style={{ minHeight: "297mm", width: "210mm", maxWidth: "100%" }}>
      <header className={isClassic ? "text-center border-b-2 border-gray-900 pb-4 mb-5" : "border-b-4 pb-4 mb-5"}
        style={isClassic ? {} : { borderColor: accent }}>
        <h1 className="text-3xl font-black tracking-tight">{personal.fullName || "Your Name"}</h1>
        {personal.title && <p className="text-sm mt-1" style={{ color: accent }}>{personal.title}</p>}
        <p className="text-xs text-gray-600 mt-2">
          {[personal.email, personal.phone, personal.location, personal.website].filter(Boolean).join(" • ")}
        </p>
      </header>

      {personal.summary && <Section title="Summary" color={accent}><p className="text-sm leading-relaxed">{personal.summary}</p></Section>}
      {experiences.length > 0 && <Section title="Experience" color={accent}>
        {experiences.map((e) => <ExpItem key={e.id} e={e} color={accent} />)}
      </Section>}
      {educations.length > 0 && <Section title="Education" color={accent}>
        {educations.map((e) => <EduItem key={e.id} e={e} color={accent} />)}
      </Section>}
      {skills.length > 0 && <Section title="Skills" color={accent}>
        <div className="flex flex-wrap gap-2">
          {skills.map((s) => (
            <span key={s.id} className="text-xs px-2 py-1 rounded border" style={{ borderColor: accent, color: accent }}>
              {s.name} {"★".repeat(s.level)}
            </span>
          ))}
        </div>
      </Section>}
      {projects.length > 0 && <Section title="Projects" color={accent}>
        {projects.map((p) => (
          <div key={p.id} className="mb-2">
            <p className="text-sm font-bold">{p.name} {p.link && <span className="text-xs text-gray-500">— {p.link}</span>}</p>
            <p className="text-xs text-gray-700">{p.description}</p>
          </div>
        ))}
      </Section>}
    </div>
  )
})
CVPreview.displayName = "CVPreview"

function Section({ title, color, children }: { title: string; color: string; children: React.ReactNode }) {
  return (
    <section className="mb-4">
      <h2 className="text-xs font-black uppercase tracking-widest mb-2" style={{ color }}>{title}</h2>
      {children}
    </section>
  )
}

function ExpItem({ e, color }: { e: Experience; color: string }) {
  return (
    <div className="mb-3">
      <div className="flex justify-between items-baseline">
        <p className="text-sm font-bold">{e.position}</p>
        <p className="text-xs text-gray-500">{e.startDate} - {e.current ? "Present" : e.endDate}</p>
      </div>
      <p className="text-xs" style={{ color }}>{e.company}</p>
      {e.description && <p className="text-xs text-gray-700 mt-1 whitespace-pre-line">{e.description}</p>}
    </div>
  )
}

function EduItem({ e, color }: { e: Education; color: string }) {
  return (
    <div className="mb-3">
      <div className="flex justify-between items-baseline">
        <p className="text-sm font-bold">{e.degree}</p>
        <p className="text-xs text-gray-500">{e.startDate} - {e.endDate}</p>
      </div>
      <p className="text-xs" style={{ color }}>{e.school}</p>
      {e.description && <p className="text-xs text-gray-700 mt-1">{e.description}</p>}
    </div>
  )
}
