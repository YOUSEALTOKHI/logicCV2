import { useState } from "react"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useLanguage } from "@/lib/i18n/language-context"
import { useToast } from "@/hooks/use-toast"
import { Briefcase, Users, Clock, MapPin, CheckCircle2, Loader2, ArrowLeft, Send } from "lucide-react"
import { useNavigate } from "react-router-dom"
import { BackButton } from "@/components/ui/back-button"

const positions = [
  {
    id: "customer-service",
    titleEn: "Customer Service Representative",
    titleAr: "ممثل خدمة العملاء",
    typeEn: "Full-time / Remote",
    typeAr: "دوام كامل / عن بعد",
    descEn: "Join our customer success team and help professionals optimize their careers. You'll be the first point of contact for our users, providing exceptional support via chat, email, and tickets.",
    descAr: "انضم لفريق نجاح العملاء وساعد المهنيين في تحسين مسيرتهم المهنية. ستكون نقطة الاتصال الأولى لمستخدمينا، وتقدم دعمًا استثنائيًا عبر الشات والبريد والتذاكر.",
    requirementsEn: ["Excellent English & Arabic (written and spoken)", "Experience in customer service (1+ years)", "Strong communication and problem-solving skills", "Ability to handle multiple conversations simultaneously", "Familiarity with CRM tools and ticketing systems", "Patient, empathetic, and professional demeanor"],
    requirementsAr: ["إجادة ممتازة للإنجليزية والعربية (كتابة ومحادثة)", "خبرة في خدمة العملاء (سنة فأكثر)", "مهارات تواصل وحل مشكلات قوية", "القدرة على إدارة محادثات متعددة في وقت واحد", "معرفة بأدوات CRM وأنظمة التذاكر", "شخصية صبورة ومتعاطفة ومهنية"],
  },
  {
    id: "cv-writer",
    titleEn: "Professional CV Writer",
    titleAr: "كاتب سيرة ذاتية محترف",
    typeEn: "Full-time / Remote",
    typeAr: "دوام كامل / عن بعد",
    descEn: "We're looking for an experienced CV writer who can craft compelling, ATS-optimized resumes for professionals across various industries. You'll work directly with clients to understand their career goals and create tailored documents.",
    descAr: "نبحث عن كاتب سيرة ذاتية متمرس يمكنه صياغة سير ذاتية مقنعة ومتوافقة مع ATS للمهنيين في مختلف القطاعات. ستعمل مباشرة مع العملاء لفهم أهدافهم المهنية وإنشاء وثائق مخصصة.",
    requirementsEn: ["3-4+ years of professional CV/resume writing experience", "Deep understanding of ATS systems and optimization", "Excellent English writing skills (Arabic is a plus)", "Portfolio of previous CV writing work", "Knowledge of multiple industries and job markets", "Ability to meet tight deadlines (24-48 hour turnaround)", "Certification in resume writing (CPRW, NCRW) is preferred"],
    requirementsAr: ["3-4+ سنوات خبرة في كتابة السير الذاتية الاحترافية", "فهم عميق لأنظمة ATS وتحسينها", "مهارات كتابة إنجليزية ممتازة (العربية ميزة إضافية)", "معرض أعمال سابقة في كتابة السير الذاتية", "معرفة بمختلف القطاعات وأسواق العمل", "القدرة على الالتزام بمواعيد ضيقة (24-48 ساعة)", "شهادة في كتابة السير الذاتية (CPRW, NCRW) مفضلة"],
  },
]

export default function CareersPage() {
  const { language } = useLanguage()
  const { toast } = useToast()
  const navigate = useNavigate()
  const isAr = language === 'ar'
  const [selectedPosition, setSelectedPosition] = useState<string>("")
  const [form, setForm] = useState({ full_name: "", email: "", phone: "", experience_years: "", cover_letter: "", portfolio_url: "", languages: "" })
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedPosition || !form.full_name || !form.email) {
      toast({ title: isAr ? "يرجى ملء جميع الحقول المطلوبة" : "Please fill all required fields", variant: "destructive" })
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch('/api/careers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, position: selectedPosition, experience_years: parseInt(form.experience_years) || 0 }),
      })
      if (!res.ok) throw new Error('Failed')
      setSubmitted(true)
      toast({ title: isAr ? "تم إرسال طلبك بنجاح!" : "Application submitted successfully!" })
    } catch {
      toast({ title: isAr ? "حدث خطأ" : "Something went wrong", variant: "destructive" })
    } finally {
      setSubmitting(false)
    }
  }

  if (submitted) {
    return (
      <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
        <Header />
        <main className="flex-1 flex items-center justify-center py-20">
          <Card className="max-w-md text-center">
            <CardContent className="p-10">
              <CheckCircle2 className="w-20 h-20 text-green-500 mx-auto mb-6" />
              <h2 className="text-2xl font-bold mb-3">{isAr ? "تم استلام طلبك!" : "Application Received!"}</h2>
              <p className="text-muted-foreground mb-6">{isAr ? "شكراً لاهتمامك بالانضمام لفريقنا. سنراجع طلبك ونتواصل معك لتحديد موعد المقابلة." : "Thank you for your interest in joining our team. We'll review your application and contact you to schedule an interview."}</p>
              <Button onClick={() => navigate('/')}>{isAr ? "العودة للرئيسية" : "Back to Home"}</Button>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1">
        {/* Hero */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-[#0a1628] via-[#0f2044] to-[#1a3a6a]" />
          <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '32px 32px' }} />
          <div className="container mx-auto px-4 relative z-10">
            <BackButton variant="light" />
            <div className="text-center max-w-3xl mx-auto mt-4">
              <Badge className="bg-[#c9a84c]/20 text-[#c9a84c] border-[#c9a84c]/30 mb-6">
                <Briefcase className="w-3.5 h-3.5 me-1.5" />{isAr ? "نحن نوظف!" : "We're Hiring!"}
              </Badge>
              <h1 className="text-4xl lg:text-5xl font-bold text-white mb-6">{isAr ? "انضم لفريق LogicCV" : "Join the LogicCV Team"}</h1>
              <p className="text-lg text-blue-100/70 leading-relaxed">{isAr ? "نبحث عن أشخاص موهوبين وشغوفين لمساعدتنا في بناء أفضل منصة لتحسين السير الذاتية في العالم." : "We're looking for talented, passionate people to help us build the world's best resume optimization platform."}</p>
            </div>
          </div>
        </section>

        {/* Positions */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4 max-w-5xl">
            <h2 className="text-3xl font-bold text-foreground mb-8 text-center">{isAr ? "الوظائف المتاحة" : "Open Positions"}</h2>
            <div className="grid gap-6 mb-16">
              {positions.map(pos => (
                <Card key={pos.id} className={`transition-all duration-300 ${selectedPosition === pos.id ? 'ring-2 ring-primary shadow-lg' : 'hover:shadow-md'}`}>
                  <CardHeader className="cursor-pointer" onClick={() => setSelectedPosition(pos.id)}>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-xl mb-2">{isAr ? pos.titleAr : pos.titleEn}</CardTitle>
                        <div className="flex flex-wrap gap-3">
                          <Badge variant="outline" className="gap-1"><MapPin className="w-3 h-3" />{isAr ? pos.typeAr : pos.typeEn}</Badge>
                          <Badge variant="outline" className="gap-1"><Clock className="w-3 h-3" />{isAr ? "التقديم مفتوح" : "Applications Open"}</Badge>
                        </div>
                      </div>
                      <Button size="sm" variant={selectedPosition === pos.id ? "default" : "outline"} onClick={(e) => { e.stopPropagation(); setSelectedPosition(pos.id) }}>
                        {isAr ? "قدّم الآن" : "Apply Now"}
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4 leading-relaxed">{isAr ? pos.descAr : pos.descEn}</p>
                    <h4 className="font-semibold text-foreground mb-3">{isAr ? "المتطلبات:" : "Requirements:"}</h4>
                    <ul className="space-y-2">
                      {(isAr ? pos.requirementsAr : pos.requirementsEn).map((req, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />{req}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Application Form */}
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-2xl">{isAr ? "نموذج التقديم" : "Application Form"}</CardTitle>
                <p className="text-muted-foreground">{isAr ? "املأ البيانات التالية وسنتواصل معك لتحديد موعد المقابلة" : "Fill in the details below and we'll contact you to schedule an interview"}</p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div><Label>{isAr ? "الاسم الكامل *" : "Full Name *"}</Label><Input required value={form.full_name} onChange={e => setForm(f => ({...f, full_name: e.target.value}))} /></div>
                    <div><Label>{isAr ? "البريد الإلكتروني *" : "Email *"}</Label><Input type="email" required value={form.email} onChange={e => setForm(f => ({...f, email: e.target.value}))} /></div>
                    <div><Label>{isAr ? "رقم الهاتف" : "Phone"}</Label><Input value={form.phone} onChange={e => setForm(f => ({...f, phone: e.target.value}))} /></div>
                    <div><Label>{isAr ? "سنوات الخبرة" : "Years of Experience"}</Label><Input type="number" min="0" value={form.experience_years} onChange={e => setForm(f => ({...f, experience_years: e.target.value}))} /></div>
                  </div>
                  <div>
                    <Label>{isAr ? "الوظيفة المطلوبة *" : "Position *"}</Label>
                    <Select value={selectedPosition} onValueChange={setSelectedPosition}>
                      <SelectTrigger><SelectValue placeholder={isAr ? "اختر الوظيفة" : "Select position"} /></SelectTrigger>
                      <SelectContent>
                        {positions.map(p => <SelectItem key={p.id} value={p.id}>{isAr ? p.titleAr : p.titleEn}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div><Label>{isAr ? "اللغات التي تتقنها" : "Languages you speak"}</Label><Input value={form.languages} onChange={e => setForm(f => ({...f, languages: e.target.value}))} placeholder={isAr ? "مثال: العربية، الإنجليزية" : "e.g., Arabic, English"} /></div>
                  <div><Label>{isAr ? "رابط معرض الأعمال (اختياري)" : "Portfolio URL (optional)"}</Label><Input value={form.portfolio_url} onChange={e => setForm(f => ({...f, portfolio_url: e.target.value}))} placeholder="https://..." /></div>
                  <div><Label>{isAr ? "رسالة التقديم" : "Cover Letter"}</Label><Textarea rows={5} value={form.cover_letter} onChange={e => setForm(f => ({...f, cover_letter: e.target.value}))} placeholder={isAr ? "أخبرنا لماذا تريد الانضمام لفريقنا..." : "Tell us why you want to join our team..."} /></div>
                  <Button type="submit" size="lg" className="w-full" disabled={submitting}>
                    {submitting ? <Loader2 className="w-5 h-5 me-2 animate-spin" /> : <Send className="w-5 h-5 me-2" />}
                    {isAr ? "إرسال الطلب" : "Submit Application"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
