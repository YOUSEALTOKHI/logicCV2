import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth/auth-context"
import { supabase } from "@/integrations/supabase/client"
import { FileText, Star, CreditCard, Upload, TrendingUp, Sparkles } from "lucide-react"
import { Link } from "react-router-dom"

export default function DashboardPage() {
  const { user, plan } = useAuth()
  const [resumeCount, setResumeCount] = useState(0)
  const [reviewCount, setReviewCount] = useState(0)
  const [profile, setProfile] = useState<any>(null)

  useEffect(() => {
    if (!user) return
    const load = async () => {
      const [resumes, reviews, prof] = await Promise.all([
        supabase.from("resumes").select("id", { count: "exact", head: true }).eq("user_id", user.id),
        supabase.from("reviews").select("id", { count: "exact", head: true }).eq("user_id", user.id),
        supabase.from("profiles").select("*").eq("user_id", user.id).maybeSingle(),
      ])
      setResumeCount(resumes.count ?? 0)
      setReviewCount(reviews.count ?? 0)
      setProfile(prof.data)
    }
    load()
  }, [user])

  const planColors: Record<string, string> = {
    free: "bg-muted text-muted-foreground",
    basic: "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300",
    pro: "bg-primary/10 text-primary",
    premium: "bg-gradient-to-r from-accent/20 to-primary/20 text-foreground",
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">
            Welcome{profile?.full_name ? `, ${profile.full_name}` : ""}! 👋
          </h1>
          <p className="text-muted-foreground mt-1">Here's your LogicCV overview</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{resumeCount}</p>
                <p className="text-sm text-muted-foreground">Resumes</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center">
                <Star className="w-6 h-6 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{reviewCount}</p>
                <p className="text-sm text-muted-foreground">Reviews</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-green-500/10 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">--</p>
                <p className="text-sm text-muted-foreground">Avg ATS Score</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className={`text-sm font-semibold px-2 py-0.5 rounded-full inline-block ${planColors[plan]}`}>
                  {plan.charAt(0).toUpperCase() + plan.slice(1)}
                </p>
                <p className="text-sm text-muted-foreground">Current Plan</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Sparkles className="w-5 h-5 text-primary" />Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Link to="/dashboard/resumes">
                <Button className="w-full justify-start" variant="outline">
                  <Upload className="w-4 h-4 mr-2" />Upload & Analyze Resume
                </Button>
              </Link>
              <Link to="/dashboard/reviews">
                <Button className="w-full justify-start" variant="outline">
                  <Star className="w-4 h-4 mr-2" />Write a Review
                </Button>
              </Link>
              <Link to="/dashboard/subscription">
                <Button className="w-full justify-start" variant="outline">
                  <CreditCard className="w-4 h-4 mr-2" />Upgrade Plan
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground text-sm">No recent activity yet. Upload your first resume to get started!</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
