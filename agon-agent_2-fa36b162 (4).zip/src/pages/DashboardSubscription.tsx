import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/lib/auth/auth-context"
import { Check, Zap } from "lucide-react"

const plans = [
  { id: "free" as const, name: "Free", price: "$0", period: "", features: ["1 ATS Scan", "Basic Analysis", "Keyword Suggestions"] },
  { id: "basic" as const, name: "Basic", price: "$49", period: "/one-time", features: ["Professional CV Writing", "1 Revision", "ATS Optimized", "48h Delivery"] },
  { id: "pro" as const, name: "Pro", price: "$79", period: "/one-time", features: ["Everything in Basic", "Unlimited Revisions", "Cover Letter", "24h Delivery", "No Ads"], popular: true },
  { id: "premium" as const, name: "Premium", price: "$129", period: "/one-time", features: ["Everything in Pro", "Career Consultation", "Interview Prep", "12h Express", "Priority Support", "No Ads"] },
]

export default function SubscriptionPage() {
  const { plan: currentPlan } = useAuth()

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Subscription</h1>
        <p className="text-muted-foreground">Choose the plan that fits your career goals</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {plans.map(plan => (
            <Card key={plan.id} className={`relative flex flex-col ${plan.popular ? "border-primary shadow-lg" : ""}`}>
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground">Popular</Badge>
                </div>
              )}
              <CardHeader className="text-center pt-8">
                <CardTitle>{plan.name}</CardTitle>
                <div className="mt-2">
                  <span className="text-3xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground text-sm">{plan.period}</span>
                </div>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col">
                <ul className="space-y-2 flex-1">
                  {plan.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm">
                      <Check className="w-4 h-4 text-green-500 shrink-0" />{f}
                    </li>
                  ))}
                </ul>
                <Button className="w-full mt-6" variant={currentPlan === plan.id ? "outline" : "default"} disabled={currentPlan === plan.id}>
                  {currentPlan === plan.id ? "Current Plan" : plan.id === "free" ? "Downgrade" : "Upgrade"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  )
}
