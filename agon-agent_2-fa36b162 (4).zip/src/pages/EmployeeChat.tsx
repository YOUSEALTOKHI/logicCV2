import { useState, useRef, useEffect, useCallback } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "@/lib/auth/auth-context"
import { supabase } from "@/integrations/supabase/client"
import {
  Send, Users, MessageCircle, Loader2, Paperclip, Image, FileText, Link,
  Mic, Video, Phone, PhoneCall, VideoIcon, X, Flame, CheckCircle2,
  Clock, Shield, StopCircle
} from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { useToast } from "@/hooks/use-toast"

interface Conversation {
  id: string
  customer_id: string
  employee_id: string | null
  status: string
  customer_plan: string
  is_express: boolean
  created_at: string
  customer_name?: string
}

interface ChatMessage {
  id: string
  conversation_id: string
  sender_id: string
  content: string
  message_type: string
  is_read: boolean
  created_at: string
}

export default function EmployeeChatPage() {
  const { user, hasRole } = useAuth()
  const { language } = useLanguage()
  const { toast } = useToast()
  const isAr = language === "ar"
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [activeConv, setActiveConv] = useState<Conversation | null>(null)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(true)
  const [isRecording, setIsRecording] = useState(false)
  const [showCallMenu, setShowCallMenu] = useState(false)
  const [activeCall, setActiveCall] = useState<"voice" | "video" | null>(null)
  const [showAttachMenu, setShowAttachMenu] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const imageInputRef = useRef<HTMLInputElement>(null)

  const isStaff = hasRole("employee") || hasRole("admin")

  const loadConversations = useCallback(async () => {
    const { data } = await supabase.from("chat_conversations").select("*").order("updated_at", { ascending: false })
    if (data) {
      const customerIds = [...new Set(data.map((c: any) => c.customer_id))]
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", customerIds)
      const nameMap = new Map(profiles?.map((p: any) => [p.user_id, p.full_name]) || [])
      setConversations(data.map((c: any) => ({ ...c, customer_name: nameMap.get(c.customer_id) || "Customer", is_express: c.is_express || false })))
    }
    setLoading(false)
  }, [])

  const loadMessages = useCallback(async (convId: string) => {
    const { data } = await supabase.from("chat_messages").select("*").eq("conversation_id", convId).order("created_at", { ascending: true })
    if (data) setMessages(data)
  }, [])

  useEffect(() => { loadConversations() }, [loadConversations])

  useEffect(() => {
    if (activeConv) {
      loadMessages(activeConv.id)
      const channel = supabase.channel(`chat-${activeConv.id}`).on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages", filter: `conversation_id=eq.${activeConv.id}` }, (payload: any) => {
        setMessages(prev => [...prev, payload.new])
      }).subscribe()
      return () => { supabase.removeChannel(channel) }
    }
  }, [activeConv, loadMessages])

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight
  }, [messages])

  const handleSend = async (type = "text", content?: string) => {
    const msgContent = content || input.trim()
    if (!msgContent || !activeConv || !user) return
    const { error } = await supabase.from("chat_messages").insert({
      conversation_id: activeConv.id, sender_id: user.id, content: msgContent, message_type: type,
    })
    if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); return }
    setInput("")
    setShowAttachMenu(false)
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: string) => {
    const file = e.target.files?.[0]
    if (!file || !activeConv) return
    await handleSend(type === "image" ? "image" : "file", `${isAr ? '\uD83D\uDCC1 \u0645\u0644\u0641:' : '\uD83D\uDCC1 File:'} ${file.name}`)
    e.target.value = ""
  }

  const handleStartRecording = () => {
    setIsRecording(true)
    toast({ title: isAr ? "\u062c\u0627\u0631\u064a \u0627\u0644\u062a\u0633\u062c\u064a\u0644..." : "Recording..." })
  }

  const handleStopRecording = () => {
    setIsRecording(false)
    handleSend("voice", isAr ? "\uD83C\uDF99\uFE0F \u0631\u0633\u0627\u0644\u0629 \u0635\u0648\u062a\u064a\u0629" : "\uD83C\uDF99\uFE0F Voice message")
  }

  const planBadgeColor: Record<string, string> = {
    free: "bg-muted text-muted-foreground",
    basic: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
    pro: "bg-[#0f2044]/10 text-[#0f2044]",
    premium: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
  }

  const planLabels: Record<string, string> = {
    free: isAr ? "\u0645\u062c\u0627\u0646\u064a" : "Free",
    basic: isAr ? "\u0623\u0633\u0627\u0633\u064a" : "Basic",
    pro: isAr ? "\u0627\u062d\u062a\u0631\u0627\u0641\u064a" : "Pro",
    premium: isAr ? "\u0645\u0645\u064a\u0632" : "Premium",
  }

  const sortedConvs = [...conversations].sort((a, b) => {
    if (a.is_express && !b.is_express) return -1
    if (!a.is_express && b.is_express) return 1
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  })

  if (!isStaff) {
    return (
      <DashboardLayout>
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold">{isAr ? "\u063a\u064a\u0631 \u0645\u0635\u0631\u062d" : "Unauthorized"}</h1>
          <p className="text-muted-foreground">{isAr ? "\u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062d\u0629 \u0644\u0644\u0645\u0648\u0638\u0641\u064a\u0646 \u0641\u0642\u0637" : "This page is for staff only"}</p>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">{isAr ? "\u0634\u0627\u062a \u0627\u0644\u0639\u0645\u0644\u0627\u0621" : "Customer Chat"}</h1>
          <Badge variant="outline" className="border-red-500/30 text-red-600">
            <Flame className="w-3 h-3 me-1" />{conversations.filter(c => c.is_express).length} {isAr ? "\u0637\u0644\u0628\u0627\u062a \u0633\u0631\u064a\u0639\u0629" : "Express"}
          </Badge>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-[calc(100vh-220px)]">
          <Card className="lg:col-span-1 flex flex-col">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Users className="w-4 h-4" />{isAr ? "\u0627\u0644\u0645\u062d\u0627\u062f\u062b\u0627\u062a" : "Conversations"} ({conversations.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 p-0 overflow-hidden">
              <ScrollArea className="h-full">
                {loading ? (
                  <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
                ) : conversations.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8 text-sm">{isAr ? "\u0644\u0627 \u062a\u0648\u062c\u062f \u0645\u062d\u0627\u062f\u062b\u0627\u062a" : "No conversations"}</p>
                ) : (
                  <div className="space-y-1 p-2">
                    {sortedConvs.map(conv => (
                      <button key={conv.id} onClick={() => setActiveConv(conv)}
                        className={`w-full text-left p-3 rounded-lg transition-colors relative ${
                          activeConv?.id === conv.id ? "bg-primary/10 border border-primary/20" : "hover:bg-muted"
                        } ${conv.is_express ? "border-l-4 border-l-red-500" : ""}`}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm truncate">{conv.customer_name}</span>
                            {conv.is_express && <Badge className="bg-red-500 text-white text-[9px] px-1.5 py-0.5 animate-pulse"><Flame className="w-2.5 h-2.5 me-0.5" />VIP</Badge>}
                          </div>
                          <Badge className={`text-[10px] px-1.5 py-0.5 ${planBadgeColor[conv.customer_plan] || ""}`}>{planLabels[conv.customer_plan] || conv.customer_plan.toUpperCase()}</Badge>
                        </div>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-xs text-muted-foreground">{new Date(conv.created_at).toLocaleDateString()}</span>
                          <Badge variant="outline" className="text-[10px]">{conv.status}</Badge>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          <Card className={`lg:col-span-2 flex flex-col ${activeConv?.is_express ? 'border-red-500/20' : ''}`}>
            {activeConv ? (
              <>
                <CardHeader className="pb-2 border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${activeConv.is_express ? 'bg-red-500/15' : 'bg-primary/10'}`}>
                        <MessageCircle className={`w-5 h-5 ${activeConv.is_express ? 'text-red-500' : 'text-primary'}`} />
                      </div>
                      <div>
                        <h3 className="font-semibold flex items-center gap-2">
                          {activeConv.customer_name}
                          {activeConv.is_express && <Badge className="bg-red-500 text-white text-[10px]"><Flame className="w-3 h-3 me-1" />{isAr ? "\u0637\u0644\u0628 \u0633\u0631\u064a\u0639 VIP" : "VIP Express"}</Badge>}
                        </h3>
                        <p className="text-xs text-muted-foreground">{isAr ? "\u0639\u0645\u064a\u0644" : "Customer"}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={planBadgeColor[activeConv.customer_plan] || ""}>{isAr ? `\u0628\u0627\u0642\u0629 ${planLabels[activeConv.customer_plan] || activeConv.customer_plan}` : `${planLabels[activeConv.customer_plan] || activeConv.customer_plan} Plan`}</Badge>
                      <div className="relative">
                        <Button variant="ghost" size="icon" className="text-green-600 hover:bg-green-50" onClick={() => setShowCallMenu(!showCallMenu)}><Phone className="w-5 h-5" /></Button>
                        {showCallMenu && (
                          <div className="absolute top-full end-0 mt-1 bg-card border border-border rounded-xl shadow-xl p-2 z-50 min-w-[160px]">
                            <button onClick={() => { setActiveCall("voice"); setShowCallMenu(false) }} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-muted text-sm"><PhoneCall className="w-4 h-4 text-green-600" />{isAr ? "\u0645\u0643\u0627\u0644\u0645\u0629 \u0635\u0648\u062a\u064a\u0629" : "Voice Call"}</button>
                            <button onClick={() => { setActiveCall("video"); setShowCallMenu(false) }} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-muted text-sm"><VideoIcon className="w-4 h-4 text-blue-600" />{isAr ? "\u0645\u0643\u0627\u0644\u0645\u0629 \u0641\u064a\u062f\u064a\u0648" : "Video Call"}</button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardHeader>

                {activeCall && (
                  <div className="bg-gradient-to-r from-green-500/10 via-green-500/15 to-green-500/10 border-b border-green-500/20 px-4 py-3 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center animate-pulse">
                        {activeCall === "voice" ? <PhoneCall className="w-4 h-4 text-green-600" /> : <VideoIcon className="w-4 h-4 text-green-600" />}
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-green-700">{activeCall === "voice" ? (isAr ? "\u0645\u0643\u0627\u0644\u0645\u0629 \u0635\u0648\u062a\u064a\u0629 \u0645\u0634\u0641\u0631\u0629" : "Encrypted Voice Call") : (isAr ? "\u0645\u0643\u0627\u0644\u0645\u0629 \u0641\u064a\u062f\u064a\u0648 \u0645\u0634\u0641\u0631\u0629" : "Encrypted Video Call")}</p>
                        <p className="text-xs text-green-600/60 flex items-center gap-1"><Shield className="w-3 h-3" />{isAr ? "\u0645\u0634\u0641\u0631\u0629 \u0645\u0646 \u0637\u0631\u0641 \u0644\u0637\u0631\u0641" : "End-to-end encrypted"}</p>
                      </div>
                    </div>
                    <Button variant="destructive" size="sm" className="bg-red-500 hover:bg-red-600" onClick={() => setActiveCall(null)}><StopCircle className="w-4 h-4 me-1" />{isAr ? "\u0625\u0646\u0647\u0627\u0621" : "End"}</Button>
                  </div>
                )}

                <CardContent className="flex-1 p-0 overflow-hidden">
                  <ScrollArea className="h-full p-4" ref={scrollRef}>
                    <div className="space-y-3">
                      {messages.map(msg => {
                        const isMine = msg.sender_id === user?.id
                        return (
                          <div key={msg.id} className={`flex ${isMine ? "justify-end" : "justify-start"}`}>
                            <div className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${isMine ? "bg-[#0f2044] text-white rounded-br-sm" : "bg-muted text-foreground rounded-bl-sm"}`}>
                              {(msg.message_type === "file") && <div className="flex items-center gap-2 mb-1"><FileText className="w-4 h-4" /><span className="font-medium">{isAr ? "\u0645\u0644\u0641 \u0645\u0631\u0641\u0642" : "Attached File"}</span></div>}
                              {(msg.message_type === "image") && <div className="flex items-center gap-2 mb-1"><Image className="w-4 h-4" /><span className="font-medium">{isAr ? "\u0635\u0648\u0631\u0629 \u0645\u0631\u0641\u0642\u0629" : "Attached Image"}</span></div>}
                              {(msg.message_type === "voice") && <div className="flex items-center gap-2"><Mic className="w-4 h-4" /><span className="font-medium">{isAr ? "\u0631\u0633\u0627\u0644\u0629 \u0635\u0648\u062a\u064a\u0629" : "Voice Message"}</span></div>}
                              <p>{msg.content}</p>
                              <p className="text-[10px] mt-1 opacity-60">{new Date(msg.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</p>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </ScrollArea>
                </CardContent>

                {showAttachMenu && (
                  <div className="px-4 py-2 border-t bg-muted/30">
                    <div className="flex gap-2 flex-wrap">
                      <Button variant="outline" size="sm" className="gap-1.5" onClick={() => imageInputRef.current?.click()}><Image className="w-4 h-4" />{isAr ? "\u0635\u0648\u0631\u0629" : "Image"}</Button>
                      <Button variant="outline" size="sm" className="gap-1.5" onClick={() => fileInputRef.current?.click()}><FileText className="w-4 h-4" />{isAr ? "\u0645\u0644\u0641" : "File"}</Button>
                      <Button variant="outline" size="sm" className="gap-1.5" onClick={() => { setInput(isAr ? "\uD83D\uDD17 " : "\uD83D\uDD17 "); setShowAttachMenu(false) }}><Link className="w-4 h-4" />{isAr ? "\u0631\u0627\u0628\u0637" : "Link"}</Button>
                      <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setShowAttachMenu(false)}><X className="w-4 h-4" />{isAr ? "\u0625\u063a\u0644\u0627\u0642" : "Close"}</Button>
                    </div>
                    <input ref={imageInputRef} type="file" accept="image/*,video/*" className="hidden" onChange={e => handleFileUpload(e, "image")} />
                    <input ref={fileInputRef} type="file" accept=".pdf,.doc,.docx,.txt,.zip" className="hidden" onChange={e => handleFileUpload(e, "file")} />
                  </div>
                )}

                <div className="p-3 border-t">
                  <form onSubmit={e => { e.preventDefault(); handleSend() }} className="flex gap-2 items-end">
                    <Button type="button" variant="ghost" size="icon" className="shrink-0 text-muted-foreground hover:text-foreground" onClick={() => setShowAttachMenu(!showAttachMenu)}><Paperclip className="w-5 h-5" /></Button>
                    <Input value={input} onChange={e => setInput(e.target.value)} placeholder={isAr ? "\u0627\u0643\u062a\u0628 \u0631\u0633\u0627\u0644\u062a\u0643..." : "Type a message..."} className="flex-1" />
                    {isRecording ? (
                      <Button type="button" size="icon" className="shrink-0 bg-red-500 text-white hover:bg-red-600 animate-pulse" onClick={handleStopRecording}><StopCircle className="w-5 h-5" /></Button>
                    ) : (
                      <Button type="button" variant="ghost" size="icon" className="shrink-0 text-muted-foreground hover:text-foreground" onClick={handleStartRecording}><Mic className="w-5 h-5" /></Button>
                    )}
                    <Button type="submit" size="icon" disabled={!input.trim()} className="shrink-0 bg-[#0f2044] text-white hover:bg-[#162d5a]"><Send className="w-4 h-4" /></Button>
                  </form>
                </div>
              </>
            ) : (
              <CardContent className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <MessageCircle className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold">{isAr ? "\u0627\u062e\u062a\u0631 \u0645\u062d\u0627\u062f\u062b\u0629" : "Select a conversation"}</h3>
                  <p className="text-muted-foreground text-sm">{isAr ? "\u0627\u062e\u062a\u0631 \u0645\u062d\u0627\u062f\u062b\u0629 \u0645\u0646 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0644\u0644\u0628\u062f\u0621" : "Choose a conversation from the list to start"}</p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
