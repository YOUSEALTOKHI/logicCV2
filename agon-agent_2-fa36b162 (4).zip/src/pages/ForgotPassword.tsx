import { useState } from "react"
import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { LogicCVLogo } from "@/components/ui/logiccv-logo"
import { supabase } from "@/integrations/supabase/client"
import { useToast } from "@/hooks/use-toast"
import { Loader2, ArrowLeft } from "lucide-react"

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [sent, setSent] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    })
    setIsLoading(false)
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" })
    } else {
      setSent(true)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-accent/5 p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center space-y-4">
          <Link to="/" className="flex justify-center"><LogicCVLogo size="lg" /></Link>
          <div>
            <CardTitle className="text-2xl">Reset Password</CardTitle>
            <CardDescription>{sent ? "Check your email" : "Enter your email to reset your password"}</CardDescription>
          </div>
        </CardHeader>
        {sent ? (
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">We sent a password reset link to <strong>{email}</strong></p>
            <Link to="/login"><Button variant="outline"><ArrowLeft className="w-4 h-4 mr-2" />Back to Login</Button></Link>
          </CardContent>
        ) : (
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required />
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-4">
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Send Reset Link
              </Button>
              <Link to="/login" className="text-sm text-primary hover:underline">Back to Login</Link>
            </CardFooter>
          </form>
        )}
      </Card>
    </div>
  )
}
