import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { HeroSection } from "@/components/landing/hero-section"
import { HowItWorks } from "@/components/landing/how-it-works"
import { FeaturesSection } from "@/components/landing/features-section"
import { TestimonialsSection } from "@/components/landing/testimonials-section"
import { PricingSection } from "@/components/landing/pricing-section"
import { FAQSection } from "@/components/landing/faq-section"
import { CTASection } from "@/components/landing/cta-section"
import { AIChatbot } from "@/components/chat/ai-chatbot"
import { ScrollToTop } from "@/components/scroll-to-top"
import { useLanguage } from "@/lib/i18n/language-context"
import { useAuth } from "@/lib/auth/auth-context"
import { AdBanner } from "@/components/ads/adsense-unit"

import { LiveATSSimulator } from "@/components/landing/live-ats-simulator"
import { ROICalculator } from "@/components/landing/roi-calculator"
import { ConversionFunnel } from "@/components/landing/conversion-funnel"
import { RealtimeCounters } from "@/components/landing/realtime-counters"
import { CaseStudy } from "@/components/landing/case-study"
import { AIDemo } from "@/components/landing/ai-demo"
import { LeadCapture } from "@/components/landing/lead-capture"
import { StickyCTA } from "@/components/landing/sticky-cta"
import { TrustBadges } from "@/components/landing/trust-badges"
import { PerformanceIndicators } from "@/components/landing/performance-indicators"
import { SmartRecommendations } from "@/components/landing/smart-recommendations"
import { ExitIntentPopup } from "@/components/landing/exit-intent-popup"

import "@/lib/tracking"

const Index = () => {
  const { dir } = useLanguage()
  const { isPremium, plan } = useAuth()
  const showAds = !isPremium && plan === 'free'

  return (
    <div className="min-h-screen flex flex-col" dir={dir}>
      <Header />
      <main className="flex-1">
        <HeroSection />
        <TrustBadges />
        <RealtimeCounters />
        <HowItWorks />

        {showAds && <AdBanner position="content" />}

        <LiveATSSimulator />
        <AIDemo />
        <FeaturesSection />
        <SmartRecommendations />

        {showAds && <AdBanner position="content" />}

        <LeadCapture />
        <CaseStudy />
        <ConversionFunnel />
        <TestimonialsSection />
        <ROICalculator />
        <PerformanceIndicators />
        <PricingSection />

        {showAds && <AdBanner position="content" />}

        <FAQSection />
        <CTASection />
      </main>
      <Footer />
      <StickyCTA />
      <ExitIntentPopup />
      <AIChatbot />
      <ScrollToTop />
    </div>
  )
}

export default Index
