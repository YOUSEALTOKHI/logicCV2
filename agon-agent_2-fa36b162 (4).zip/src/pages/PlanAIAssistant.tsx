import { useState, useRef, useEffect, useCallback } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "@/lib/auth/auth-context"
import { supabase } from "@/integrations/supabase/client"
import { Send, Bot, Sparkles, Loader2, FileText, Lock } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { useToast } from "@/hooks/use-toast"
import { Link } from "react-router-dom"

interface Message {
  role: "user" | "assistant"
  content: string
}

export default function PlanAIAssistantPage() {
  const { user, plan } = useAuth()
  const { language } = useLanguage()
  const { toast } = useToast()
  const isAr = language === "ar"
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [cvCount, setCvCount] = useState(0)
  const scrollRef = useRef<HTMLDivElement>(null)

  const hasAccess = plan === "pro" || plan === "premium"
  const maxCVs = plan === "pro" ? 3 : plan === "premium" ? 10 : 0

  useEffect(() => {
    if (user) {
      supabase.from("cv_creations").select("id", { count: "exact", head: true }).eq("user_id", user.id).then(({ count }) => {
        setCvCount(count ?? 0)
      })
    }
  }, [user])

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight
  }, [messages])

  const handleSend = useCallback(async () => {
    if (!input.trim() || loading || !user) return

    const userMsg: Message = { role: "user", content: input }
    const newMessages = [...messages, userMsg]
    setMessages(newMessages)
    setInput("")
    setLoading(true)

    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          mode: "plan_ai_assistant",
          language,
          messages: newMessages,
        }),
      })

      if (!response.ok) throw new Error("Failed")

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let assistantText = ""

      if (reader) {
        setMessages(prev => [...prev, { role: "assistant", content: "" }])
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          const chunk = decoder.decode(value, { stream: true })
          const lines = chunk.split("\n")
          for (const line of lines) {
            if (!line.startsWith("data: ") || line.includes("[DONE]")) continue
            try {
              const parsed = JSON.parse(line.slice(6))
              const content = parsed.choices?.[0]?.delta?.content
              if (content) {
                assistantText += content
                setMessages(prev => prev.map((m, i) => i === prev.length - 1 ? { ...m, content: assistantText } : m))
              }
            } catch {}
          }
        }
      }
    } catch {
      toast({ title: isAr ? "خطأ" : "Error", variant: "destructive" })
    } finally {
      setLoading(false)
    }
  }, [input, messages, loading, user, language, isAr, toast])

  if (!hasAccess) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Card className="max-w-md text-center">
            <CardContent className="py-12">
              <Lock className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
              <h2 className="text-2xl font-bold mb-2">{isAr ? "ميزة مخصصة للمشتركين" : "Subscribers Only"}</h2>
              <p className="text-muted-foreground mb-6">
                {isAr
                  ? "مساعد الذكاء الاصطناعي متاح فقط في باقة Pro ($79) و Premium ($129)"
                  : "AI Assistant is available only for Pro ($79) and Premium ($129) plans"}
              </p>
              <Link to="/dashboard/subscription">
                <Button>{isAr ? "ترقية الباقة" : "Upgrade Plan"}</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Sparkles className="w-7 h-7 text-primary" />
              {isAr ? "مساعد AI الذكي" : "AI Assistant"}
            </h1>
            <p className="text-muted-foreground mt-1">
              {isAr ? "حلل سيرتك الذاتية واحصل على نصائح مخصصة" : "Analyze your CV and get personalized advice"}
            </p>
          </div>
          <div className="flex gap-2">
            <Badge variant="outline">
              <FileText className="w-3 h-3 mr-1" />
              {isAr ? `${cvCount}/${maxCVs} سيرة ذاتية` : `${cvCount}/${maxCVs} CVs created`}
            </Badge>
            <Badge className="bg-primary text-primary-foreground">
              {plan.toUpperCase()}
            </Badge>
          </div>
        </div>

        <Card className="h-[calc(100vh-240px)] flex flex-col">
          <CardContent className="flex-1 p-0 overflow-hidden">
            <ScrollArea className="h-full p-4" ref={scrollRef}>
              <div className="space-y-4">
                {messages.length === 0 && (
                  <div className="text-center py-12">
                    <Bot className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold">{isAr ? "مرحباً! أنا المساعد الذكي" : "Hello! I'm LogicCV AI Assistant"}</h3>
                    <p className="text-muted-foreground text-sm mt-2 max-w-md mx-auto">
                      {isAr
                        ? "يمكنني تحليل سيرتك الذاتية، تقديم نصائح، وإنشاء سير ذاتية احترافية متوافقة مع ATS"
                        : "I can analyze your CV, provide tips, and create professional ATS-compatible resumes"}
                    </p>
                    <div className="flex flex-wrap gap-2 justify-center mt-6">
                      {[
                        isAr ? "حلل سيرتي الذاتية" : "Analyze my CV",
                        isAr ? "نصائح لتحسين ATS" : "ATS improvement tips",
                        isAr ? "أنشئ لي سيرة ذاتية" : "Create a CV for me",
                      ].map((q, i) => (
                        <Button key={i} variant="outline" size="sm" onClick={() => { setInput(q); }}>
                          {q}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}

                {messages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                    {msg.role === "assistant" && (
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-2 flex-shrink-0 mt-1">
                        <Bot className="w-4 h-4 text-primary" />
                      </div>
                    )}
                    <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap break-words ${
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground rounded-br-sm"
                        : "bg-muted text-foreground rounded-bl-sm"
                    }`}>
                      {msg.content || (loading && i === messages.length - 1 ? "..." : "")}
                    </div>
                  </div>
                ))}

                {loading && messages[messages.length - 1]?.role !== "assistant" && (
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-primary" />
                    <span className="text-sm text-muted-foreground">{isAr ? "جاري التفكير..." : "Thinking..."}</span>
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>

          <div className="p-4 border-t">
            <form onSubmit={e => { e.preventDefault(); handleSend() }} className="flex gap-2">
              <Input
                value={input}
                onChange={e => setInput(e.target.value)}
                placeholder={isAr ? "اكتب رسالتك أو الصق سيرتك الذاتية..." : "Type your message or paste your CV..."}
                disabled={loading}
                className="flex-1"
              />
              <Button type="submit" disabled={!input.trim() || loading}>
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </div>
        </Card>
      </div>
    </DashboardLayout>
  )
}
