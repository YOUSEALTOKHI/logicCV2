import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { useLanguage } from "@/lib/i18n/language-context"
import { BackButton } from "@/components/ui/back-button"

export default function PrivacyPolicy() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1 py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <BackButton />
          <h1 className="text-4xl font-bold text-foreground mb-8 mt-4">{isAr ? "سياسة الخصوصية" : "Privacy Policy"}</h1>
          <div className="prose prose-lg max-w-none text-muted-foreground space-y-6">
            <p className="text-sm text-muted-foreground">{isAr ? "آخر تحديث: يناير 2026" : "Last updated: January 2026"}</p>
            
            <h2 className="text-2xl font-bold text-foreground">{isAr ? "1. المقدمة" : "1. Introduction"}</h2>
            <p>{isAr ? "في LogicCV، نحترم خصوصيتك ونلتزم بحماية بياناتك الشخصية. توضح سياسة الخصوصية هذه كيفية جمع واستخدام وحماية معلوماتك عند استخدام منصتنا." : "At LogicCV, we respect your privacy and are committed to protecting your personal data. This Privacy Policy explains how we collect, use, and protect your information when you use our platform."}</p>
            
            <h2 className="text-2xl font-bold text-foreground">{isAr ? "2. البيانات التي نجمعها" : "2. Data We Collect"}</h2>
            <p>{isAr ? "نجمع المعلومات التالية:" : "We collect the following information:"}</p>
            <ul className="list-disc ps-6 space-y-2">
              <li>{isAr ? "معلومات الحساب: الاسم، البريد الإلكتروني، كلمة المرور المشفرة" : "Account information: name, email, encrypted password"}</li>
              <li>{isAr ? "بيانات السيرة الذاتية: المحتوى الذي ترفعه لتحليله" : "Resume data: content you upload for analysis"}</li>
              <li>{isAr ? "بيانات الاستخدام: كيفية تفاعلك مع المنصة" : "Usage data: how you interact with the platform"}</li>
              <li>{isAr ? "بيانات الدفع: تتم معالجتها بواسطة مزودي خدمات دفع آمنين" : "Payment data: processed by secure payment providers"}</li>
            </ul>
            
            <h2 className="text-2xl font-bold text-foreground">{isAr ? "3. كيف نستخدم بياناتك" : "3. How We Use Your Data"}</h2>
            <ul className="list-disc ps-6 space-y-2">
              <li>{isAr ? "تقديم وتحسين خدماتنا" : "To provide and improve our services"}</li>
              <li>{isAr ? "تحليل سيرتك الذاتية وتقديم التوصيات" : "To analyze your resume and provide recommendations"}</li>
              <li>{isAr ? "معالجة المدفوعات والاشتراكات" : "To process payments and subscriptions"}</li>
              <li>{isAr ? "التواصل معك بشأن حسابك" : "To communicate with you about your account"}</li>
            </ul>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "4. حماية البيانات" : "4. Data Protection"}</h2>
            <p>{isAr ? "نستخدم تشفير AES-256 لحماية بياناتك أثناء النقل والتخزين. جميع الاتصالات مشفرة بـ SSL/TLS. نلتزم بمعايير PCI DSS لمعالجة المدفوعات." : "We use AES-256 encryption to protect your data in transit and at rest. All communications are encrypted with SSL/TLS. We comply with PCI DSS standards for payment processing."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "5. مشاركة البيانات" : "5. Data Sharing"}</h2>
            <p>{isAr ? "لا نبيع أو نشارك بياناتك الشخصية مع أطراف ثالثة أبداً. قد نشارك بيانات مجهولة الهوية لأغراض تحليلية فقط." : "We never sell or share your personal data with third parties. We may share anonymized data for analytical purposes only."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "6. حقوقك" : "6. Your Rights"}</h2>
            <p>{isAr ? "لديك الحق في الوصول إلى بياناتك، تصحيحها، حذفها، أو نقلها. يمكنك ممارسة هذه الحقوق عبر التواصل معنا على support@logiccv.com" : "You have the right to access, correct, delete, or port your data. You can exercise these rights by contacting us at support@logiccv.com"}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "7. ملفات تعريف الارتباط" : "7. Cookies"}</h2>
            <p>{isAr ? "نستخدم ملفات تعريف الارتباط الضرورية لتشغيل المنصة وملفات تعريف الارتباط التحليلية لتحسين تجربتك. يمكنك إدارة تفضيلاتك من إعدادات المتصفح." : "We use essential cookies to operate the platform and analytical cookies to improve your experience. You can manage your preferences from your browser settings."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "8. التواصل" : "8. Contact"}</h2>
            <p>{isAr ? "لأي استفسارات حول الخصوصية، تواصل معنا على: support@logiccv.com" : "For any privacy inquiries, contact us at: support@logiccv.com"}</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
