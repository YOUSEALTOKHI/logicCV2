import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { useLanguage } from "@/lib/i18n/language-context"
import { BackButton } from "@/components/ui/back-button"

export default function RefundPolicy() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1 py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <BackButton />
          <h1 className="text-4xl font-bold text-foreground mb-8 mt-4">{isAr ? "سياسة الاسترداد" : "Refund Policy"}</h1>
          <div className="prose prose-lg max-w-none text-muted-foreground space-y-6">
            <p className="text-sm">{isAr ? "آخر تحديث: يناير 2026" : "Last updated: January 2026"}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "1. ضمان استرداد المال" : "1. Money-Back Guarantee"}</h2>
            <p>{isAr ? "نقدم ضمان استرداد المال خلال 7 أيام من تاريخ الشراء لجميع الباقات المدفوعة. إذا لم تكن راضياً عن الخدمة، يمكنك طلب استرداد كامل." : "We offer a 7-day money-back guarantee from the date of purchase for all paid plans. If you are not satisfied with the service, you can request a full refund."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "2. شروط الاسترداد" : "2. Refund Conditions"}</h2>
            <ul className="list-disc ps-6 space-y-2">
              <li>{isAr ? "يجب تقديم طلب الاسترداد خلال 7 أيام من الشراء" : "Refund request must be submitted within 7 days of purchase"}</li>
              <li>{isAr ? "يجب توضيح سبب عدم الرضا" : "Reason for dissatisfaction must be provided"}</li>
              <li>{isAr ? "الطلبات السريعة (3 ساعات) غير قابلة للاسترداد بعد بدء العمل" : "Express orders (3 hours) are non-refundable once work has started"}</li>
              <li>{isAr ? "الاسترداد لا يشمل الخدمات المجانية" : "Refunds do not apply to free services"}</li>
            </ul>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "3. عملية الاسترداد" : "3. Refund Process"}</h2>
            <p>{isAr ? "لطلب الاسترداد، تواصل معنا عبر support@logiccv.com مع ذكر رقم الطلب وسبب الاسترداد. سنعالج طلبك خلال 3-5 أيام عمل." : "To request a refund, contact us at support@logiccv.com with your order number and reason for the refund. We will process your request within 3-5 business days."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "4. طريقة الاسترداد" : "4. Refund Method"}</h2>
            <p>{isAr ? "يتم الاسترداد بنفس طريقة الدفع الأصلية. قد يستغرق ظهور المبلغ في حسابك 5-10 أيام عمل حسب البنك أو مزود الدفع." : "Refunds are issued to the original payment method. It may take 5-10 business days for the amount to appear in your account depending on your bank or payment provider."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "5. التعديلات والمراجعات" : "5. Revisions"}</h2>
            <p>{isAr ? "قبل طلب الاسترداد، نشجعك على الاستفادة من المراجعات المتاحة في باقتك. فريقنا مستعد لإجراء التعديلات حتى تكون راضياً تماماً." : "Before requesting a refund, we encourage you to take advantage of the revisions available in your plan. Our team is ready to make adjustments until you are fully satisfied."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "6. التواصل" : "6. Contact"}</h2>
            <p>{isAr ? "لأي استفسارات حول الاسترداد: support@logiccv.com" : "For any refund inquiries: support@logiccv.com"}</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
