import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { useLanguage } from "@/lib/i18n/language-context"

export default function ReviewsPage() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1 py-12 lg:py-16">
        <div className="container mx-auto px-4 max-w-6xl text-center">
          <h1 className="text-3xl lg:text-5xl font-bold text-foreground mb-3">
            {isAr ? "تقييمات العملاء" : "Customer Reviews"}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {isAr ? "اقرأ تجارب عملائنا الحقيقيين مع LogicCV" : "Read real experiences from our verified customers"}
          </p>
        </div>
      </main>
      <Footer />
    </div>
  )
}
