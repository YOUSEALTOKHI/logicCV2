import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { supabase } from "@/integrations/supabase/client"
import { useAuth } from "@/lib/auth/auth-context"
import { HeadphonesIcon, Loader2, TicketCheck, Clock, AlertTriangle, CheckCircle } from "lucide-react"
import { Link } from "react-router-dom"

export default function SupportDashboard() {
  const { hasRole } = useAuth()
  const [stats, setStats] = useState({ total: 0, open: 0, in_progress: 0, resolved: 0 })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      const [total, open, inProg, resolved] = await Promise.all([
        supabase.from("support_tickets").select("id", { count: "exact", head: true }),
        supabase.from("support_tickets").select("id", { count: "exact", head: true }).eq("status", "open"),
        supabase.from("support_tickets").select("id", { count: "exact", head: true }).eq("status", "in_progress"),
        supabase.from("support_tickets").select("id", { count: "exact", head: true }).eq("status", "resolved"),
      ])
      setStats({
        total: total.count ?? 0,
        open: open.count ?? 0,
        in_progress: inProg.count ?? 0,
        resolved: resolved.count ?? 0,
      })
      setLoading(false)
    }
    load()
  }, [])

  const cards = [
    { title: "إجمالي التذاكر", titleEn: "Total Tickets", value: stats.total, icon: TicketCheck, color: "bg-primary/10 text-primary" },
    { title: "مفتوحة", titleEn: "Open", value: stats.open, icon: AlertTriangle, color: "bg-yellow-500/10 text-yellow-500" },
    { title: "قيد المعالجة", titleEn: "In Progress", value: stats.in_progress, icon: Clock, color: "bg-blue-500/10 text-blue-500" },
    { title: "تم الحل", titleEn: "Resolved", value: stats.resolved, icon: CheckCircle, color: "bg-green-500/10 text-green-500" },
  ]

  if (!hasRole("support") && !hasRole("admin")) {
    return (
      <DashboardLayout>
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold">Unauthorized</h1>
          <p className="text-muted-foreground">This page is for support staff only</p>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HeadphonesIcon className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold">Support Dashboard</h1>
          </div>
          <Link to="/support/tickets">
            <Button>View All Tickets</Button>
          </Link>
        </div>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {cards.map(card => (
              <Card key={card.titleEn}>
                <CardContent className="p-6 flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${card.color}`}>
                    <card.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{card.value}</p>
                    <p className="text-sm text-muted-foreground">{card.titleEn}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
