import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { useLanguage } from "@/lib/i18n/language-context"
import { BackButton } from "@/components/ui/back-button"

export default function TermsOfService() {
  const { language } = useLanguage()
  const isAr = language === 'ar'

  return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1 py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <BackButton />
          <h1 className="text-4xl font-bold text-foreground mb-8 mt-4">{isAr ? "شروط الخدمة" : "Terms of Service"}</h1>
          <div className="prose prose-lg max-w-none text-muted-foreground space-y-6">
            <p className="text-sm">{isAr ? "آخر تحديث: يناير 2026" : "Last updated: January 2026"}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "1. قبول الشروط" : "1. Acceptance of Terms"}</h2>
            <p>{isAr ? "باستخدامك لمنصة LogicCV، فإنك توافق على الالتزام بهذه الشروط والأحكام. إذا كنت لا توافق على أي من هذه الشروط، يرجى عدم استخدام المنصة." : "By using the LogicCV platform, you agree to be bound by these terms and conditions. If you do not agree to any of these terms, please do not use the platform."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "2. الخدمات" : "2. Services"}</h2>
            <p>{isAr ? "توفر LogicCV خدمات تحسين السيرة الذاتية تشمل: فحص ATS، كتابة السيرة الذاتية الاحترافية، مطابقة الوظائف، ومساعد الذكاء الاصطناعي. الخدمات متاحة حسب الباقة المختارة." : "LogicCV provides resume optimization services including: ATS scanning, professional CV writing, job matching, and AI assistant. Services are available according to the selected plan."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "3. الحسابات والتسجيل" : "3. Accounts & Registration"}</h2>
            <p>{isAr ? "أنت مسؤول عن الحفاظ على سرية بيانات حسابك. يجب أن تكون المعلومات المقدمة دقيقة وحديثة. يحق لنا تعليق أو إنهاء الحسابات التي تنتهك شروطنا." : "You are responsible for maintaining the confidentiality of your account credentials. Information provided must be accurate and current. We reserve the right to suspend or terminate accounts that violate our terms."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "4. الدفع والاشتراكات" : "4. Payment & Subscriptions"}</h2>
            <p>{isAr ? "جميع الأسعار معروضة بالدولار الأمريكي. الدفع يتم لمرة واحدة حسب الباقة المختارة. يتم معالجة المدفوعات بشكل آمن عبر مزودي خدمات دفع معتمدين." : "All prices are displayed in USD. Payment is a one-time charge based on the selected plan. Payments are securely processed through certified payment providers."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "5. حقوق الملكية الفكرية" : "5. Intellectual Property"}</h2>
            <p>{isAr ? "جميع محتويات المنصة، بما في ذلك التصميم والشعارات والنصوص والبرمجيات، هي ملكية فكرية لـ LogicCV. السير الذاتية التي تنشئها تبقى ملكاً لك." : "All platform content, including design, logos, text, and software, is the intellectual property of LogicCV. Resumes you create remain your property."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "6. الاستخدام المحظور" : "6. Prohibited Use"}</h2>
            <ul className="list-disc ps-6 space-y-2">
              <li>{isAr ? "محاولة اختراق أو تعطيل المنصة" : "Attempting to hack or disrupt the platform"}</li>
              <li>{isAr ? "رفع محتوى ضار أو فيروسات" : "Uploading harmful content or viruses"}</li>
              <li>{isAr ? "انتحال هوية شخص آخر" : "Impersonating another person"}</li>
              <li>{isAr ? "استخدام المنصة لأغراض غير قانونية" : "Using the platform for illegal purposes"}</li>
            </ul>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "7. إخلاء المسؤولية" : "7. Disclaimer"}</h2>
            <p>{isAr ? "نبذل قصارى جهدنا لتقديم خدمات عالية الجودة، لكننا لا نضمن الحصول على وظيفة. النتائج تعتمد على عوامل متعددة خارج سيطرتنا." : "We make every effort to provide high-quality services, but we do not guarantee employment. Results depend on multiple factors beyond our control."}</p>

            <h2 className="text-2xl font-bold text-foreground">{isAr ? "8. التواصل" : "8. Contact"}</h2>
            <p>{isAr ? "لأي استفسارات حول الشروط: support@logiccv.com" : "For any inquiries about these terms: support@logiccv.com"}</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
