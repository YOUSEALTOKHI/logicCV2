import { useState, useRef, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageCircle, X, Send, Bot, User, Sparkles } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

interface Message {
  id: string; role: "user" | "assistant"; content: string; timestamp: Date
}

export function AIChatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const { language, dir } = useLanguage()

  const getInitialMessage = useCallback((): Message => ({
    id: "1", role: "assistant",
    content: language === 'ar'
      ? "مرحباً! أنا مساعد LogicCV الذكي. كيف يمكنني مساعدتك اليوم؟"
      : "Hello! I'm LogicCV AI Assistant. How can I help you today?",
    timestamp: new Date()
  }), [language])

  useEffect(() => { setMessages([getInitialMessage()]) }, [getInitialMessage])
  useEffect(() => { scrollRef.current && (scrollRef.current.scrollTop = scrollRef.current.scrollHeight) }, [messages])

  const generateResponse = (msg: string): string => {
    const lower = msg.toLowerCase()
    const isAr = language === 'ar'
    if (lower.includes("ats") || lower.includes("تتبع"))
      return isAr ? "نظام ATS يستخدمه 98% من الشركات لتصفية السير الذاتية. هل تريد تجربة فحص ATS المجاني؟" : "ATS is used by 98% of Fortune 500 companies. Would you like to try our free ATS scan?"
    if (lower.includes("price") || lower.includes("cost") || lower.includes("سعر"))
      return isAr ? "نقدم: مجاني، أساسي ($49)، احترافي ($79)، مميز ($129). أي خطة تهمك؟" : "We offer: Free, Basic ($49), Pro ($79), Premium ($129). Which interests you?"
    return isAr ? "سأكون سعيداً بالمساعدة! هل هناك شيء آخر؟" : "I'd be happy to help! Is there anything else I can explain?"
  }

  const handleSend = async (text?: string) => {
    const msg = text || input
    if (!msg.trim()) return
    setMessages(prev => [...prev, { id: Date.now().toString(), role: "user", content: msg, timestamp: new Date() }])
    setInput(""); setIsTyping(true)
    await new Promise(r => setTimeout(r, 1000))
    setIsTyping(false)
    setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: "assistant", content: generateResponse(msg), timestamp: new Date() }])
  }

  if (!isOpen) {
    return (
      <Button onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90">
        <MessageCircle className="w-6 h-6" />
      </Button>
    )
  }

  return (
    <Card className="fixed bottom-6 right-6 z-50 w-[380px] h-[500px] shadow-2xl flex flex-col" dir={dir}>
      <CardHeader className="bg-primary text-primary-foreground rounded-t-lg p-4 flex flex-row items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5" />
          <CardTitle className="text-base">{language === 'ar' ? 'المساعد الذكي' : 'AI Assistant'}</CardTitle>
        </div>
        <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="text-primary-foreground hover:bg-primary-foreground/10">
          <X className="w-4 h-4" />
        </Button>
      </CardHeader>
      <CardContent className="flex-1 p-0 overflow-hidden">
        <ScrollArea className="h-full p-4" ref={scrollRef}>
          <div className="space-y-4">
            {messages.map(msg => (
              <div key={msg.id} className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {msg.role === 'assistant' && <Avatar className="w-8 h-8"><AvatarFallback className="bg-primary text-primary-foreground text-xs"><Bot className="w-4 h-4" /></AvatarFallback></Avatar>}
                <div className={`max-w-[75%] rounded-lg p-3 text-sm ${msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground'}`}>
                  {msg.content}
                </div>
                {msg.role === 'user' && <Avatar className="w-8 h-8"><AvatarFallback className="bg-accent text-accent-foreground text-xs"><User className="w-4 h-4" /></AvatarFallback></Avatar>}
              </div>
            ))}
            {isTyping && <div className="flex gap-2"><Avatar className="w-8 h-8"><AvatarFallback className="bg-primary text-primary-foreground text-xs"><Bot className="w-4 h-4" /></AvatarFallback></Avatar><div className="bg-muted rounded-lg p-3 text-sm text-muted-foreground">...</div></div>}
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter className="p-3 border-t">
        <form onSubmit={e => { e.preventDefault(); handleSend() }} className="flex gap-2 w-full">
          <Input value={input} onChange={e => setInput(e.target.value)} placeholder={language === 'ar' ? 'اسألني أي شيء...' : 'Ask me anything...'} className="flex-1" />
          <Button type="submit" size="icon" className="bg-primary text-primary-foreground"><Send className="w-4 h-4" /></Button>
        </form>
      </CardFooter>
    </Card>
  )
}
