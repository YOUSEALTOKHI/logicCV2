import { Button } from "@/components/ui/button"
import { ArrowRight, Shield, CreditCard, Zap } from "lucide-react"

export function CTASection() {
  return (
    <section className="py-16 lg:py-24 bg-gradient-to-r from-primary via-secondary to-primary">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl lg:text-4xl font-bold text-primary-foreground mb-6 text-balance">Ready to Land Your Dream Job?</h2>
          <p className="text-lg text-primary-foreground/80 mb-8 leading-relaxed">Start optimizing your resume today and get more interviews</p>
          <div className="flex flex-wrap justify-center gap-6 mb-8">
            {[
              { icon: Zap, text: "Free to start" },
              { icon: CreditCard, text: "No credit card required" },
              { icon: Shield, text: "Results in seconds" },
            ].map(({ icon: Icon, text }, i) => (
              <div key={i} className="flex items-center gap-2 text-primary-foreground/80">
                <Icon className="w-5 h-5" /><span className="text-sm">{text}</span>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="bg-card text-primary hover:bg-card/90">
              Start Free Scan<ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <Button size="lg" variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10">
              View Services
            </Button>
          </div>
          <div className="flex justify-center items-center gap-6 mt-10">
            <div className="flex items-center gap-2 text-primary-foreground/70 text-sm"><Shield className="w-4 h-4" />SSL Secured</div>
            <div className="text-primary-foreground/70 text-sm">GDPR Compliant</div>
            <div className="text-primary-foreground/70 text-sm">Money Back Guarantee</div>
          </div>
        </div>
      </div>
    </section>
  )
}
