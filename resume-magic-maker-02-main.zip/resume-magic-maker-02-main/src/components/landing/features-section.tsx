import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScanLine, FileSearch, DollarSign, MessageSquare, FileText, Mail, BarChart2, Target, BadgeCheck, Users, Globe, FileEdit } from "lucide-react"

const features = [
  { icon: ScanLine, title: "ATS Scanner", description: "Check if your resume can pass applicant tracking systems", badge: "Free" },
  { icon: FileSearch, title: "Job Description Matcher", description: "Compare your CV with any job posting to see match percentage.", badge: "Free" },
  { icon: DollarSign, title: "Salary Insights", description: "Get salary predictions based on your profile", badge: "New" },
  { icon: MessageSquare, title: "Interview Prep", description: "Practice with AI-powered mock interviews", badge: "Pro" },
  { icon: FileText, title: "Cover Letter Generator", description: "Create customized cover letters for each job application.", badge: "Pro" },
  { icon: Mail, title: "Email Generator", description: "Generate professional follow-up and application emails.", badge: "Pro" },
  { icon: BarChart2, title: "Skill Gap Analysis", description: "Identify missing skills for your target role." },
  { icon: Target, title: "Keyword Optimization", description: "Optimize keywords to match job descriptions" },
  { icon: BadgeCheck, title: "Verification Badge", description: "Get a QR code on your CV that employers can scan.", badge: "Pro" },
  { icon: Users, title: "Competitive Analysis", description: "Compare your resume against others in your field.", badge: "Pro" },
  { icon: Globe, title: "Multi-Language Support", description: "Full support for English and Arabic with professional translations." },
  { icon: FileEdit, title: "Professional CV Writing", description: "Get your resume written by certified professionals.", badge: "Premium" },
]

const getBadgeClass = (badge?: string) => {
  switch (badge) {
    case "Free": return "bg-green-100 text-green-700"
    case "New": return "bg-accent/20 text-accent-foreground"
    case "Pro": return "bg-primary/10 text-primary"
    case "Premium": return "bg-gradient-to-r from-accent to-primary text-primary-foreground"
    default: return ""
  }
}

export function FeaturesSection() {
  return (
    <section id="features" className="py-16 lg:py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Powerful Features</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Everything you need to land your dream job</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-0 bg-card">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary transition-colors">
                    <feature.icon className="w-6 h-6 text-primary group-hover:text-primary-foreground transition-colors" />
                  </div>
                  {feature.badge && <Badge className={`text-xs ${getBadgeClass(feature.badge)}`}>{feature.badge}</Badge>}
                </div>
              </CardHeader>
              <CardContent>
                <CardTitle className="text-lg mb-2">{feature.title}</CardTitle>
                <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
