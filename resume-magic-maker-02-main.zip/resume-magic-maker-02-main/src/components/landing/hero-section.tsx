import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useLanguage } from "@/lib/i18n/language-context"
import { Upload, CheckCircle2, Shield, Zap, FileText, ArrowRight, Sparkles } from "lucide-react"

export function HeroSection() {
  const { language, dir } = useLanguage()
  const [isDragging, setIsDragging] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [progress, setProgress] = useState(0)

  const handleDragOver = useCallback((e: React.DragEvent) => { e.preventDefault(); setIsDragging(true) }, [])
  const handleDragLeave = useCallback((e: React.DragEvent) => { e.preventDefault(); setIsDragging(false) }, [])
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); setIsDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) { setUploadedFile(file); startAnalysis() }
  }, [])

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) { setUploadedFile(file); startAnalysis() }
  }

  const startAnalysis = () => {
    setIsAnalyzing(true); setProgress(0)
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) { clearInterval(interval); setIsAnalyzing(false); return 100 }
        return prev + 10
      })
    }, 200)
  }

  const c = language === 'ar' ? {
    badge: "تحسين السيرة الذاتية بالذكاء الاصطناعي",
    title: "حسّن سيرتك الذاتية لنظام", titleHighlight: "ATS",
    subtitle: "اجعل سيرتك الذاتية تتجاوز أنظمة تتبع المتقدمين واحصل على وظيفة أحلامك.",
    stat1: "3x", stat1Label: "مقابلات أكثر", stat2: "+50 ألف", stat2Label: "سيرة ذاتية محسّنة",
    stat3: "95%", stat3Label: "معدل النجاح",
    startScan: "ابدأ الفحص المجاني", viewServices: "عرض الخدمات",
    freeATSScan: "فحص ATS مجاني", uploadText: "ارفع سيرتك الذاتية (PDF أو DOCX)",
    clickUpload: "انقر للرفع أو اسحب وأفلت", fileSize: "PDF, DOCX حتى 10MB",
    uploadButton: "رفع السيرة الذاتية", analyzing: "جاري التحليل...",
    freeAnalysis: "تحليل مجاني", secure: "آمن", instant: "فوري",
  } : {
    badge: "AI-Powered Resume Optimization",
    title: "Optimize Your Resume for the", titleHighlight: "ATS",
    subtitle: "Get your CV past the applicant tracking systems and land your dream job. Our AI analyzes your resume against 30+ parameters.",
    stat1: "3x", stat1Label: "More Interviews", stat2: "50K+", stat2Label: "Resumes Optimized",
    stat3: "95%", stat3Label: "Success Rate",
    startScan: "Start Free Scan", viewServices: "View Services",
    freeATSScan: "Free ATS Scan", uploadText: "Upload Your Resume (PDF or DOCX)",
    clickUpload: "Click to upload or drag and drop", fileSize: "PDF, DOCX up to 10MB",
    uploadButton: "Upload Resume", analyzing: "Analyzing...",
    freeAnalysis: "Free Analysis", secure: "Secure", instant: "Instant",
  }

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-secondary py-16 lg:py-24" dir={dir}>
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs><pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5"/>
          </pattern></defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>
      <div className="absolute top-20 start-10 w-20 h-20 bg-accent/20 rounded-full blur-xl animate-pulse" />
      <div className="absolute bottom-20 end-10 w-32 h-32 bg-secondary/30 rounded-full blur-xl animate-pulse" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-start">
            <div className="inline-flex items-center gap-2 bg-accent/20 text-primary-foreground px-4 py-2 rounded-full text-sm mb-6">
              <Sparkles className="w-4 h-4" />{c.badge}
            </div>
            <h1 className="text-4xl lg:text-5xl xl:text-6xl font-bold text-primary-foreground leading-tight mb-6 text-balance">
              {c.title}{" "}<span className="text-accent">{c.titleHighlight}</span>
            </h1>
            <p className="text-lg lg:text-xl text-primary-foreground/80 mb-8 leading-relaxed max-w-xl">{c.subtitle}</p>
            <div className="flex flex-wrap justify-center lg:justify-start gap-8 mb-8">
              {[[c.stat1, c.stat1Label], [c.stat2, c.stat2Label], [c.stat3, c.stat3Label]].map(([val, label], i) => (
                <div key={i} className="text-center">
                  <div className="text-3xl font-bold text-accent">{val}</div>
                  <div className="text-sm text-primary-foreground/70">{label}</div>
                </div>
              ))}
            </div>
            <div className="flex flex-wrap justify-center lg:justify-start gap-4">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                {c.startScan}<ArrowRight className="w-4 h-4 ms-2" />
              </Button>
              <Button size="lg" variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10">
                {c.viewServices}
              </Button>
            </div>
          </div>

          <div className="flex justify-center">
            <Card className="w-full max-w-md bg-card/95 backdrop-blur shadow-2xl border-0">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <h2 className="text-xl font-bold text-foreground mb-2">{c.freeATSScan}</h2>
                  <p className="text-sm text-muted-foreground">{c.uploadText}</p>
                </div>
                <div className={`relative border-2 border-dashed rounded-xl p-8 transition-all cursor-pointer ${
                  isDragging ? "border-primary bg-primary/5" : "border-muted-foreground/30 hover:border-primary/50 hover:bg-muted/50"
                }`} onDragOver={handleDragOver} onDragLeave={handleDragLeave} onDrop={handleDrop}>
                  <input type="file" accept=".pdf,.docx" onChange={handleFileSelect} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                  {uploadedFile ? (
                    <div className="text-center">
                      <FileText className="w-12 h-12 mx-auto text-primary mb-3" />
                      <p className="font-medium text-foreground">{uploadedFile.name}</p>
                      {isAnalyzing && <div className="mt-4"><Progress value={progress} className="h-2" /><p className="text-sm text-muted-foreground mt-2">{c.analyzing} {progress}%</p></div>}
                    </div>
                  ) : (
                    <div className="text-center">
                      <Upload className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
                      <p className="font-medium text-foreground mb-1">{c.clickUpload}</p>
                      <p className="text-xs text-muted-foreground">{c.fileSize}</p>
                    </div>
                  )}
                </div>
                {!uploadedFile && (
                  <Button className="w-full mt-4 bg-primary text-primary-foreground hover:bg-primary/90">
                    <Upload className="w-4 h-4 me-2" />{c.uploadButton}
                  </Button>
                )}
                <div className="flex justify-center gap-6 mt-6 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4 text-green-500" />{c.freeAnalysis}</div>
                  <div className="flex items-center gap-1"><Shield className="w-4 h-4 text-green-500" />{c.secure}</div>
                  <div className="flex items-center gap-1"><Zap className="w-4 h-4 text-green-500" />{c.instant}</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
