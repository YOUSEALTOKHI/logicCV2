import { Link } from "react-router-dom"
import { Mail, Phone, MapPin, ExternalLink } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { LogicCVLogo } from "@/components/ui/logiccv-logo"

export function Footer() {
  const { language, dir } = useLanguage()

  const c = language === 'ar' ? {
    description: "منصة تحسين السيرة الذاتية بالذكاء الاصطناعي.",
    quickLinks: "روابط سريعة", howItWorks: "كيف يعمل", features: "المميزات",
    pricing: "الأسعار", blog: "المدونة", careers: "الوظائف",
    support: "الدعم", faq: "الأسئلة الشائعة", contactUs: "اتصل بنا",
    privacy: "سياسة الخصوصية", terms: "شروط الخدمة", refund: "سياسة الاسترداد",
    contact: "التواصل", sslSecured: "مشفر بـ SSL", gdprCompliant: "متوافق مع GDPR",
    moneyBack: "ضمان استرداد المال",
    copyright: `${new Date().getFullYear()} LogicCV. جميع الحقوق محفوظة.`
  } : {
    description: "AI-powered resume optimization platform. Get your CV past ATS systems and land your dream job.",
    quickLinks: "Quick Links", howItWorks: "How It Works", features: "Features",
    pricing: "Pricing", blog: "Blog", careers: "Careers",
    support: "Support", faq: "FAQ", contactUs: "Contact Us",
    privacy: "Privacy Policy", terms: "Terms of Service", refund: "Refund Policy",
    contact: "Contact", sslSecured: "SSL Secured", gdprCompliant: "GDPR Compliant",
    moneyBack: "Money Back Guarantee",
    copyright: `${new Date().getFullYear()} LogicCV. All rights reserved.`
  }

  return (
    <footer className="bg-primary text-primary-foreground" dir={dir}>
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="space-y-4">
            <Link to="/"><LogicCVLogo variant="light" size="md" /></Link>
            <p className="text-sm text-primary-foreground/80 leading-relaxed">{c.description}</p>
            <div className="flex items-center gap-3">
              {[ExternalLink, ExternalLink, ExternalLink, ExternalLink, ExternalLink].map((Icon, i) => (
                <a key={i} href="#" className="p-2 bg-primary-foreground/10 rounded-full hover:bg-primary-foreground/20 transition-colors">
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-4">{c.quickLinks}</h3>
            <ul className="space-y-2">
              {[
                { href: "#how-it-works", label: c.howItWorks },
                { href: "#features", label: c.features },
                { href: "#pricing", label: c.pricing },
                { href: "#", label: c.blog },
                { href: "#", label: c.careers },
              ].map((l, i) => (
                <li key={i}><a href={l.href} className="text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors">{l.label}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-4">{c.support}</h3>
            <ul className="space-y-2">
              {[c.faq, c.contactUs, c.privacy, c.terms, c.refund].map((label, i) => (
                <li key={i}><a href="#" className="text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors">{label}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-4">{c.contact}</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-primary-foreground/80"><Mail className="w-4 h-4" />support@logiccv.com</li>
              <li className="flex items-center gap-2 text-sm text-primary-foreground/80"><Phone className="w-4 h-4" />+1 (555) 123-4567</li>
              <li className="flex items-start gap-2 text-sm text-primary-foreground/80"><MapPin className="w-4 h-4 mt-0.5" /><span>123 Career Street,<br />San Francisco, CA 94105</span></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-primary-foreground/20">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-primary-foreground/80">&copy; {c.copyright}</p>
            <div className="flex items-center gap-4">
              <span className="text-xs text-primary-foreground/60">{c.sslSecured}</span>
              <span className="text-xs text-primary-foreground/60">{c.gdprCompliant}</span>
              <span className="text-xs text-primary-foreground/60">{c.moneyBack}</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
