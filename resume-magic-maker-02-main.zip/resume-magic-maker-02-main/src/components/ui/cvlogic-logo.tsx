import { cn } from "@/lib/utils"

interface CVLogicLogoProps {
  className?: string
  size?: "sm" | "md" | "lg" | "xl"
  showText?: boolean
  variant?: "light" | "dark" | "auto"
}

export function CVLogicLogo({ className, size = "md", showText = true, variant = "auto" }: CVLogicLogoProps) {
  const sizeClasses = {
    sm: { icon: "w-6 h-6", text: "text-lg" },
    md: { icon: "w-8 h-8", text: "text-xl" },
    lg: { icon: "w-10 h-10", text: "text-2xl" },
    xl: { icon: "w-14 h-14", text: "text-3xl" },
  }

  const variantClasses = {
    light: "text-primary-foreground",
    dark: "text-primary",
    auto: "text-primary dark:text-primary-foreground",
  }

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className={cn("relative flex items-center justify-center", sizeClasses[size].icon)}>
        <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
          <path
            d="M24 4L6 12V24C6 35.0457 14.2053 44.4277 24 46C33.7947 44.4277 42 35.0457 42 24V12L24 4Z"
            className={cn(
              variant === "light" ? "fill-primary-foreground" :
              variant === "dark" ? "fill-primary" :
              "fill-primary dark:fill-primary-foreground"
            )}
          />
          <path
            d="M20 28L16 24L14 26L20 32L34 18L32 16L20 28Z"
            className={cn(
              variant === "light" ? "fill-primary" :
              variant === "dark" ? "fill-primary-foreground" :
              "fill-primary-foreground dark:fill-primary"
            )}
          />
        </svg>
      </div>
      {showText && (
        <span className={cn("font-bold tracking-tight", sizeClasses[size].text, variantClasses[variant])}>
          CV<span className="text-accent">Logic</span>
        </span>
      )}
    </div>
  )
}
