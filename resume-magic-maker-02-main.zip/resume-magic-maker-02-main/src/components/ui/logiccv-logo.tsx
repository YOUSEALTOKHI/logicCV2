import { cn } from "@/lib/utils"
import logoImg from "@/assets/logiccv-logo.png"

interface LogicCVLogoProps {
  className?: string
  size?: "sm" | "md" | "lg" | "xl"
  showText?: boolean
  variant?: "light" | "dark" | "auto"
}

export function LogicCVLogo({ className, size = "md", showText = true, variant = "auto" }: LogicCVLogoProps) {
  const sizeClasses = {
    sm: { icon: "w-7 h-7", text: "text-lg", bg: "p-1" },
    md: { icon: "w-9 h-9", text: "text-xl", bg: "p-1.5" },
    lg: { icon: "w-11 h-11", text: "text-2xl", bg: "p-2" },
    xl: { icon: "w-14 h-14", text: "text-3xl", bg: "p-2.5" },
  }

  const variantClasses = {
    light: "text-primary-foreground",
    dark: "text-primary",
    auto: "text-primary dark:text-primary-foreground",
  }

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className={cn("rounded-lg bg-white dark:bg-white/95 shadow-sm", sizeClasses[size].bg)}>
        <img
          src={logoImg}
          alt="LogicCV Logo"
          className={cn("object-contain", sizeClasses[size].icon)}
        />
      </div>
      {showText && (
        <span className={cn("font-bold tracking-tight", sizeClasses[size].text, variantClasses[variant])}>
          Logic<span className="text-accent">CV</span>
        </span>
      )}
    </div>
  )
}
