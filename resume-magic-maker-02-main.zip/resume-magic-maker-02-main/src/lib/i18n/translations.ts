export type Language = 'en' | 'ar'

export interface Translations {
  nav: {
    home: string; howItWorks: string; features: string; pricing: string;
    about: string; blog: string; careers: string; login: string;
    signup: string; dashboard: string; logout: string;
  };
  [key: string]: any;
}

export const translations: Record<Language, Translations> = {
  en: {
    nav: {
      home: 'Home', howItWorks: 'How It Works', features: 'Features',
      pricing: 'Pricing', about: 'About', blog: 'Blog', careers: 'Careers',
      login: 'Login', signup: 'Sign Up', dashboard: 'Dashboard', logout: 'Logout',
    },
  },
  ar: {
    nav: {
      home: 'الرئيسية', howItWorks: 'كيف يعمل', features: 'المميزات',
      pricing: 'الأسعار', about: 'من نحن', blog: 'المدونة', careers: 'الوظائف',
      login: 'تسجيل الدخول', signup: 'إنشاء حساب', dashboard: 'لوحة التحكم', logout: 'تسجيل الخروج',
    },
  },
}
