import { useState } from "react"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { HeroSection } from "@/components/landing/hero-section"
import { HowItWorks } from "@/components/landing/how-it-works"
import { FeaturesSection } from "@/components/landing/features-section"
import { TestimonialsSection } from "@/components/landing/testimonials-section"
import { PricingSection } from "@/components/landing/pricing-section"
import { FAQSection } from "@/components/landing/faq-section"
import { CTASection } from "@/components/landing/cta-section"
import { AIChatbot } from "@/components/chat/ai-chatbot"
import { BannerAd } from "@/components/ads/adsense-unit"
import { useLanguage } from "@/lib/i18n/language-context"
import { useAuth } from "@/lib/auth/auth-context"

const Index = () => {
  const { dir } = useLanguage()
  const { isPremium } = useAuth()

  return (
    <div className="min-h-screen flex flex-col" dir={dir}>
      <Header />
      <main className="flex-1">
        <HeroSection />
        {!isPremium && <BannerAd />}
        <HowItWorks />
        <FeaturesSection />
        {!isPremium && <BannerAd />}
        <TestimonialsSection />
        <PricingSection />
        {!isPremium && <BannerAd />}
        <FAQSection />
        <CTASection />
      </main>
      <Footer />
      <AIChatbot />
    </div>
  )
}

export default Index
